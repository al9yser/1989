.class public final synthetic Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic f$0:Ljava/lang/Object;

.field public final synthetic f$1:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Landroidx/media3/exoplayer/audio/AudioRendererEventListener$EventDispatcher;Landroidx/media3/common/Format;Landroidx/media3/exoplayer/DecoderReuseEvaluation;)V
    .registers 4

    .line 1
    const/16 p3, 0x13

    .line 2
    .line 3
    iput-byte p3, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->$r8$classId:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p2, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 11
    .line 12
    return-void
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;B)V
    .registers 4

    .line 13
    iput-byte p3, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->$r8$classId:B

    iput-object p1, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->$r8$classId:B

    .line 4
    .line 5
    const/16 v2, 0x9

    .line 6
    .line 7
    const/16 v3, 0x16

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    const/4 v5, 0x4

    .line 11
    const/4 v8, 0x0

    .line 12
    packed-switch v1, :pswitch_data_568

    .line 13
    .line 14
    .line 15
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v1, Lcoil/request/RequestService;

    .line 18
    .line 19
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v0, Landroidx/media3/common/VideoSize;

    .line 22
    .line 23
    iget-object v1, v1, Lcoil/request/RequestService;->hardwareBitmapService:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v1, Landroidx/media3/exoplayer/video/DefaultVideoSink;

    .line 26
    .line 27
    iget-object v1, v1, Landroidx/media3/exoplayer/video/DefaultVideoSink;->listener:Landroidx/media3/exoplayer/video/VideoSink$Listener;

    .line 28
    .line 29
    invoke-interface {v1, v0}, Landroidx/media3/exoplayer/video/VideoSink$Listener;->onVideoSizeChanged(Landroidx/media3/common/VideoSize;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :pswitch_20
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v1, Landroidx/recyclerview/widget/OpReorderer;

    .line 36
    .line 37
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v0, Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest;

    .line 40
    .line 41
    iget-object v1, v1, Landroidx/recyclerview/widget/OpReorderer;->mCallback:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v1, Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifestTracker;

    .line 44
    .line 45
    iget-object v1, v1, Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifestTracker;->callback:Landroidx/recyclerview/widget/OpReorderer;

    .line 46
    .line 47
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    .line 49
    .line 50
    iget-object v1, v1, Landroidx/recyclerview/widget/OpReorderer;->mCallback:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;

    .line 53
    .line 54
    iget-boolean v2, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->isActive:Z

    .line 55
    .line 56
    invoke-static {v2}, Lcoil/util/-Contexts;->checkState(Z)V

    .line 57
    .line 58
    .line 59
    iget-object v2, v0, Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest;->pathwayClones:Lcom/google/common/collect/ImmutableList;

    .line 60
    .line 61
    iget-object v3, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->availablePathwayIds:Ljava/util/HashSet;

    .line 62
    .line 63
    invoke-virtual {v2, v8}, Lcom/google/common/collect/ImmutableList;->listIterator(I)Lcom/google/common/collect/ImmutableList$Itr;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    :cond_42
    :goto_42
    invoke-virtual {v2}, Lcom/google/common/collect/ImmutableList$Itr;->hasNext()Z

    .line 68
    .line 69
    .line 70
    move-result v4

    .line 71
    if-eqz v4, :cond_120

    .line 72
    .line 73
    invoke-virtual {v2}, Lcom/google/common/collect/ImmutableList$Itr;->next()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    check-cast v4, Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest$PathwayClone;

    .line 78
    .line 79
    iget-object v10, v4, Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest$PathwayClone;->baseId:Ljava/lang/String;

    .line 80
    .line 81
    iget-object v11, v4, Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest$PathwayClone;->uriReplacement:Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest$UriReplacement;

    .line 82
    .line 83
    iget-object v12, v4, Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest$PathwayClone;->id:Ljava/lang/String;

    .line 84
    .line 85
    invoke-virtual {v3, v10}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v13

    .line 89
    if-eqz v13, :cond_42

    .line 90
    .line 91
    invoke-virtual {v3, v12}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v13

    .line 95
    if-eqz v13, :cond_61

    .line 96
    .line 97
    goto :goto_42

    .line 98
    :cond_61
    new-instance v13, Lcom/google/common/collect/ImmutableList$Builder;

    .line 99
    .line 100
    invoke-direct {v13, v5}, Lcom/google/common/collect/ImmutableCollection$ArrayBasedBuilder;-><init>(I)V

    .line 101
    .line 102
    .line 103
    new-instance v14, Lcom/google/common/collect/ImmutableList$Builder;

    .line 104
    .line 105
    invoke-direct {v14, v5}, Lcom/google/common/collect/ImmutableCollection$ArrayBasedBuilder;-><init>(I)V

    .line 106
    .line 107
    .line 108
    iget-object v15, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->variantRedundantGroups:Lcom/google/common/collect/ImmutableList;

    .line 109
    .line 110
    iget-object v5, v11, Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest$UriReplacement;->perVariantUris:Lcom/google/common/collect/RegularImmutableMap;

    .line 111
    .line 112
    invoke-virtual {v15}, Ljava/util/AbstractCollection;->size()I

    .line 113
    .line 114
    .line 115
    move-result v9

    .line 116
    :cond_73
    :goto_73
    if-ge v8, v9, :cond_af

    .line 117
    .line 118
    invoke-interface {v15, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v16

    .line 122
    add-int/lit8 v8, v8, 0x1

    .line 123
    .line 124
    move-object/from16 v6, v16

    .line 125
    .line 126
    check-cast v6, Landroidx/media3/exoplayer/hls/playlist/HlsRedundantGroup;

    .line 127
    .line 128
    iget-object v7, v6, Landroidx/media3/exoplayer/hls/playlist/HlsRedundantGroup;->pathwayIdToPlaylistUrl:Ljava/util/HashMap;

    .line 129
    .line 130
    invoke-virtual {v7, v10}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v7

    .line 134
    check-cast v7, Landroid/net/Uri;

    .line 135
    .line 136
    iget-object v6, v6, Landroidx/media3/exoplayer/hls/playlist/HlsRedundantGroup;->groupKey:Landroidx/media3/exoplayer/hls/playlist/HlsRedundantGroup$GroupKey;

    .line 137
    .line 138
    iget-object v6, v6, Landroidx/media3/exoplayer/hls/playlist/HlsRedundantGroup$GroupKey;->stableId:Ljava/lang/String;

    .line 139
    .line 140
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 141
    .line 142
    .line 143
    invoke-virtual {v5, v6}, Lcom/google/common/collect/RegularImmutableMap;->containsKey(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    move-result v16

    .line 147
    if-eqz v16, :cond_9e

    .line 148
    .line 149
    invoke-virtual {v5, v6}, Lcom/google/common/collect/RegularImmutableMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v6

    .line 153
    check-cast v6, Landroid/net/Uri;

    .line 154
    .line 155
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 156
    .line 157
    .line 158
    goto :goto_a6

    .line 159
    :cond_9e
    invoke-static {v7, v11}, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->getUriBuilder(Landroid/net/Uri;Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest$UriReplacement;)Landroid/net/Uri$Builder;

    .line 160
    .line 161
    .line 162
    move-result-object v6

    .line 163
    invoke-virtual {v6}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 164
    .line 165
    .line 166
    move-result-object v6

    .line 167
    :goto_a6
    if-eqz v6, :cond_73

    .line 168
    .line 169
    invoke-virtual {v13, v6}, Lcom/google/common/collect/ImmutableCollection$ArrayBasedBuilder;->add(Ljava/lang/Object;)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {v14, v7}, Lcom/google/common/collect/ImmutableCollection$ArrayBasedBuilder;->add(Ljava/lang/Object;)V

    .line 173
    .line 174
    .line 175
    goto :goto_73

    .line 176
    :cond_af
    iget-object v5, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->videoRenditionRedundantGroups:Lcom/google/common/collect/ImmutableList;

    .line 177
    .line 178
    invoke-static {v4, v5, v13, v14}, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->performPathwayClonesForRenditions(Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest$PathwayClone;Ljava/util/List;Lcom/google/common/collect/ImmutableList$Builder;Lcom/google/common/collect/ImmutableList$Builder;)V

    .line 179
    .line 180
    .line 181
    iget-object v5, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->audioRenditionRedundantGroups:Lcom/google/common/collect/ImmutableList;

    .line 182
    .line 183
    invoke-static {v4, v5, v13, v14}, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->performPathwayClonesForRenditions(Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest$PathwayClone;Ljava/util/List;Lcom/google/common/collect/ImmutableList$Builder;Lcom/google/common/collect/ImmutableList$Builder;)V

    .line 184
    .line 185
    .line 186
    iget-object v5, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->subtitleRenditionRedundantGroups:Lcom/google/common/collect/ImmutableList;

    .line 187
    .line 188
    invoke-static {v4, v5, v13, v14}, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->performPathwayClonesForRenditions(Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest$PathwayClone;Ljava/util/List;Lcom/google/common/collect/ImmutableList$Builder;Lcom/google/common/collect/ImmutableList$Builder;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v3, v12}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    iget-object v4, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->callback:Landroidx/recyclerview/widget/OpReorderer;

    .line 195
    .line 196
    invoke-virtual {v13}, Lcom/google/common/collect/ImmutableList$Builder;->build()Lcom/google/common/collect/RegularImmutableList;

    .line 197
    .line 198
    .line 199
    move-result-object v5

    .line 200
    invoke-virtual {v14}, Lcom/google/common/collect/ImmutableList$Builder;->build()Lcom/google/common/collect/RegularImmutableList;

    .line 201
    .line 202
    .line 203
    move-result-object v6

    .line 204
    iget-object v4, v4, Landroidx/recyclerview/widget/OpReorderer;->mCallback:Ljava/lang/Object;

    .line 205
    .line 206
    check-cast v4, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker;

    .line 207
    .line 208
    iget-object v4, v4, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker;->redundantGroupBundles:Ljava/util/HashMap;

    .line 209
    .line 210
    iget v7, v5, Lcom/google/common/collect/RegularImmutableList;->size:I

    .line 211
    .line 212
    iget v8, v6, Lcom/google/common/collect/RegularImmutableList;->size:I

    .line 213
    .line 214
    if-ne v7, v8, :cond_d9

    .line 215
    .line 216
    const/4 v7, 0x1

    .line 217
    goto :goto_da

    .line 218
    :cond_d9
    const/4 v7, 0x0

    .line 219
    :goto_da
    invoke-static {v7}, Lcoil/util/-Contexts;->checkState(Z)V

    .line 220
    .line 221
    .line 222
    const/4 v7, 0x0

    .line 223
    :goto_de
    iget v8, v5, Lcom/google/common/collect/RegularImmutableList;->size:I

    .line 224
    .line 225
    if-ge v7, v8, :cond_11c

    .line 226
    .line 227
    invoke-virtual {v6, v7}, Lcom/google/common/collect/RegularImmutableList;->get(I)Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v8

    .line 231
    invoke-virtual {v4, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v8

    .line 235
    check-cast v8, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$RedundantGroupBundle;

    .line 236
    .line 237
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 238
    .line 239
    .line 240
    invoke-virtual {v5, v7}, Lcom/google/common/collect/RegularImmutableList;->get(I)Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v9

    .line 244
    check-cast v9, Landroid/net/Uri;

    .line 245
    .line 246
    iget-object v10, v8, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$RedundantGroupBundle;->redundantGroup:Landroidx/media3/exoplayer/hls/playlist/HlsRedundantGroup;

    .line 247
    .line 248
    iget-object v10, v10, Landroidx/media3/exoplayer/hls/playlist/HlsRedundantGroup;->pathwayIdToPlaylistUrl:Ljava/util/HashMap;

    .line 249
    .line 250
    invoke-virtual {v10, v12, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    iget-object v10, v8, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$RedundantGroupBundle;->playlistBundles:Ljava/util/HashMap;

    .line 254
    .line 255
    invoke-virtual {v10, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 256
    .line 257
    .line 258
    move-result-object v11

    .line 259
    check-cast v11, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$MediaPlaylistBundle;

    .line 260
    .line 261
    if-nez v11, :cond_111

    .line 262
    .line 263
    new-instance v11, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$MediaPlaylistBundle;

    .line 264
    .line 265
    iget-object v13, v8, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$RedundantGroupBundle;->this$0:Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker;

    .line 266
    .line 267
    invoke-direct {v11, v13, v9, v12}, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$MediaPlaylistBundle;-><init>(Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker;Landroid/net/Uri;Ljava/lang/String;)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {v10, v9, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    goto :goto_116

    .line 274
    :cond_111
    iget-object v10, v11, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$MediaPlaylistBundle;->pathwayIds:Ljava/util/HashSet;

    .line 275
    .line 276
    invoke-virtual {v10, v12}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 277
    .line 278
    .line 279
    :goto_116
    invoke-virtual {v4, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    add-int/lit8 v7, v7, 0x1

    .line 283
    .line 284
    goto :goto_de

    .line 285
    :cond_11c
    const/4 v5, 0x4

    .line 286
    const/4 v8, 0x0

    .line 287
    goto/16 :goto_42

    .line 288
    .line 289
    :cond_120
    iget-object v0, v0, Landroidx/media3/exoplayer/upstream/contentsteering/SteeringManifest;->pathwayPriority:Lcom/google/common/collect/ImmutableList;

    .line 290
    .line 291
    iput-object v0, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->currentPathwayPriority:Lcom/google/common/collect/ImmutableList;

    .line 292
    .line 293
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    invoke-virtual {v1, v2, v3}, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->performPathwayEvaluationAndUpdate(J)V

    .line 299
    .line 300
    .line 301
    return-void

    .line 302
    :pswitch_12d
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 303
    .line 304
    check-cast v1, Landroidx/media3/exoplayer/source/ProgressiveMediaPeriod;

    .line 305
    .line 306
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 307
    .line 308
    check-cast v0, Landroidx/media3/extractor/SeekMap;

    .line 309
    .line 310
    invoke-virtual {v1, v0}, Landroidx/media3/exoplayer/source/ProgressiveMediaPeriod;->setSeekMap(Landroidx/media3/extractor/SeekMap;)V

    .line 311
    .line 312
    .line 313
    return-void

    .line 314
    :pswitch_139
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 315
    .line 316
    check-cast v1, Landroidx/media3/common/util/Consumer;

    .line 317
    .line 318
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 319
    .line 320
    check-cast v0, Landroidx/media3/exoplayer/source/MediaSourceEventListener;

    .line 321
    .line 322
    invoke-interface {v1, v0}, Landroidx/media3/common/util/Consumer;->accept(Ljava/lang/Object;)V

    .line 323
    .line 324
    .line 325
    return-void

    .line 326
    :pswitch_145
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 327
    .line 328
    check-cast v1, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$MediaPlaylistBundle;

    .line 329
    .line 330
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 331
    .line 332
    check-cast v0, Landroid/net/Uri;

    .line 333
    .line 334
    const/4 v2, 0x0

    .line 335
    iput-boolean v2, v1, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$MediaPlaylistBundle;->loadPending:Z

    .line 336
    .line 337
    iget-object v2, v1, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$MediaPlaylistBundle;->playlistUrl:Landroid/net/Uri;

    .line 338
    .line 339
    iget-object v3, v1, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$MediaPlaylistBundle;->this$0:Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker;

    .line 340
    .line 341
    iget-object v3, v3, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker;->primaryMediaPlaylistUrl:Landroid/net/Uri;

    .line 342
    .line 343
    invoke-virtual {v2, v3}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    .line 344
    .line 345
    .line 346
    move-result v2

    .line 347
    if-nez v2, :cond_160

    .line 348
    .line 349
    iget-boolean v2, v1, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$MediaPlaylistBundle;->activeForPlayback:Z

    .line 350
    .line 351
    if-eqz v2, :cond_163

    .line 352
    .line 353
    :cond_160
    invoke-virtual {v1, v0}, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$MediaPlaylistBundle;->loadPlaylistImmediately(Landroid/net/Uri;)V

    .line 354
    .line 355
    .line 356
    :cond_163
    return-void

    .line 357
    :pswitch_164
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 358
    .line 359
    check-cast v1, Landroidx/media3/exoplayer/hls/HlsSampleStreamWrapper;

    .line 360
    .line 361
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 362
    .line 363
    check-cast v0, Landroidx/media3/exoplayer/hls/HlsMediaChunk;

    .line 364
    .line 365
    iget-object v1, v1, Landroidx/media3/exoplayer/hls/HlsSampleStreamWrapper;->callback:Landroidx/recyclerview/widget/OpReorderer;

    .line 366
    .line 367
    iget-object v0, v0, Landroidx/media3/exoplayer/hls/HlsMediaChunk;->playlistUrl:Landroid/net/Uri;

    .line 368
    .line 369
    iget-object v1, v1, Landroidx/recyclerview/widget/OpReorderer;->mCallback:Ljava/lang/Object;

    .line 370
    .line 371
    check-cast v1, Landroidx/media3/exoplayer/hls/HlsMediaPeriod;

    .line 372
    .line 373
    iget-object v1, v1, Landroidx/media3/exoplayer/hls/HlsMediaPeriod;->playlistTracker:Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker;

    .line 374
    .line 375
    iget-object v1, v1, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker;->redundantGroupBundles:Ljava/util/HashMap;

    .line 376
    .line 377
    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    move-result-object v1

    .line 381
    check-cast v1, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$RedundantGroupBundle;

    .line 382
    .line 383
    if-eqz v1, :cond_184

    .line 384
    .line 385
    const/4 v2, 0x1

    .line 386
    invoke-virtual {v1, v2, v0}, Landroidx/media3/exoplayer/hls/playlist/DefaultHlsPlaylistTracker$RedundantGroupBundle;->loadPlaylist(ZLandroid/net/Uri;)V

    .line 387
    .line 388
    .line 389
    :cond_184
    return-void

    .line 390
    :pswitch_185
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 391
    .line 392
    check-cast v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;

    .line 393
    .line 394
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 395
    .line 396
    check-cast v0, Ljava/lang/String;

    .line 397
    .line 398
    iget-boolean v2, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->isActive:Z

    .line 399
    .line 400
    invoke-static {v2}, Lcoil/util/-Contexts;->checkState(Z)V

    .line 401
    .line 402
    .line 403
    iget-object v2, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->excludedPathwayIds:Ljava/util/HashSet;

    .line 404
    .line 405
    invoke-virtual {v2, v0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 406
    .line 407
    .line 408
    iget-object v0, v1, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->currentPathwayPriority:Lcom/google/common/collect/ImmutableList;

    .line 409
    .line 410
    if-eqz v0, :cond_1a3

    .line 411
    .line 412
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    invoke-virtual {v1, v2, v3}, Landroidx/media3/exoplayer/hls/HlsContentSteeringTracker;->performPathwayEvaluationAndUpdate(J)V

    .line 418
    .line 419
    .line 420
    :cond_1a3
    return-void

    .line 421
    :pswitch_1a4
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 422
    .line 423
    check-cast v1, Lokhttp3/Dispatcher;

    .line 424
    .line 425
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 426
    .line 427
    check-cast v0, Landroid/media/AudioDeviceInfo;

    .line 428
    .line 429
    iget-object v2, v1, Lokhttp3/Dispatcher;->runningSyncCalls:Ljava/lang/Object;

    .line 430
    .line 431
    check-cast v2, Landroidx/media3/exoplayer/audio/AudioTrackAudioOutput$OnRoutingChangedListenerApi24$$ExternalSyntheticLambda0;

    .line 432
    .line 433
    if-nez v2, :cond_1b3

    .line 434
    .line 435
    goto :goto_1e6

    .line 436
    :cond_1b3
    iget-object v1, v1, Lokhttp3/Dispatcher;->readyAsyncCalls:Ljava/lang/Object;

    .line 437
    .line 438
    check-cast v1, Landroidx/recyclerview/widget/OpReorderer;

    .line 439
    .line 440
    iget-object v1, v1, Landroidx/recyclerview/widget/OpReorderer;->mCallback:Ljava/lang/Object;

    .line 441
    .line 442
    check-cast v1, Landroidx/media3/exoplayer/audio/AudioTrackAudioOutputProvider;

    .line 443
    .line 444
    iget-object v1, v1, Landroidx/media3/exoplayer/audio/AudioTrackAudioOutputProvider;->audioCapabilitiesReceiver:Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;

    .line 445
    .line 446
    if-eqz v1, :cond_1e6

    .line 447
    .line 448
    iget-object v2, v1, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;->routedDevice:Landroid/media/AudioDeviceInfo;

    .line 449
    .line 450
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 451
    .line 452
    .line 453
    move-result v2

    .line 454
    if-eqz v2, :cond_1c8

    .line 455
    .line 456
    goto :goto_1e6

    .line 457
    :cond_1c8
    iput-object v0, v1, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;->routedDevice:Landroid/media/AudioDeviceInfo;

    .line 458
    .line 459
    iget-object v2, v1, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;->context:Landroid/content/Context;

    .line 460
    .line 461
    iget-object v3, v1, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;->audioAttributes:Landroidx/media3/common/AudioAttributes;

    .line 462
    .line 463
    invoke-virtual {v1}, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;->getSpatializerChannelMasks()Ljava/util/List;

    .line 464
    .line 465
    .line 466
    move-result-object v5

    .line 467
    sget-object v6, Landroidx/media3/exoplayer/audio/AudioCapabilities;->DEFAULT_SPEAKER_LAYOUT_CHANNEL_MASKS:Lcom/google/common/collect/RegularImmutableList;

    .line 468
    .line 469
    new-instance v6, Landroid/content/IntentFilter;

    .line 470
    .line 471
    const-string v7, "android.media.action.HDMI_AUDIO_PLUG"

    .line 472
    .line 473
    invoke-direct {v6, v7}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 474
    .line 475
    .line 476
    invoke-virtual {v2, v4, v6}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 477
    .line 478
    .line 479
    move-result-object v4

    .line 480
    invoke-static {v2, v4, v3, v0, v5}, Landroidx/media3/exoplayer/audio/AudioCapabilities;->getCapabilitiesInternal(Landroid/content/Context;Landroid/content/Intent;Landroidx/media3/common/AudioAttributes;Landroid/media/AudioDeviceInfo;Ljava/util/List;)Landroidx/media3/exoplayer/audio/AudioCapabilities;

    .line 481
    .line 482
    .line 483
    move-result-object v0

    .line 484
    invoke-virtual {v1, v0}, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;->onNewAudioCapabilities(Landroidx/media3/exoplayer/audio/AudioCapabilities;)V

    .line 485
    .line 486
    .line 487
    :cond_1e6
    :goto_1e6
    return-void

    .line 488
    :pswitch_1e7
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 489
    .line 490
    check-cast v1, Lokhttp3/Dispatcher;

    .line 491
    .line 492
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 493
    .line 494
    check-cast v0, Landroid/media/AudioRouting;

    .line 495
    .line 496
    invoke-interface {v0}, Landroid/media/AudioRouting;->getRoutedDevice()Landroid/media/AudioDeviceInfo;

    .line 497
    .line 498
    .line 499
    move-result-object v0

    .line 500
    if-eqz v0, :cond_201

    .line 501
    .line 502
    iget-object v2, v1, Lokhttp3/Dispatcher;->runningAsyncCalls:Ljava/lang/Object;

    .line 503
    .line 504
    check-cast v2, Landroid/os/Handler;

    .line 505
    .line 506
    new-instance v4, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;

    .line 507
    .line 508
    invoke-direct {v4, v1, v0, v3}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 509
    .line 510
    .line 511
    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 512
    .line 513
    .line 514
    :cond_201
    return-void

    .line 515
    :pswitch_202
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 516
    .line 517
    check-cast v1, Landroidx/media3/exoplayer/audio/AudioRendererEventListener$EventDispatcher;

    .line 518
    .line 519
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 520
    .line 521
    check-cast v0, Landroidx/media3/exoplayer/CodecParameters;

    .line 522
    .line 523
    iget-object v1, v1, Landroidx/media3/exoplayer/audio/AudioRendererEventListener$EventDispatcher;->listener:Landroidx/media3/exoplayer/audio/AudioRendererEventListener;

    .line 524
    .line 525
    sget-object v2, Landroidx/media3/common/util/Util;->DEVICE_DEBUG_INFO:Ljava/lang/String;

    .line 526
    .line 527
    check-cast v1, Landroidx/media3/exoplayer/ExoPlayerImpl$ComponentListener;

    .line 528
    .line 529
    iget-object v1, v1, Landroidx/media3/exoplayer/ExoPlayerImpl$ComponentListener;->this$0:Landroidx/media3/exoplayer/ExoPlayerImpl;

    .line 530
    .line 531
    iget-object v1, v1, Landroidx/media3/exoplayer/ExoPlayerImpl;->audioListenerManager:Lcoil/request/RequestService;

    .line 532
    .line 533
    invoke-virtual {v1, v0}, Lcoil/request/RequestService;->onParametersChanged(Landroidx/media3/exoplayer/CodecParameters;)V

    .line 534
    .line 535
    .line 536
    return-void

    .line 537
    :pswitch_218
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 538
    .line 539
    check-cast v1, Landroidx/media3/exoplayer/audio/AudioRendererEventListener$EventDispatcher;

    .line 540
    .line 541
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 542
    .line 543
    check-cast v0, Landroidx/media3/common/Format;

    .line 544
    .line 545
    iget-object v1, v1, Landroidx/media3/exoplayer/audio/AudioRendererEventListener$EventDispatcher;->listener:Landroidx/media3/exoplayer/audio/AudioRendererEventListener;

    .line 546
    .line 547
    sget-object v2, Landroidx/media3/common/util/Util;->DEVICE_DEBUG_INFO:Ljava/lang/String;

    .line 548
    .line 549
    check-cast v1, Landroidx/media3/exoplayer/ExoPlayerImpl$ComponentListener;

    .line 550
    .line 551
    iget-object v1, v1, Landroidx/media3/exoplayer/ExoPlayerImpl$ComponentListener;->this$0:Landroidx/media3/exoplayer/ExoPlayerImpl;

    .line 552
    .line 553
    iput-object v0, v1, Landroidx/media3/exoplayer/ExoPlayerImpl;->audioFormat:Landroidx/media3/common/Format;

    .line 554
    .line 555
    iget-object v0, v1, Landroidx/media3/exoplayer/ExoPlayerImpl;->analyticsCollector:Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector;

    .line 556
    .line 557
    invoke-virtual {v0}, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector;->generateReadingMediaPeriodEventTime()Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;

    .line 558
    .line 559
    .line 560
    move-result-object v1

    .line 561
    new-instance v2, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector$$ExternalSyntheticLambda1;

    .line 562
    .line 563
    invoke-direct {v2, v3}, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector$$ExternalSyntheticLambda1;-><init>(B)V

    .line 564
    .line 565
    .line 566
    const/16 v3, 0x3f1

    .line 567
    .line 568
    invoke-virtual {v0, v1, v3, v2}, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector;->sendEvent(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;ILandroidx/media3/common/util/ListenerSet$Event;)V

    .line 569
    .line 570
    .line 571
    return-void

    .line 572
    :pswitch_23b
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 573
    .line 574
    check-cast v1, Landroidx/media3/exoplayer/audio/AudioRendererEventListener$EventDispatcher;

    .line 575
    .line 576
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 577
    .line 578
    check-cast v0, Landroidx/media3/exoplayer/DecoderCounters;

    .line 579
    .line 580
    monitor-enter v0

    .line 581
    monitor-exit v0

    .line 582
    iget-object v0, v1, Landroidx/media3/exoplayer/audio/AudioRendererEventListener$EventDispatcher;->listener:Landroidx/media3/exoplayer/audio/AudioRendererEventListener;

    .line 583
    .line 584
    sget-object v1, Landroidx/media3/common/util/Util;->DEVICE_DEBUG_INFO:Ljava/lang/String;

    .line 585
    .line 586
    check-cast v0, Landroidx/media3/exoplayer/ExoPlayerImpl$ComponentListener;

    .line 587
    .line 588
    iget-object v0, v0, Landroidx/media3/exoplayer/ExoPlayerImpl$ComponentListener;->this$0:Landroidx/media3/exoplayer/ExoPlayerImpl;

    .line 589
    .line 590
    iget-object v1, v0, Landroidx/media3/exoplayer/ExoPlayerImpl;->analyticsCollector:Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector;

    .line 591
    .line 592
    iget-object v2, v1, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector;->mediaPeriodQueueTracker:Landroidx/work/Configuration;

    .line 593
    .line 594
    iget-object v2, v2, Landroidx/work/Configuration;->runnableScheduler:Ljava/lang/Object;

    .line 595
    .line 596
    check-cast v2, Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;

    .line 597
    .line 598
    invoke-virtual {v1, v2}, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector;->generateEventTime(Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;)Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;

    .line 599
    .line 600
    .line 601
    move-result-object v2

    .line 602
    new-instance v3, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector$$ExternalSyntheticLambda1;

    .line 603
    .line 604
    const/16 v5, 0x11

    .line 605
    .line 606
    invoke-direct {v3, v5}, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector$$ExternalSyntheticLambda1;-><init>(B)V

    .line 607
    .line 608
    .line 609
    const/16 v5, 0x3f5

    .line 610
    .line 611
    invoke-virtual {v1, v2, v5, v3}, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector;->sendEvent(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;ILandroidx/media3/common/util/ListenerSet$Event;)V

    .line 612
    .line 613
    .line 614
    iput-object v4, v0, Landroidx/media3/exoplayer/ExoPlayerImpl;->audioFormat:Landroidx/media3/common/Format;

    .line 615
    .line 616
    return-void

    .line 617
    :pswitch_268
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 618
    .line 619
    check-cast v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;

    .line 620
    .line 621
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 622
    .line 623
    check-cast v0, Landroid/media/metrics/PlaybackStateEvent;

    .line 624
    .line 625
    iget-object v1, v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 626
    .line 627
    invoke-static {v1, v0}, Landroidx/media3/exoplayer/audio/AudioCapabilities$$ExternalSyntheticApiModelOutline0;->m(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackStateEvent;)V

    .line 628
    .line 629
    .line 630
    return-void

    .line 631
    :pswitch_276
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 632
    .line 633
    check-cast v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;

    .line 634
    .line 635
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 636
    .line 637
    check-cast v0, Landroid/media/metrics/PlaybackMetrics;

    .line 638
    .line 639
    iget-object v1, v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 640
    .line 641
    invoke-static {v1, v0}, Landroidx/media3/exoplayer/audio/AudioCapabilities$$ExternalSyntheticApiModelOutline0;->m(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackMetrics;)V

    .line 642
    .line 643
    .line 644
    return-void

    .line 645
    :pswitch_284
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 646
    .line 647
    check-cast v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;

    .line 648
    .line 649
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 650
    .line 651
    check-cast v0, Landroid/media/metrics/PlaybackErrorEvent;

    .line 652
    .line 653
    iget-object v1, v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 654
    .line 655
    invoke-static {v1, v0}, Landroidx/media3/exoplayer/audio/AudioCapabilities$$ExternalSyntheticApiModelOutline0;->m(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackErrorEvent;)V

    .line 656
    .line 657
    .line 658
    return-void

    .line 659
    :pswitch_292
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 660
    .line 661
    check-cast v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;

    .line 662
    .line 663
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 664
    .line 665
    check-cast v0, Landroid/media/metrics/NetworkEvent;

    .line 666
    .line 667
    iget-object v1, v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 668
    .line 669
    invoke-static {v1, v0}, Landroidx/media3/exoplayer/audio/AudioCapabilities$$ExternalSyntheticApiModelOutline0;->m(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/NetworkEvent;)V

    .line 670
    .line 671
    .line 672
    return-void

    .line 673
    :pswitch_2a0
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 674
    .line 675
    check-cast v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;

    .line 676
    .line 677
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 678
    .line 679
    check-cast v0, Landroid/media/metrics/TrackChangeEvent;

    .line 680
    .line 681
    iget-object v1, v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 682
    .line 683
    invoke-static {v1, v0}, Landroidx/media3/exoplayer/audio/AudioCapabilities$$ExternalSyntheticApiModelOutline0;->m(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/TrackChangeEvent;)V

    .line 684
    .line 685
    .line 686
    return-void

    .line 687
    :pswitch_2ae
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 693
    .line 694
    move-object v4, v1

    .line 695
    check-cast v4, Landroidx/media3/exoplayer/ExoPlayerImpl;

    .line 696
    .line 697
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 698
    .line 699
    check-cast v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;

    .line 700
    .line 701
    iget v1, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->pendingOperationAcks:I

    .line 702
    .line 703
    iget v5, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mPosition:I

    .line 704
    .line 705
    sub-int/2addr v1, v5

    .line 706
    iput v1, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->pendingOperationAcks:I

    .line 707
    .line 708
    iget-boolean v5, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mValid:Z

    .line 709
    .line 710
    if-eqz v5, :cond_2ce

    .line 711
    .line 712
    iget v5, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mCoordinate:I

    .line 713
    .line 714
    iput v5, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->pendingDiscontinuityReason:I

    .line 715
    .line 716
    const/4 v5, 0x1

    .line 717
    iput-boolean v5, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->pendingDiscontinuity:Z

    .line 718
    .line 719
    :cond_2ce
    if-nez v1, :cond_3bb

    .line 720
    .line 721
    iget-object v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mOrientationHelper:Ljava/lang/Object;

    .line 722
    .line 723
    check-cast v1, Landroidx/media3/exoplayer/PlaybackInfo;

    .line 724
    .line 725
    iget-object v1, v1, Landroidx/media3/exoplayer/PlaybackInfo;->timeline:Landroidx/media3/common/Timeline;

    .line 726
    .line 727
    iget-object v5, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->playbackInfo:Landroidx/media3/exoplayer/PlaybackInfo;

    .line 728
    .line 729
    iget-object v5, v5, Landroidx/media3/exoplayer/PlaybackInfo;->timeline:Landroidx/media3/common/Timeline;

    .line 730
    .line 731
    invoke-virtual {v5}, Landroidx/media3/common/Timeline;->isEmpty()Z

    .line 732
    .line 733
    .line 734
    move-result v5

    .line 735
    const/4 v6, -0x1

    .line 736
    if-nez v5, :cond_2ed

    .line 737
    .line 738
    invoke-virtual {v1}, Landroidx/media3/common/Timeline;->isEmpty()Z

    .line 739
    .line 740
    .line 741
    move-result v5

    .line 742
    if-eqz v5, :cond_2ed

    .line 743
    .line 744
    iput v6, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->maskingWindowIndex:I

    .line 745
    .line 746
    const-wide/16 v7, 0x0

    .line 747
    .line 748
    iput-wide v7, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->maskingWindowPositionMs:J

    .line 749
    .line 750
    :cond_2ed
    invoke-virtual {v1}, Landroidx/media3/common/Timeline;->isEmpty()Z

    .line 751
    .line 752
    .line 753
    move-result v5

    .line 754
    if-nez v5, :cond_328

    .line 755
    .line 756
    move-object v5, v1

    .line 757
    check-cast v5, Landroidx/media3/exoplayer/PlaylistTimeline;

    .line 758
    .line 759
    iget-object v5, v5, Landroidx/media3/exoplayer/PlaylistTimeline;->timelines:[Landroidx/media3/common/Timeline;

    .line 760
    .line 761
    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 762
    .line 763
    .line 764
    move-result-object v5

    .line 765
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 766
    .line 767
    .line 768
    move-result v7

    .line 769
    iget-object v8, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->mediaSourceHolderSnapshots:Ljava/util/ArrayList;

    .line 770
    .line 771
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 772
    .line 773
    .line 774
    move-result v8

    .line 775
    if-ne v7, v8, :cond_30a

    .line 776
    .line 777
    const/4 v7, 0x1

    .line 778
    goto :goto_30b

    .line 779
    :cond_30a
    const/4 v7, 0x0

    .line 780
    :goto_30b
    invoke-static {v7}, Lcoil/util/-Contexts;->checkState(Z)V

    .line 781
    .line 782
    .line 783
    const/4 v7, 0x0

    .line 784
    :goto_30f
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 785
    .line 786
    .line 787
    move-result v8

    .line 788
    if-ge v7, v8, :cond_328

    .line 789
    .line 790
    iget-object v8, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->mediaSourceHolderSnapshots:Ljava/util/ArrayList;

    .line 791
    .line 792
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 793
    .line 794
    .line 795
    move-result-object v8

    .line 796
    check-cast v8, Landroidx/media3/exoplayer/ExoPlayerImpl$MediaSourceHolderSnapshot;

    .line 797
    .line 798
    invoke-interface {v5, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 799
    .line 800
    .line 801
    move-result-object v9

    .line 802
    check-cast v9, Landroidx/media3/common/Timeline;

    .line 803
    .line 804
    iput-object v9, v8, Landroidx/media3/exoplayer/ExoPlayerImpl$MediaSourceHolderSnapshot;->timeline:Landroidx/media3/common/Timeline;

    .line 805
    .line 806
    add-int/lit8 v7, v7, 0x1

    .line 807
    .line 808
    goto :goto_30f

    .line 809
    :cond_328
    iget-boolean v5, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->pendingDiscontinuity:Z

    .line 810
    .line 811
    if-eqz v5, :cond_3a9

    .line 812
    .line 813
    iget-object v5, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mOrientationHelper:Ljava/lang/Object;

    .line 814
    .line 815
    check-cast v5, Landroidx/media3/exoplayer/PlaybackInfo;

    .line 816
    .line 817
    iget-object v5, v5, Landroidx/media3/exoplayer/PlaybackInfo;->timeline:Landroidx/media3/common/Timeline;

    .line 818
    .line 819
    invoke-virtual {v5}, Landroidx/media3/common/Timeline;->isEmpty()Z

    .line 820
    .line 821
    .line 822
    move-result v5

    .line 823
    if-eqz v5, :cond_344

    .line 824
    .line 825
    iget-object v5, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->playbackInfo:Landroidx/media3/exoplayer/PlaybackInfo;

    .line 826
    .line 827
    iget-object v5, v5, Landroidx/media3/exoplayer/PlaybackInfo;->timeline:Landroidx/media3/common/Timeline;

    .line 828
    .line 829
    invoke-virtual {v5}, Landroidx/media3/common/Timeline;->isEmpty()Z

    .line 830
    .line 831
    .line 832
    move-result v5

    .line 833
    if-eqz v5, :cond_344

    .line 834
    .line 835
    const/4 v5, 0x1

    .line 836
    goto :goto_345

    .line 837
    :cond_344
    const/4 v5, 0x0

    .line 838
    :goto_345
    iget-object v7, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mOrientationHelper:Ljava/lang/Object;

    .line 839
    .line 840
    check-cast v7, Landroidx/media3/exoplayer/PlaybackInfo;

    .line 841
    .line 842
    iget-object v7, v7, Landroidx/media3/exoplayer/PlaybackInfo;->periodId:Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;

    .line 843
    .line 844
    iget-object v8, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->playbackInfo:Landroidx/media3/exoplayer/PlaybackInfo;

    .line 845
    .line 846
    iget-object v8, v8, Landroidx/media3/exoplayer/PlaybackInfo;->periodId:Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;

    .line 847
    .line 848
    invoke-virtual {v7, v8}, Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;->equalsExceptNextAdGroupIndex(Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;)Z

    .line 849
    .line 850
    .line 851
    move-result v7

    .line 852
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mOrientationHelper:Ljava/lang/Object;

    .line 853
    .line 854
    check-cast v8, Landroidx/media3/exoplayer/PlaybackInfo;

    .line 855
    .line 856
    iget-wide v8, v8, Landroidx/media3/exoplayer/PlaybackInfo;->discontinuityStartPositionUs:J

    .line 857
    .line 858
    iget-object v10, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->playbackInfo:Landroidx/media3/exoplayer/PlaybackInfo;

    .line 859
    .line 860
    iget-wide v10, v10, Landroidx/media3/exoplayer/PlaybackInfo;->positionUs:J

    .line 861
    .line 862
    cmp-long v8, v8, v10

    .line 863
    .line 864
    if-nez v8, :cond_363

    .line 865
    .line 866
    const/4 v8, 0x1

    .line 867
    goto :goto_364

    .line 868
    :cond_363
    const/4 v8, 0x0

    .line 869
    :goto_364
    if-nez v5, :cond_36c

    .line 870
    .line 871
    if-eqz v7, :cond_36a

    .line 872
    .line 873
    if-nez v8, :cond_36c

    .line 874
    .line 875
    :cond_36a
    const/4 v9, 0x1

    .line 876
    goto :goto_36d

    .line 877
    :cond_36c
    const/4 v9, 0x0

    .line 878
    :goto_36d
    if-eqz v9, :cond_3a5

    .line 879
    .line 880
    invoke-virtual {v4}, Landroidx/media3/exoplayer/ExoPlayerImpl;->getCurrentMediaItemIndex()I

    .line 881
    .line 882
    .line 883
    move-result v6

    .line 884
    invoke-virtual {v1}, Landroidx/media3/common/Timeline;->isEmpty()Z

    .line 885
    .line 886
    .line 887
    move-result v2

    .line 888
    if-nez v2, :cond_39a

    .line 889
    .line 890
    iget-object v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mOrientationHelper:Ljava/lang/Object;

    .line 891
    .line 892
    check-cast v2, Landroidx/media3/exoplayer/PlaybackInfo;

    .line 893
    .line 894
    iget-object v2, v2, Landroidx/media3/exoplayer/PlaybackInfo;->periodId:Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;

    .line 895
    .line 896
    invoke-virtual {v2}, Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;->isAd()Z

    .line 897
    .line 898
    .line 899
    move-result v2

    .line 900
    if-eqz v2, :cond_386

    .line 901
    .line 902
    goto :goto_39a

    .line 903
    :cond_386
    iget-object v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mOrientationHelper:Ljava/lang/Object;

    .line 904
    .line 905
    check-cast v2, Landroidx/media3/exoplayer/PlaybackInfo;

    .line 906
    .line 907
    iget-object v3, v2, Landroidx/media3/exoplayer/PlaybackInfo;->periodId:Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;

    .line 908
    .line 909
    iget-wide v7, v2, Landroidx/media3/exoplayer/PlaybackInfo;->discontinuityStartPositionUs:J

    .line 910
    .line 911
    iget-object v2, v3, Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;->periodUid:Ljava/lang/Object;

    .line 912
    .line 913
    iget-object v3, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->period:Landroidx/media3/common/Timeline$Period;

    .line 914
    .line 915
    invoke-virtual {v1, v2, v3}, Landroidx/media3/common/Timeline;->getPeriodByUid(Ljava/lang/Object;Landroidx/media3/common/Timeline$Period;)Landroidx/media3/common/Timeline$Period;

    .line 916
    .line 917
    .line 918
    iget-wide v1, v3, Landroidx/media3/common/Timeline$Period;->positionInWindowUs:J

    .line 919
    .line 920
    add-long/2addr v7, v1

    .line 921
    move-wide v1, v7

    .line 922
    goto :goto_3a0

    .line 923
    :cond_39a
    :goto_39a
    iget-object v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mOrientationHelper:Ljava/lang/Object;

    .line 924
    .line 925
    check-cast v1, Landroidx/media3/exoplayer/PlaybackInfo;

    .line 926
    .line 927
    iget-wide v1, v1, Landroidx/media3/exoplayer/PlaybackInfo;->discontinuityStartPositionUs:J

    .line 928
    .line 929
    :goto_3a0
    move v11, v6

    .line 930
    move v7, v9

    .line 931
    move-wide v9, v1

    .line 932
    :goto_3a3
    const/4 v2, 0x0

    .line 933
    goto :goto_3ad

    .line 934
    :cond_3a5
    move v11, v6

    .line 935
    move v7, v9

    .line 936
    move-wide v9, v2

    .line 937
    goto :goto_3a3

    .line 938
    :cond_3a9
    move-wide v9, v2

    .line 939
    move v11, v6

    .line 940
    const/4 v2, 0x0

    .line 941
    const/4 v7, 0x0

    .line 942
    :goto_3ad
    iput-boolean v2, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->pendingDiscontinuity:Z

    .line 943
    .line 944
    iget-object v0, v0, Landroidx/recyclerview/widget/LinearLayoutManager$AnchorInfo;->mOrientationHelper:Ljava/lang/Object;

    .line 945
    .line 946
    move-object v5, v0

    .line 947
    check-cast v5, Landroidx/media3/exoplayer/PlaybackInfo;

    .line 948
    .line 949
    iget v8, v4, Landroidx/media3/exoplayer/ExoPlayerImpl;->pendingDiscontinuityReason:I

    .line 950
    .line 951
    const/4 v12, 0x0

    .line 952
    const/4 v6, 0x1

    .line 953
    invoke-virtual/range {v4 .. v12}, Landroidx/media3/exoplayer/ExoPlayerImpl;->updatePlaybackInfo(Landroidx/media3/exoplayer/PlaybackInfo;IZIJIZ)V

    .line 954
    .line 955
    .line 956
    :cond_3bb
    return-void

    .line 957
    :pswitch_3bc
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 958
    .line 959
    check-cast v1, Landroidx/core/provider/CallbackWrapper;

    .line 960
    .line 961
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 962
    .line 963
    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 964
    .line 965
    monitor-enter v1

    .line 966
    :try_start_3c5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 967
    .line 968
    .line 969
    move-result v0

    .line 970
    if-eqz v0, :cond_3d7

    .line 971
    .line 972
    iget-object v0, v1, Landroidx/core/provider/CallbackWrapper;->mExecutor:Ljava/lang/Object;

    .line 973
    .line 974
    check-cast v0, Landroid/net/wifi/WifiManager$WifiLock;

    .line 975
    .line 976
    if-eqz v0, :cond_3d7

    .line 977
    .line 978
    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$WifiLock;->release()V
    :try_end_3d4
    .catchall {:try_start_3c5 .. :try_end_3d4} :catchall_3d5

    .line 979
    .line 980
    .line 981
    goto :goto_3d7

    .line 982
    :catchall_3d5
    move-exception v0

    .line 983
    goto :goto_3d9

    .line 984
    :cond_3d7
    :goto_3d7
    monitor-exit v1

    .line 985
    return-void

    .line 986
    :goto_3d9
    :try_start_3d9
    monitor-exit v1
    :try_end_3da
    .catchall {:try_start_3d9 .. :try_end_3da} :catchall_3d5

    .line 987
    throw v0

    .line 988
    :pswitch_3db
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 989
    .line 990
    check-cast v1, Landroidx/media3/common/util/WakeLockManager;

    .line 991
    .line 992
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 993
    .line 994
    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 995
    .line 996
    iget-object v1, v1, Landroidx/media3/common/util/WakeLockManager;->wakeLockManagerInternal:Ljava/lang/Object;

    .line 997
    .line 998
    check-cast v1, Landroidx/core/provider/CallbackWrapper;

    .line 999
    .line 1000
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 1001
    .line 1002
    .line 1003
    move-result v2

    .line 1004
    if-eqz v2, :cond_3fe

    .line 1005
    .line 1006
    new-instance v2, Ljava/lang/Thread;

    .line 1007
    .line 1008
    new-instance v3, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;

    .line 1009
    .line 1010
    const/16 v4, 0xb

    .line 1011
    .line 1012
    invoke-direct {v3, v1, v0, v4}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1013
    .line 1014
    .line 1015
    const-string v0, "ExoPlayer:WifiLockManager"

    .line 1016
    .line 1017
    invoke-direct {v2, v3, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 1018
    .line 1019
    .line 1020
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 1021
    .line 1022
    .line 1023
    :cond_3fe
    return-void

    .line 1024
    :pswitch_3ff
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 1025
    .line 1026
    check-cast v1, Lcoil/request/RequestService;

    .line 1027
    .line 1028
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 1029
    .line 1030
    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1031
    .line 1032
    monitor-enter v1

    .line 1033
    :try_start_408
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 1034
    .line 1035
    .line 1036
    move-result v0

    .line 1037
    if-eqz v0, :cond_41a

    .line 1038
    .line 1039
    iget-object v0, v1, Lcoil/request/RequestService;->hardwareBitmapService:Ljava/lang/Object;

    .line 1040
    .line 1041
    check-cast v0, Landroid/os/PowerManager$WakeLock;

    .line 1042
    .line 1043
    if-eqz v0, :cond_41a

    .line 1044
    .line 1045
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_417
    .catchall {:try_start_408 .. :try_end_417} :catchall_418

    .line 1046
    .line 1047
    .line 1048
    goto :goto_41a

    .line 1049
    :catchall_418
    move-exception v0

    .line 1050
    goto :goto_41c

    .line 1051
    :cond_41a
    :goto_41a
    monitor-exit v1

    .line 1052
    return-void

    .line 1053
    :goto_41c
    :try_start_41c
    monitor-exit v1
    :try_end_41d
    .catchall {:try_start_41c .. :try_end_41d} :catchall_418

    .line 1054
    throw v0

    .line 1055
    :pswitch_41e
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 1056
    .line 1057
    check-cast v1, Landroidx/media3/common/util/WakeLockManager;

    .line 1058
    .line 1059
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 1060
    .line 1061
    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 1062
    .line 1063
    iget-object v1, v1, Landroidx/media3/common/util/WakeLockManager;->wakeLockManagerInternal:Ljava/lang/Object;

    .line 1064
    .line 1065
    check-cast v1, Lcoil/request/RequestService;

    .line 1066
    .line 1067
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 1068
    .line 1069
    .line 1070
    move-result v3

    .line 1071
    if-eqz v3, :cond_43f

    .line 1072
    .line 1073
    new-instance v3, Ljava/lang/Thread;

    .line 1074
    .line 1075
    new-instance v4, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;

    .line 1076
    .line 1077
    invoke-direct {v4, v1, v0, v2}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1078
    .line 1079
    .line 1080
    const-string v0, "ExoPlayer:WakeLockManager"

    .line 1081
    .line 1082
    invoke-direct {v3, v4, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 1083
    .line 1084
    .line 1085
    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    .line 1086
    .line 1087
    .line 1088
    :cond_43f
    return-void

    .line 1089
    :pswitch_440
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 1090
    .line 1091
    check-cast v1, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;

    .line 1092
    .line 1093
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 1094
    .line 1095
    check-cast v0, Landroid/content/Context;

    .line 1096
    .line 1097
    iget-object v1, v1, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 1098
    .line 1099
    check-cast v1, Landroidx/media3/common/util/NetworkTypeObserver;

    .line 1100
    .line 1101
    const-string v3, "connectivity"

    .line 1102
    .line 1103
    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 1104
    .line 1105
    .line 1106
    move-result-object v3

    .line 1107
    check-cast v3, Landroid/net/ConnectivityManager;

    .line 1108
    .line 1109
    const/4 v4, 0x5

    .line 1110
    if-nez v3, :cond_459

    .line 1111
    .line 1112
    :catch_457
    :cond_457
    const/4 v2, 0x0

    .line 1113
    goto :goto_499

    .line 1114
    :cond_459
    :try_start_459
    invoke-virtual {v3}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    .line 1115
    .line 1116
    .line 1117
    move-result-object v3
    :try_end_45d
    .catch Ljava/lang/SecurityException; {:try_start_459 .. :try_end_45d} :catch_457

    .line 1118
    if-eqz v3, :cond_498

    .line 1119
    .line 1120
    invoke-virtual {v3}, Landroid/net/NetworkInfo;->isConnected()Z

    .line 1121
    .line 1122
    .line 1123
    move-result v5

    .line 1124
    if-nez v5, :cond_466

    .line 1125
    .line 1126
    goto :goto_498

    .line 1127
    :cond_466
    invoke-virtual {v3}, Landroid/net/NetworkInfo;->getType()I

    .line 1128
    .line 1129
    .line 1130
    move-result v5

    .line 1131
    const/4 v6, 0x2

    .line 1132
    const/4 v7, 0x6

    .line 1133
    if-eqz v5, :cond_483

    .line 1134
    .line 1135
    const/4 v8, 0x1

    .line 1136
    if-eq v5, v8, :cond_481

    .line 1137
    .line 1138
    const/4 v8, 0x4

    .line 1139
    if-eq v5, v8, :cond_484

    .line 1140
    .line 1141
    if-eq v5, v4, :cond_484

    .line 1142
    .line 1143
    if-eq v5, v7, :cond_47f

    .line 1144
    .line 1145
    if-eq v5, v2, :cond_47d

    .line 1146
    .line 1147
    const/16 v2, 0x8

    .line 1148
    .line 1149
    goto :goto_499

    .line 1150
    :cond_47d
    const/4 v2, 0x7

    .line 1151
    goto :goto_499

    .line 1152
    :cond_47f
    :pswitch_47f
    move v2, v4

    .line 1153
    goto :goto_499

    .line 1154
    :cond_481
    :pswitch_481
    move v2, v6

    .line 1155
    goto :goto_499

    .line 1156
    :cond_483
    const/4 v8, 0x4

    .line 1157
    :cond_484
    invoke-virtual {v3}, Landroid/net/NetworkInfo;->getSubtype()I

    .line 1158
    .line 1159
    .line 1160
    move-result v3

    .line 1161
    packed-switch v3, :pswitch_data_5a6

    .line 1162
    .line 1163
    .line 1164
    :pswitch_48b
    move v2, v7

    .line 1165
    goto :goto_499

    .line 1166
    :pswitch_48d
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1167
    .line 1168
    const/16 v5, 0x1d

    .line 1169
    .line 1170
    if-lt v3, v5, :cond_457

    .line 1171
    .line 1172
    goto :goto_499

    .line 1173
    :pswitch_494
    move v2, v8

    .line 1174
    goto :goto_499

    .line 1175
    :pswitch_496
    const/4 v2, 0x3

    .line 1176
    goto :goto_499

    .line 1177
    :cond_498
    :goto_498
    const/4 v2, 0x1

    .line 1178
    :goto_499
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1179
    .line 1180
    const/16 v5, 0x1f

    .line 1181
    .line 1182
    if-lt v3, v5, :cond_4be

    .line 1183
    .line 1184
    if-ne v2, v4, :cond_4be

    .line 1185
    .line 1186
    :try_start_4a1
    const-string v2, "phone"

    .line 1187
    .line 1188
    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 1189
    .line 1190
    .line 1191
    move-result-object v0

    .line 1192
    check-cast v0, Landroid/telephony/TelephonyManager;

    .line 1193
    .line 1194
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1195
    .line 1196
    .line 1197
    new-instance v2, Landroidx/media3/common/util/NetworkTypeObserver$Api31$DisplayInfoCallback;

    .line 1198
    .line 1199
    invoke-direct {v2, v1}, Landroidx/media3/common/util/NetworkTypeObserver$Api31$DisplayInfoCallback;-><init>(Landroidx/media3/common/util/NetworkTypeObserver;)V

    .line 1200
    .line 1201
    .line 1202
    iget-object v3, v1, Landroidx/media3/common/util/NetworkTypeObserver;->backgroundExecutor:Ljava/util/concurrent/Executor;

    .line 1203
    .line 1204
    invoke-static {v0, v3, v2}, Landroidx/core/view/DisplayCompat$$ExternalSyntheticApiModelOutline0;->m(Landroid/telephony/TelephonyManager;Ljava/util/concurrent/Executor;Landroidx/media3/common/util/NetworkTypeObserver$Api31$DisplayInfoCallback;)V

    .line 1205
    .line 1206
    .line 1207
    invoke-static {v0, v2}, Landroidx/core/view/DisplayCompat$$ExternalSyntheticApiModelOutline0;->m(Landroid/telephony/TelephonyManager;Landroidx/media3/common/util/NetworkTypeObserver$Api31$DisplayInfoCallback;)V
    :try_end_4b9
    .catch Ljava/lang/RuntimeException; {:try_start_4a1 .. :try_end_4b9} :catch_4ba

    .line 1208
    .line 1209
    .line 1210
    goto :goto_4c1

    .line 1211
    :catch_4ba
    invoke-virtual {v1, v4}, Landroidx/media3/common/util/NetworkTypeObserver;->updateNetworkType(I)V

    .line 1212
    .line 1213
    .line 1214
    goto :goto_4c1

    .line 1215
    :cond_4be
    invoke-virtual {v1, v2}, Landroidx/media3/common/util/NetworkTypeObserver;->updateNetworkType(I)V

    .line 1216
    .line 1217
    .line 1218
    :goto_4c1
    return-void

    .line 1219
    :pswitch_4c2
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 1220
    .line 1221
    check-cast v1, Landroidx/media3/common/util/NetworkTypeObserver;

    .line 1222
    .line 1223
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 1224
    .line 1225
    check-cast v0, Landroid/content/Context;

    .line 1226
    .line 1227
    new-instance v2, Landroid/content/IntentFilter;

    .line 1228
    .line 1229
    invoke-direct {v2}, Landroid/content/IntentFilter;-><init>()V

    .line 1230
    .line 1231
    .line 1232
    const-string v3, "android.net.conn.CONNECTIVITY_CHANGE"

    .line 1233
    .line 1234
    invoke-virtual {v2, v3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 1235
    .line 1236
    .line 1237
    new-instance v3, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;

    .line 1238
    .line 1239
    const/4 v4, 0x0

    .line 1240
    invoke-direct {v3, v1, v4}, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;-><init>(Ljava/lang/Object;B)V

    .line 1241
    .line 1242
    .line 1243
    invoke-virtual {v0, v3, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 1244
    .line 1245
    .line 1246
    return-void

    .line 1247
    :pswitch_4de
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 1248
    .line 1249
    check-cast v1, Landroidx/compose/ui/node/RulerTrackingMap;

    .line 1250
    .line 1251
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 1252
    .line 1253
    check-cast v0, Landroidx/media3/exoplayer/ExoPlayerImpl$$ExternalSyntheticLambda17;

    .line 1254
    .line 1255
    iget-object v2, v1, Landroidx/compose/ui/node/RulerTrackingMap;->newRulers:Ljava/lang/Object;

    .line 1256
    .line 1257
    invoke-virtual {v0, v2}, Landroidx/media3/exoplayer/ExoPlayerImpl$$ExternalSyntheticLambda17;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1258
    .line 1259
    .line 1260
    move-result-object v0

    .line 1261
    iput-object v0, v1, Landroidx/compose/ui/node/RulerTrackingMap;->newRulers:Ljava/lang/Object;

    .line 1262
    .line 1263
    new-instance v2, Landroidx/media3/common/util/BackgroundThreadStateHandler$$ExternalSyntheticLambda0;

    .line 1264
    .line 1265
    const/4 v5, 0x1

    .line 1266
    invoke-direct {v2, v1, v0, v5}, Landroidx/media3/common/util/BackgroundThreadStateHandler$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/ui/node/RulerTrackingMap;Ljava/lang/Object;B)V

    .line 1267
    .line 1268
    .line 1269
    iget-object v0, v1, Landroidx/compose/ui/node/RulerTrackingMap;->values:Ljava/lang/Object;

    .line 1270
    .line 1271
    check-cast v0, Landroidx/media3/common/util/SystemHandlerWrapper;

    .line 1272
    .line 1273
    iget-object v1, v0, Landroidx/media3/common/util/SystemHandlerWrapper;->handler:Landroid/os/Handler;

    .line 1274
    .line 1275
    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    .line 1276
    .line 1277
    .line 1278
    move-result-object v1

    .line 1279
    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 1280
    .line 1281
    .line 1282
    move-result-object v1

    .line 1283
    invoke-virtual {v1}, Ljava/lang/Thread;->isAlive()Z

    .line 1284
    .line 1285
    .line 1286
    move-result v1

    .line 1287
    if-nez v1, :cond_509

    .line 1288
    .line 1289
    goto :goto_50c

    .line 1290
    :cond_509
    invoke-virtual {v0, v2}, Landroidx/media3/common/util/SystemHandlerWrapper;->post(Ljava/lang/Runnable;)V

    .line 1291
    .line 1292
    .line 1293
    :goto_50c
    return-void

    .line 1294
    :pswitch_50d
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 1295
    .line 1296
    check-cast v1, Landroid/content/Context;

    .line 1297
    .line 1298
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 1299
    .line 1300
    check-cast v0, Landroidx/media3/common/util/ConditionVariable;

    .line 1301
    .line 1302
    const-string v2, "audio"

    .line 1303
    .line 1304
    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 1305
    .line 1306
    .line 1307
    move-result-object v1

    .line 1308
    check-cast v1, Landroid/media/AudioManager;

    .line 1309
    .line 1310
    sput-object v1, Lcoil/util/-Lifecycles;->audioManager:Landroid/media/AudioManager;

    .line 1311
    .line 1312
    invoke-virtual {v0}, Landroidx/media3/common/util/ConditionVariable;->open()Z

    .line 1313
    .line 1314
    .line 1315
    return-void

    .line 1316
    :pswitch_523
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 1317
    .line 1318
    check-cast v1, Landroidx/core/provider/CallbackWrapper;

    .line 1319
    .line 1320
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 1321
    .line 1322
    check-cast v0, Landroid/graphics/Typeface;

    .line 1323
    .line 1324
    iget-object v1, v1, Landroidx/core/provider/CallbackWrapper;->mCallback:Ljava/lang/Object;

    .line 1325
    .line 1326
    check-cast v1, Lkotlinx/coroutines/CancellableContinuationImpl;

    .line 1327
    .line 1328
    invoke-virtual {v1, v0}, Lkotlinx/coroutines/CancellableContinuationImpl;->resumeWith(Ljava/lang/Object;)V

    .line 1329
    .line 1330
    .line 1331
    return-void

    .line 1332
    :pswitch_533
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 1333
    .line 1334
    check-cast v1, Landroidx/compose/ui/platform/WrappedComposition;

    .line 1335
    .line 1336
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 1337
    .line 1338
    check-cast v0, Landroidx/lifecycle/Lifecycle;

    .line 1339
    .line 1340
    iget-boolean v2, v1, Landroidx/compose/ui/platform/WrappedComposition;->disposed:Z

    .line 1341
    .line 1342
    if-nez v2, :cond_544

    .line 1343
    .line 1344
    iput-object v0, v1, Landroidx/compose/ui/platform/WrappedComposition;->addedToLifecycle:Landroidx/lifecycle/Lifecycle;

    .line 1345
    .line 1346
    invoke-virtual {v0, v1}, Landroidx/lifecycle/Lifecycle;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 1347
    .line 1348
    .line 1349
    :cond_544
    return-void

    .line 1350
    :pswitch_545
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 1351
    .line 1352
    check-cast v1, Landroidx/compose/ui/contentcapture/AndroidContentCaptureManager;

    .line 1353
    .line 1354
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 1355
    .line 1356
    check-cast v0, Landroid/util/LongSparseArray;

    .line 1357
    .line 1358
    invoke-static {v1, v0}, Landroidx/work/impl/background/systemjob/SystemJobService$Api31Impl;->doTranslation(Landroidx/compose/ui/contentcapture/AndroidContentCaptureManager;Landroid/util/LongSparseArray;)V

    .line 1359
    .line 1360
    .line 1361
    return-void

    .line 1362
    :pswitch_551
    iget-object v1, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$0:Ljava/lang/Object;

    .line 1363
    .line 1364
    check-cast v1, Lcom/ipvio/stream/MainActivity;

    .line 1365
    .line 1366
    iget-object v0, v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda11;->f$1:Ljava/lang/Object;

    .line 1367
    .line 1368
    check-cast v0, Landroidx/activity/OnBackPressedDispatcher;

    .line 1369
    .line 1370
    invoke-virtual {v1}, Landroidx/activity/ComponentActivity;->getLifecycle()Landroidx/lifecycle/Lifecycle;

    .line 1371
    .line 1372
    .line 1373
    move-result-object v2

    .line 1374
    new-instance v3, Landroidx/core/view/MenuHostHelper$$ExternalSyntheticLambda0;

    .line 1375
    .line 1376
    const/4 v5, 0x1

    .line 1377
    invoke-direct {v3, v0, v1, v5}, Landroidx/core/view/MenuHostHelper$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1378
    .line 1379
    .line 1380
    invoke-virtual {v2, v3}, Landroidx/lifecycle/Lifecycle;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 1381
    .line 1382
    .line 1383
    return-void

    .line 1384
    nop

    .line 1385
    :pswitch_data_568
    .packed-switch 0x0
        :pswitch_551
        :pswitch_545
        :pswitch_533
        :pswitch_523
        :pswitch_50d
        :pswitch_4de
        :pswitch_4c2
        :pswitch_440
        :pswitch_41e
        :pswitch_3ff
        :pswitch_3db
        :pswitch_3bc
        :pswitch_2ae
        :pswitch_2a0
        :pswitch_292
        :pswitch_284
        :pswitch_276
        :pswitch_268
        :pswitch_23b
        :pswitch_218
        :pswitch_202
        :pswitch_1e7
        :pswitch_1a4
        :pswitch_185
        :pswitch_164
        :pswitch_145
        :pswitch_139
        :pswitch_12d
        :pswitch_20
    .end packed-switch

    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    :pswitch_data_5a6
    .packed-switch 0x1
        :pswitch_496
        :pswitch_496
        :pswitch_494
        :pswitch_494
        :pswitch_494
        :pswitch_494
        :pswitch_494
        :pswitch_494
        :pswitch_494
        :pswitch_494
        :pswitch_494
        :pswitch_494
        :pswitch_47f
        :pswitch_494
        :pswitch_494
        :pswitch_48b
        :pswitch_494
        :pswitch_481
        :pswitch_48b
        :pswitch_48d
    .end packed-switch
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
    .line 2190
    .line 2191
    .line 2192
    .line 2193
    .line 2194
    .line 2195
    .line 2196
    .line 2197
    .line 2198
    .line 2199
    .line 2200
    .line 2201
    .line 2202
    .line 2203
    .line 2204
    .line 2205
    .line 2206
    .line 2207
    .line 2208
    .line 2209
    .line 2210
    .line 2211
    .line 2212
    .line 2213
    .line 2214
    .line 2215
    .line 2216
    .line 2217
    .line 2218
    .line 2219
    .line 2220
    .line 2221
    .line 2222
    .line 2223
    .line 2224
    .line 2225
    .line 2226
    .line 2227
    .line 2228
    .line 2229
    .line 2230
    .line 2231
    .line 2232
    .line 2233
    .line 2234
    .line 2235
    .line 2236
    .line 2237
    .line 2238
    .line 2239
    .line 2240
    .line 2241
    .line 2242
    .line 2243
    .line 2244
    .line 2245
    .line 2246
    .line 2247
    .line 2248
    .line 2249
    .line 2250
    .line 2251
    .line 2252
    .line 2253
    .line 2254
    .line 2255
    .line 2256
    .line 2257
    .line 2258
    .line 2259
    .line 2260
    .line 2261
    .line 2262
    .line 2263
    .line 2264
    .line 2265
    .line 2266
    .line 2267
    .line 2268
    .line 2269
    .line 2270
    .line 2271
    .line 2272
    .line 2273
    .line 2274
    .line 2275
    .line 2276
    .line 2277
    .line 2278
    .line 2279
    .line 2280
    .line 2281
    .line 2282
    .line 2283
    .line 2284
    .line 2285
    .line 2286
    .line 2287
    .line 2288
    .line 2289
    .line 2290
    .line 2291
    .line 2292
    .line 2293
    .line 2294
    .line 2295
    .line 2296
    .line 2297
    .line 2298
    .line 2299
    .line 2300
    .line 2301
    .line 2302
    .line 2303
    .line 2304
    .line 2305
    .line 2306
    .line 2307
    .line 2308
    .line 2309
    .line 2310
    .line 2311
    .line 2312
    .line 2313
    .line 2314
    .line 2315
    .line 2316
    .line 2317
    .line 2318
    .line 2319
    .line 2320
    .line 2321
    .line 2322
    .line 2323
    .line 2324
    .line 2325
    .line 2326
    .line 2327
    .line 2328
    .line 2329
    .line 2330
    .line 2331
    .line 2332
    .line 2333
    .line 2334
    .line 2335
    .line 2336
    .line 2337
    .line 2338
    .line 2339
    .line 2340
    .line 2341
    .line 2342
    .line 2343
    .line 2344
    .line 2345
    .line 2346
    .line 2347
    .line 2348
    .line 2349
    .line 2350
    .line 2351
    .line 2352
    .line 2353
    .line 2354
    .line 2355
    .line 2356
    .line 2357
    .line 2358
    .line 2359
    .line 2360
    .line 2361
    .line 2362
    .line 2363
    .line 2364
    .line 2365
    .line 2366
    .line 2367
    .line 2368
    .line 2369
    .line 2370
    .line 2371
    .line 2372
    .line 2373
    .line 2374
    .line 2375
    .line 2376
    .line 2377
    .line 2378
    .line 2379
    .line 2380
    .line 2381
    .line 2382
    .line 2383
    .line 2384
    .line 2385
    .line 2386
    .line 2387
    .line 2388
    .line 2389
    .line 2390
    .line 2391
    .line 2392
    .line 2393
    .line 2394
    .line 2395
    .line 2396
    .line 2397
    .line 2398
    .line 2399
    .line 2400
    .line 2401
    .line 2402
    .line 2403
    .line 2404
    .line 2405
    .line 2406
    .line 2407
    .line 2408
    .line 2409
    .line 2410
    .line 2411
    .line 2412
    .line 2413
    .line 2414
    .line 2415
    .line 2416
    .line 2417
    .line 2418
    .line 2419
    .line 2420
    .line 2421
    .line 2422
    .line 2423
    .line 2424
    .line 2425
    .line 2426
    .line 2427
    .line 2428
    .line 2429
    .line 2430
    .line 2431
    .line 2432
    .line 2433
    .line 2434
    .line 2435
    .line 2436
    .line 2437
    .line 2438
    .line 2439
    .line 2440
    .line 2441
    .line 2442
    .line 2443
    .line 2444
    .line 2445
    .line 2446
    .line 2447
    .line 2448
    .line 2449
    .line 2450
    .line 2451
    .line 2452
    .line 2453
    .line 2454
    .line 2455
    .line 2456
    .line 2457
    .line 2458
    .line 2459
    .line 2460
    .line 2461
    .line 2462
    .line 2463
    .line 2464
    .line 2465
    .line 2466
    .line 2467
    .line 2468
    .line 2469
    .line 2470
    .line 2471
    .line 2472
    .line 2473
    .line 2474
    .line 2475
    .line 2476
    .line 2477
    .line 2478
    .line 2479
    .line 2480
    .line 2481
    .line 2482
    .line 2483
    .line 2484
    .line 2485
    .line 2486
    .line 2487
    .line 2488
    .line 2489
    .line 2490
    .line 2491
    .line 2492
    .line 2493
    .line 2494
    .line 2495
    .line 2496
    .line 2497
    .line 2498
    .line 2499
    .line 2500
    .line 2501
    .line 2502
    .line 2503
    .line 2504
    .line 2505
    .line 2506
    .line 2507
    .line 2508
    .line 2509
    .line 2510
    .line 2511
    .line 2512
    .line 2513
    .line 2514
    .line 2515
    .line 2516
    .line 2517
    .line 2518
    .line 2519
    .line 2520
    .line 2521
    .line 2522
    .line 2523
    .line 2524
    .line 2525
    .line 2526
    .line 2527
    .line 2528
    .line 2529
    .line 2530
    .line 2531
    .line 2532
    .line 2533
    .line 2534
    .line 2535
    .line 2536
    .line 2537
    .line 2538
    .line 2539
    .line 2540
    .line 2541
    .line 2542
    .line 2543
    .line 2544
    .line 2545
    .line 2546
    .line 2547
    .line 2548
    .line 2549
    .line 2550
    .line 2551
    .line 2552
    .line 2553
    .line 2554
    .line 2555
    .line 2556
    .line 2557
    .line 2558
    .line 2559
    .line 2560
    .line 2561
    .line 2562
    .line 2563
    .line 2564
    .line 2565
    .line 2566
    .line 2567
    .line 2568
    .line 2569
    .line 2570
    .line 2571
    .line 2572
    .line 2573
    .line 2574
    .line 2575
    .line 2576
    .line 2577
    .line 2578
    .line 2579
    .line 2580
    .line 2581
    .line 2582
    .line 2583
    .line 2584
    .line 2585
    .line 2586
    .line 2587
    .line 2588
    .line 2589
    .line 2590
    .line 2591
    .line 2592
    .line 2593
    .line 2594
    .line 2595
    .line 2596
    .line 2597
    .line 2598
    .line 2599
    .line 2600
    .line 2601
    .line 2602
    .line 2603
    .line 2604
    .line 2605
    .line 2606
    .line 2607
    .line 2608
    .line 2609
    .line 2610
    .line 2611
    .line 2612
    .line 2613
    .line 2614
    .line 2615
    .line 2616
    .line 2617
    .line 2618
    .line 2619
    .line 2620
    .line 2621
    .line 2622
    .line 2623
    .line 2624
    .line 2625
    .line 2626
    .line 2627
    .line 2628
    .line 2629
    .line 2630
    .line 2631
    .line 2632
    .line 2633
    .line 2634
    .line 2635
    .line 2636
    .line 2637
    .line 2638
    .line 2639
    .line 2640
    .line 2641
    .line 2642
    .line 2643
    .line 2644
    .line 2645
    .line 2646
    .line 2647
    .line 2648
    .line 2649
    .line 2650
    .line 2651
    .line 2652
    .line 2653
    .line 2654
    .line 2655
    .line 2656
    .line 2657
    .line 2658
    .line 2659
    .line 2660
    .line 2661
    .line 2662
    .line 2663
    .line 2664
    .line 2665
    .line 2666
    .line 2667
    .line 2668
    .line 2669
    .line 2670
    .line 2671
    .line 2672
    .line 2673
    .line 2674
    .line 2675
    .line 2676
    .line 2677
    .line 2678
    .line 2679
    .line 2680
    .line 2681
    .line 2682
    .line 2683
    .line 2684
    .line 2685
    .line 2686
    .line 2687
    .line 2688
    .line 2689
    .line 2690
    .line 2691
    .line 2692
    .line 2693
    .line 2694
    .line 2695
    .line 2696
    .line 2697
    .line 2698
    .line 2699
    .line 2700
    .line 2701
    .line 2702
    .line 2703
    .line 2704
    .line 2705
    .line 2706
    .line 2707
    .line 2708
    .line 2709
    .line 2710
    .line 2711
    .line 2712
    .line 2713
    .line 2714
    .line 2715
    .line 2716
    .line 2717
    .line 2718
    .line 2719
    .line 2720
    .line 2721
    .line 2722
    .line 2723
    .line 2724
    .line 2725
    .line 2726
    .line 2727
    .line 2728
    .line 2729
    .line 2730
    .line 2731
    .line 2732
    .line 2733
    .line 2734
    .line 2735
    .line 2736
    .line 2737
    .line 2738
    .line 2739
    .line 2740
    .line 2741
    .line 2742
    .line 2743
    .line 2744
    .line 2745
    .line 2746
    .line 2747
    .line 2748
    .line 2749
    .line 2750
    .line 2751
    .line 2752
    .line 2753
    .line 2754
    .line 2755
    .line 2756
    .line 2757
    .line 2758
    .line 2759
    .line 2760
    .line 2761
    .line 2762
    .line 2763
    .line 2764
    .line 2765
    .line 2766
    .line 2767
    .line 2768
    .line 2769
    .line 2770
    .line 2771
    .line 2772
    .line 2773
    .line 2774
    .line 2775
    .line 2776
    .line 2777
    .line 2778
    .line 2779
    .line 2780
    .line 2781
    .line 2782
    .line 2783
    .line 2784
    .line 2785
    .line 2786
    .line 2787
    .line 2788
    .line 2789
    .line 2790
    .line 2791
    .line 2792
    .line 2793
    .line 2794
    .line 2795
    .line 2796
    .line 2797
    .line 2798
    .line 2799
    .line 2800
    .line 2801
    .line 2802
    .line 2803
    .line 2804
    .line 2805
    .line 2806
    .line 2807
    .line 2808
    .line 2809
    .line 2810
    .line 2811
    .line 2812
    .line 2813
    .line 2814
    .line 2815
    .line 2816
    .line 2817
    .line 2818
    .line 2819
    .line 2820
    .line 2821
    .line 2822
    .line 2823
    .line 2824
    .line 2825
    .line 2826
    .line 2827
    .line 2828
    .line 2829
    .line 2830
    .line 2831
    .line 2832
    .line 2833
    .line 2834
    .line 2835
    .line 2836
    .line 2837
    .line 2838
    .line 2839
    .line 2840
    .line 2841
    .line 2842
    .line 2843
    .line 2844
    .line 2845
    .line 2846
    .line 2847
    .line 2848
    .line 2849
    .line 2850
    .line 2851
    .line 2852
    .line 2853
    .line 2854
    .line 2855
    .line 2856
    .line 2857
    .line 2858
    .line 2859
    .line 2860
    .line 2861
    .line 2862
    .line 2863
    .line 2864
    .line 2865
    .line 2866
    .line 2867
    .line 2868
    .line 2869
    .line 2870
    .line 2871
    .line 2872
    .line 2873
    .line 2874
    .line 2875
    .line 2876
    .line 2877
    .line 2878
    .line 2879
    .line 2880
    .line 2881
    .line 2882
    .line 2883
    .line 2884
    .line 2885
    .line 2886
    .line 2887
    .line 2888
    .line 2889
    .line 2890
    .line 2891
    .line 2892
    .line 2893
    .line 2894
    .line 2895
    .line 2896
    .line 2897
    .line 2898
    .line 2899
    .line 2900
    .line 2901
    .line 2902
    .line 2903
    .line 2904
    .line 2905
    .line 2906
    .line 2907
    .line 2908
    .line 2909
    .line 2910
    .line 2911
    .line 2912
    .line 2913
    .line 2914
    .line 2915
    .line 2916
    .line 2917
    .line 2918
    .line 2919
    .line 2920
    .line 2921
    .line 2922
    .line 2923
    .line 2924
    .line 2925
    .line 2926
    .line 2927
    .line 2928
    .line 2929
    .line 2930
    .line 2931
    .line 2932
    .line 2933
    .line 2934
    .line 2935
    .line 2936
    .line 2937
    .line 2938
    .line 2939
    .line 2940
    .line 2941
    .line 2942
    .line 2943
    .line 2944
    .line 2945
    .line 2946
    .line 2947
    .line 2948
    .line 2949
    .line 2950
    .line 2951
    .line 2952
    .line 2953
    .line 2954
    .line 2955
    .line 2956
    .line 2957
    .line 2958
    .line 2959
    .line 2960
    .line 2961
    .line 2962
    .line 2963
    .line 2964
    .line 2965
    .line 2966
    .line 2967
    .line 2968
    .line 2969
    .line 2970
.end method
