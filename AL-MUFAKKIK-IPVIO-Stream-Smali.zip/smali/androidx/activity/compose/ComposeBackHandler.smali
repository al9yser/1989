.class public final Landroidx/activity/compose/ComposeBackHandler;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"


# instance fields
.field public currentOnBackCompleted:Lkotlin/jvm/functions/Function0;

.field public final navigationEventHandler:Landroidx/activity/compose/internal/BackHandlerCompat$navigationEventHandler$1;

.field public final onBackPressedCallback:Landroidx/activity/OnBackPressedDispatcherKt$addCallback$callback$1;


# direct methods
.method public constructor <init>(Landroidx/activity/compose/BackHandlerInfo;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroidx/activity/OnBackPressedDispatcherKt$addCallback$callback$1;

    .line 5
    .line 6
    invoke-direct {v0, p0}, Landroidx/activity/OnBackPressedDispatcherKt$addCallback$callback$1;-><init>(Landroidx/activity/compose/ComposeBackHandler;)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Landroidx/activity/compose/ComposeBackHandler;->onBackPressedCallback:Landroidx/activity/OnBackPressedDispatcherKt$addCallback$callback$1;

    .line 10
    .line 11
    new-instance v0, Landroidx/activity/compose/internal/BackHandlerCompat$navigationEventHandler$1;

    .line 12
    .line 13
    invoke-direct {v0, p0, p1}, Landroidx/activity/compose/internal/BackHandlerCompat$navigationEventHandler$1;-><init>(Landroidx/activity/compose/ComposeBackHandler;Landroidx/activity/compose/BackHandlerInfo;)V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Landroidx/activity/compose/ComposeBackHandler;->navigationEventHandler:Landroidx/activity/compose/internal/BackHandlerCompat$navigationEventHandler$1;

    .line 17
    .line 18
    return-void
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
.end method


# virtual methods
.method public final setBackEnabled(Z)V
    .registers 8

    .line 1
    iget-object v0, p0, Landroidx/activity/compose/ComposeBackHandler;->onBackPressedCallback:Landroidx/activity/OnBackPressedDispatcherKt$addCallback$callback$1;

    .line 2
    .line 3
    iput-boolean p1, v0, Landroidx/activity/OnBackPressedDispatcherKt$addCallback$callback$1;->isEnabled:Z

    .line 4
    .line 5
    iget-object v0, v0, Landroidx/activity/OnBackPressedDispatcherKt$addCallback$callback$1;->eventHandlers:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x0

    .line 12
    move v3, v2

    .line 13
    :goto_c
    if-ge v3, v1, :cond_23

    .line 14
    .line 15
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    add-int/lit8 v3, v3, 0x1

    .line 20
    .line 21
    check-cast v4, Landroidx/activity/OnBackPressedCallback$OnBackPressedEventHandler;

    .line 22
    .line 23
    iget-boolean v5, v4, Landroidx/activity/OnBackPressedCallback$OnBackPressedEventHandler;->isLifecycleActive:Z

    .line 24
    .line 25
    if-eqz v5, :cond_1e

    .line 26
    .line 27
    if-eqz p1, :cond_1e

    .line 28
    .line 29
    const/4 v5, 0x1

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    move v5, v2

    .line 32
    :goto_1f
    invoke-virtual {v4, v5}, Landroidx/navigationevent/NavigationEventHandler;->setBackEnabled(Z)V

    .line 33
    .line 34
    .line 35
    goto :goto_c

    .line 36
    :cond_23
    iget-object p0, p0, Landroidx/activity/compose/ComposeBackHandler;->navigationEventHandler:Landroidx/activity/compose/internal/BackHandlerCompat$navigationEventHandler$1;

    .line 37
    .line 38
    invoke-virtual {p0, p1}, Landroidx/navigationevent/NavigationEventHandler;->setBackEnabled(Z)V

    .line 39
    .line 40
    .line 41
    return-void
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
.end method
