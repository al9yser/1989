.class public abstract Landroidx/arch/core/internal/SafeIterableMap$SupportRemove;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"


# virtual methods
.method public abstract supportRemove(Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
.end method
