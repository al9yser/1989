.class public final Landroidx/collection/ArrayMap$EntrySet;
.super Ljava/util/AbstractSet;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic this$0:Ljava/util/Map;


# direct methods
.method public synthetic constructor <init>(Ljava/util/Map;B)V
    .registers 3

    .line 1
    iput-byte p2, p0, Landroidx/collection/ArrayMap$EntrySet;->$r8$classId:B

    .line 2
    .line 3
    iput-object p1, p0, Landroidx/collection/ArrayMap$EntrySet;->this$0:Ljava/util/Map;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/util/AbstractSet;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
.end method


# virtual methods
.method public clear()V
    .registers 3

    .line 1
    iget-byte v0, p0, Landroidx/collection/ArrayMap$EntrySet;->$r8$classId:B

    .line 2
    .line 3
    iget-object v1, p0, Landroidx/collection/ArrayMap$EntrySet;->this$0:Ljava/util/Map;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_18

    .line 6
    .line 7
    .line 8
    invoke-super {p0}, Ljava/util/AbstractCollection;->clear()V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_b
    check-cast v1, Lcom/google/common/collect/CompactHashMap;

    .line 13
    .line 14
    invoke-virtual {v1}, Lcom/google/common/collect/CompactHashMap;->clear()V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_11
    check-cast v1, Lcom/google/common/collect/CompactHashMap;

    .line 19
    .line 20
    invoke-virtual {v1}, Lcom/google/common/collect/CompactHashMap;->clear()V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    nop

    .line 25
    :pswitch_data_18
    .packed-switch 0x1
        :pswitch_11
        :pswitch_b
    .end packed-switch
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
.end method

.method public contains(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    iget-byte v0, p0, Landroidx/collection/ArrayMap$EntrySet;->$r8$classId:B

    .line 2
    .line 3
    iget-object v1, p0, Landroidx/collection/ArrayMap$EntrySet;->this$0:Ljava/util/Map;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_4a

    .line 6
    .line 7
    .line 8
    invoke-super {p0, p1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0

    .line 13
    :pswitch_c
    check-cast v1, Lcom/google/common/collect/CompactHashMap;

    .line 14
    .line 15
    invoke-virtual {v1, p1}, Lcom/google/common/collect/CompactHashMap;->containsKey(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :pswitch_13
    check-cast v1, Lcom/google/common/collect/CompactHashMap;

    .line 21
    .line 22
    invoke-virtual {v1}, Lcom/google/common/collect/CompactHashMap;->delegateOrNull()Ljava/util/Map;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    if-eqz p0, :cond_24

    .line 27
    .line 28
    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    invoke-interface {p0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result p0

    .line 36
    goto :goto_48

    .line 37
    :cond_24
    instance-of p0, p1, Ljava/util/Map$Entry;

    .line 38
    .line 39
    if-eqz p0, :cond_47

    .line 40
    .line 41
    check-cast p1, Ljava/util/Map$Entry;

    .line 42
    .line 43
    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    invoke-virtual {v1, p0}, Lcom/google/common/collect/CompactHashMap;->indexOf(Ljava/lang/Object;)I

    .line 48
    .line 49
    .line 50
    move-result p0

    .line 51
    const/4 v0, -0x1

    .line 52
    if-eq p0, v0, :cond_47

    .line 53
    .line 54
    invoke-virtual {v1}, Lcom/google/common/collect/CompactHashMap;->requireValues()[Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    aget-object p0, v0, p0

    .line 59
    .line 60
    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    invoke-static {p0, p1}, Lkotlin/math/MathKt;->equal(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result p0

    .line 68
    if-eqz p0, :cond_47

    .line 69
    .line 70
    const/4 p0, 0x1

    .line 71
    goto :goto_48

    .line 72
    :cond_47
    const/4 p0, 0x0

    .line 73
    :goto_48
    return p0

    .line 74
    nop

    .line 75
    :pswitch_data_4a
    .packed-switch 0x1
        :pswitch_13
        :pswitch_c
    .end packed-switch
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 3

    .line 1
    iget-byte v0, p0, Landroidx/collection/ArrayMap$EntrySet;->$r8$classId:B

    .line 2
    .line 3
    iget-object p0, p0, Landroidx/collection/ArrayMap$EntrySet;->this$0:Ljava/util/Map;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_42

    .line 6
    .line 7
    .line 8
    check-cast p0, Lcom/google/common/collect/CompactHashMap;

    .line 9
    .line 10
    invoke-virtual {p0}, Lcom/google/common/collect/CompactHashMap;->delegateOrNull()Ljava/util/Map;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    if-eqz v0, :cond_18

    .line 15
    .line 16
    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    goto :goto_1f

    .line 25
    :cond_18
    new-instance v0, Lcom/google/common/collect/CompactHashMap$1;

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/CompactHashMap$1;-><init>(Lcom/google/common/collect/CompactHashMap;B)V

    .line 29
    .line 30
    .line 31
    move-object p0, v0

    .line 32
    :goto_1f
    return-object p0

    .line 33
    :pswitch_20
    check-cast p0, Lcom/google/common/collect/CompactHashMap;

    .line 34
    .line 35
    invoke-virtual {p0}, Lcom/google/common/collect/CompactHashMap;->delegateOrNull()Ljava/util/Map;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    if-eqz v0, :cond_31

    .line 40
    .line 41
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    goto :goto_38

    .line 50
    :cond_31
    new-instance v0, Lcom/google/common/collect/CompactHashMap$1;

    .line 51
    .line 52
    const/4 v1, 0x1

    .line 53
    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/CompactHashMap$1;-><init>(Lcom/google/common/collect/CompactHashMap;B)V

    .line 54
    .line 55
    .line 56
    move-object p0, v0

    .line 57
    :goto_38
    return-object p0

    .line 58
    :pswitch_39
    new-instance v0, Landroidx/collection/ArrayMap$MapIterator;

    .line 59
    .line 60
    check-cast p0, Landroidx/collection/ArrayMap;

    .line 61
    .line 62
    invoke-direct {v0, p0}, Landroidx/collection/ArrayMap$MapIterator;-><init>(Landroidx/collection/ArrayMap;)V

    .line 63
    .line 64
    .line 65
    return-object v0

    .line 66
    nop

    .line 67
    :pswitch_data_42
    .packed-switch 0x0
        :pswitch_39
        :pswitch_20
    .end packed-switch
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
.end method

.method public remove(Ljava/lang/Object;)Z
    .registers 13

    .line 1
    iget-byte v0, p0, Landroidx/collection/ArrayMap$EntrySet;->$r8$classId:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    iget-object v3, p0, Landroidx/collection/ArrayMap$EntrySet;->this$0:Ljava/util/Map;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_7c

    .line 8
    .line 9
    .line 10
    invoke-super {p0, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    return p0

    .line 15
    :pswitch_e
    check-cast v3, Lcom/google/common/collect/CompactHashMap;

    .line 16
    .line 17
    invoke-virtual {v3}, Lcom/google/common/collect/CompactHashMap;->delegateOrNull()Ljava/util/Map;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    if-eqz p0, :cond_1f

    .line 22
    .line 23
    invoke-interface {p0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-interface {p0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    goto :goto_28

    .line 32
    :cond_1f
    invoke-virtual {v3, p1}, Lcom/google/common/collect/CompactHashMap;->removeHelper(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    sget-object p1, Lcom/google/common/collect/CompactHashMap;->NOT_FOUND:Ljava/lang/Object;

    .line 37
    .line 38
    if-eq p0, p1, :cond_28

    .line 39
    .line 40
    move v1, v2

    .line 41
    :cond_28
    :goto_28
    return v1

    .line 42
    :pswitch_29
    check-cast v3, Lcom/google/common/collect/CompactHashMap;

    .line 43
    .line 44
    invoke-virtual {v3}, Lcom/google/common/collect/CompactHashMap;->delegateOrNull()Ljava/util/Map;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    if-eqz p0, :cond_3a

    .line 49
    .line 50
    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    invoke-interface {p0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    goto :goto_7b

    .line 59
    :cond_3a
    instance-of p0, p1, Ljava/util/Map$Entry;

    .line 60
    .line 61
    if-eqz p0, :cond_7b

    .line 62
    .line 63
    check-cast p1, Ljava/util/Map$Entry;

    .line 64
    .line 65
    invoke-virtual {v3}, Lcom/google/common/collect/CompactHashMap;->needsAllocArrays()Z

    .line 66
    .line 67
    .line 68
    move-result p0

    .line 69
    if-eqz p0, :cond_47

    .line 70
    .line 71
    goto :goto_7b

    .line 72
    :cond_47
    invoke-virtual {v3}, Lcom/google/common/collect/CompactHashMap;->hashTableMask()I

    .line 73
    .line 74
    .line 75
    move-result v6

    .line 76
    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v5

    .line 84
    iget-object v7, v3, Lcom/google/common/collect/CompactHashMap;->table:Ljava/lang/Object;

    .line 85
    .line 86
    invoke-static {v7}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v3}, Lcom/google/common/collect/CompactHashMap;->requireEntries()[I

    .line 90
    .line 91
    .line 92
    move-result-object v8

    .line 93
    invoke-virtual {v3}, Lcom/google/common/collect/CompactHashMap;->requireKeys()[Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v9

    .line 97
    invoke-virtual {v3}, Lcom/google/common/collect/CompactHashMap;->requireValues()[Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v10

    .line 101
    invoke-static/range {v4 .. v10}, Lcom/google/common/collect/Maps;->remove(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;[I[Ljava/lang/Object;[Ljava/lang/Object;)I

    .line 102
    .line 103
    .line 104
    move-result p0

    .line 105
    const/4 p1, -0x1

    .line 106
    if-ne p0, p1, :cond_6c

    .line 107
    .line 108
    goto :goto_7b

    .line 109
    :cond_6c
    invoke-virtual {v3, p0, v6}, Lcom/google/common/collect/CompactHashMap;->moveLastEntry(II)V

    .line 110
    .line 111
    .line 112
    iget p0, v3, Lcom/google/common/collect/CompactHashMap;->size:I

    .line 113
    .line 114
    sub-int/2addr p0, v2

    .line 115
    iput p0, v3, Lcom/google/common/collect/CompactHashMap;->size:I

    .line 116
    .line 117
    iget p0, v3, Lcom/google/common/collect/CompactHashMap;->metadata:I

    .line 118
    .line 119
    add-int/lit8 p0, p0, 0x20

    .line 120
    .line 121
    iput p0, v3, Lcom/google/common/collect/CompactHashMap;->metadata:I

    .line 122
    .line 123
    move v1, v2

    .line 124
    :cond_7b
    :goto_7b
    return v1

    .line 125
    :pswitch_data_7c
    .packed-switch 0x1
        :pswitch_29
        :pswitch_e
    .end packed-switch
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
.end method

.method public final size()I
    .registers 2

    .line 1
    iget-byte v0, p0, Landroidx/collection/ArrayMap$EntrySet;->$r8$classId:B

    .line 2
    .line 3
    iget-object p0, p0, Landroidx/collection/ArrayMap$EntrySet;->this$0:Ljava/util/Map;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_1a

    .line 6
    .line 7
    .line 8
    check-cast p0, Lcom/google/common/collect/CompactHashMap;

    .line 9
    .line 10
    invoke-virtual {p0}, Lcom/google/common/collect/CompactHashMap;->size()I

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    return p0

    .line 15
    :pswitch_e
    check-cast p0, Lcom/google/common/collect/CompactHashMap;

    .line 16
    .line 17
    invoke-virtual {p0}, Lcom/google/common/collect/CompactHashMap;->size()I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    return p0

    .line 22
    :pswitch_15
    check-cast p0, Landroidx/collection/ArrayMap;

    .line 23
    .line 24
    iget p0, p0, Landroidx/collection/SimpleArrayMap;->size:I

    .line 25
    .line 26
    return p0

    .line 27
    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_15
        :pswitch_e
    .end packed-switch
    .line 28
    .line 29
    .line 30
.end method
