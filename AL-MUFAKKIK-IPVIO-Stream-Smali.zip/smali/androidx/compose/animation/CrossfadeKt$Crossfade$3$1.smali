.class public final Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;
.super Lkotlin/jvm/internal/Lambda;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# static fields
.field public static final INSTANCE:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

.field public static final INSTANCE$1:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

.field public static final INSTANCE$2:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

.field public static final INSTANCE$3:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

.field public static final INSTANCE$4:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

.field public static final INSTANCE$5:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

.field public static final INSTANCE$6:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

.field public static final INSTANCE$7:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;


# instance fields
.field public final synthetic $r8$classId:B


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x1

    .line 5
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;-><init>(IB)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->INSTANCE$1:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 9
    .line 10
    new-instance v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 11
    .line 12
    const/4 v2, 0x2

    .line 13
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;-><init>(IB)V

    .line 14
    .line 15
    .line 16
    sput-object v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->INSTANCE$2:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 17
    .line 18
    new-instance v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;-><init>(IB)V

    .line 22
    .line 23
    .line 24
    sput-object v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->INSTANCE:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 25
    .line 26
    new-instance v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 27
    .line 28
    const/4 v2, 0x3

    .line 29
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;-><init>(IB)V

    .line 30
    .line 31
    .line 32
    sput-object v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->INSTANCE$3:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 33
    .line 34
    new-instance v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 35
    .line 36
    const/4 v2, 0x4

    .line 37
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;-><init>(IB)V

    .line 38
    .line 39
    .line 40
    sput-object v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->INSTANCE$4:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 41
    .line 42
    new-instance v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 43
    .line 44
    const/4 v2, 0x5

    .line 45
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;-><init>(IB)V

    .line 46
    .line 47
    .line 48
    sput-object v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->INSTANCE$5:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 49
    .line 50
    new-instance v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 51
    .line 52
    const/4 v2, 0x6

    .line 53
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;-><init>(IB)V

    .line 54
    .line 55
    .line 56
    sput-object v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->INSTANCE$6:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 57
    .line 58
    new-instance v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 59
    .line 60
    const/4 v2, 0x7

    .line 61
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;-><init>(IB)V

    .line 62
    .line 63
    .line 64
    sput-object v0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->INSTANCE$7:Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;

    .line 65
    .line 66
    return-void
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
.end method

.method public synthetic constructor <init>(IB)V
    .registers 3

    .line 10
    iput-byte p2, p0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->$r8$classId:B

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    return-void
.end method

.method public constructor <init>(Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;)V
    .registers 3

    .line 1
    const/16 p1, 0x8

    .line 2
    .line 3
    iput-byte p1, p0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->$r8$classId:B

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    invoke-direct {p0, p1}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    .line 7
    .line 8
    .line 9
    return-void
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget-byte p0, p0, Landroidx/compose/animation/CrossfadeKt$Crossfade$3$1;->$r8$classId:B

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_8a

    .line 4
    .line 5
    .line 6
    check-cast p1, Landroidx/compose/animation/core/Transition$SegmentImpl;

    .line 7
    .line 8
    sget-object p0, Landroidx/compose/animation/EnterExitState;->PreEnter:Landroidx/compose/animation/EnterExitState;

    .line 9
    .line 10
    sget-object v0, Landroidx/compose/animation/EnterExitState;->Visible:Landroidx/compose/animation/EnterExitState;

    .line 11
    .line 12
    invoke-virtual {p1, p0, v0}, Landroidx/compose/animation/core/Transition$SegmentImpl;->isTransitioningTo(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    if-eqz p0, :cond_14

    .line 17
    .line 18
    sget-object p0, Landroidx/compose/animation/EnterExitTransitionKt;->DefaultAlphaAndScaleSpring:Landroidx/compose/animation/core/SpringSpec;

    .line 19
    .line 20
    goto :goto_21

    .line 21
    :cond_14
    sget-object p0, Landroidx/compose/animation/EnterExitState;->PostExit:Landroidx/compose/animation/EnterExitState;

    .line 22
    .line 23
    invoke-virtual {p1, v0, p0}, Landroidx/compose/animation/core/Transition$SegmentImpl;->isTransitioningTo(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    if-eqz p0, :cond_1f

    .line 28
    .line 29
    sget-object p0, Landroidx/compose/animation/EnterExitTransitionKt;->DefaultAlphaAndScaleSpring:Landroidx/compose/animation/core/SpringSpec;

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    sget-object p0, Landroidx/compose/animation/EnterExitTransitionKt;->DefaultAlphaAndScaleSpring:Landroidx/compose/animation/core/SpringSpec;

    .line 33
    .line 34
    :goto_21
    return-object p0

    .line 35
    :pswitch_22
    check-cast p1, Landroidx/compose/animation/core/Transition$SegmentImpl;

    .line 36
    .line 37
    sget-object p0, Landroidx/compose/animation/EnterExitTransitionKt;->DefaultOffsetAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    .line 38
    .line 39
    return-object p0

    .line 40
    :pswitch_27
    check-cast p1, Landroidx/compose/ui/unit/IntSize;

    .line 41
    .line 42
    iget-wide v0, p1, Landroidx/compose/ui/unit/IntSize;->packedValue:J

    .line 43
    .line 44
    return-object p1

    .line 45
    :pswitch_2c
    check-cast p1, Landroidx/compose/animation/core/Transition$SegmentImpl;

    .line 46
    .line 47
    const/4 p0, 0x0

    .line 48
    const/4 p1, 0x7

    .line 49
    const/4 v0, 0x0

    .line 50
    invoke-static {v0, p0, p1}, Landroidx/compose/animation/core/ArcSplineKt;->spring$default(FLjava/lang/Object;I)Landroidx/compose/animation/core/SpringSpec;

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    return-object p0

    .line 55
    :pswitch_36
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 56
    .line 57
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 58
    .line 59
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 60
    .line 61
    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/ColorKt;->TransformOrigin(FF)J

    .line 62
    .line 63
    .line 64
    move-result-wide p0

    .line 65
    new-instance v0, Landroidx/compose/ui/graphics/TransformOrigin;

    .line 66
    .line 67
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/graphics/TransformOrigin;-><init>(J)V

    .line 68
    .line 69
    .line 70
    return-object v0

    .line 71
    :pswitch_46
    check-cast p1, Landroidx/compose/ui/graphics/TransformOrigin;

    .line 72
    .line 73
    iget-wide p0, p1, Landroidx/compose/ui/graphics/TransformOrigin;->packedValue:J

    .line 74
    .line 75
    new-instance v0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 76
    .line 77
    const/16 v1, 0x20

    .line 78
    .line 79
    shr-long v1, p0, v1

    .line 80
    .line 81
    long-to-int v1, v1

    .line 82
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    const-wide v2, 0xffffffffL

    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    and-long/2addr p0, v2

    .line 92
    long-to-int p0, p0

    .line 93
    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 94
    .line 95
    .line 96
    move-result p0

    .line 97
    invoke-direct {v0, v1, p0}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 98
    .line 99
    .line 100
    return-object v0

    .line 101
    :pswitch_64
    check-cast p1, Landroidx/compose/ui/graphics/Color;

    .line 102
    .line 103
    iget-wide p0, p1, Landroidx/compose/ui/graphics/Color;->value:J

    .line 104
    .line 105
    sget-object v0, Landroidx/compose/ui/graphics/colorspace/ColorSpaces;->Oklab:Landroidx/compose/ui/graphics/colorspace/Oklab;

    .line 106
    .line 107
    invoke-static {p0, p1, v0}, Landroidx/compose/ui/graphics/Color;->convert-vNxB06k(JLandroidx/compose/ui/graphics/colorspace/ColorSpace;)J

    .line 108
    .line 109
    .line 110
    move-result-wide p0

    .line 111
    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getRed-impl(J)F

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getGreen-impl(J)F

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getBlue-impl(J)F

    .line 120
    .line 121
    .line 122
    move-result v2

    .line 123
    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getAlpha-impl(J)F

    .line 124
    .line 125
    .line 126
    move-result p0

    .line 127
    new-instance p1, Landroidx/compose/animation/core/AnimationVector4D;

    .line 128
    .line 129
    invoke-direct {p1, p0, v0, v1, v2}, Landroidx/compose/animation/core/AnimationVector4D;-><init>(FFFF)V

    .line 130
    .line 131
    .line 132
    return-object p1

    .line 133
    :pswitch_84
    check-cast p1, Ljava/lang/Boolean;

    .line 134
    .line 135
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 136
    .line 137
    .line 138
    :pswitch_89
    return-object p1

    .line 139
    :pswitch_data_8a
    .packed-switch 0x0
        :pswitch_89
        :pswitch_84
        :pswitch_64
        :pswitch_46
        :pswitch_36
        :pswitch_2c
        :pswitch_27
        :pswitch_22
    .end packed-switch
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
.end method
