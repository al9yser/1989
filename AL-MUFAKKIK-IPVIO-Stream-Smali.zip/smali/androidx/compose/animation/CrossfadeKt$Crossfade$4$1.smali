.class public final Landroidx/compose/animation/CrossfadeKt$Crossfade$4$1;
.super Lkotlin/jvm/internal/Lambda;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic $this_Crossfade:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .registers 3

    .line 1
    iput-byte p2, p0, Landroidx/compose/animation/CrossfadeKt$Crossfade$4$1;->$r8$classId:B

    .line 2
    .line 3
    iput-object p1, p0, Landroidx/compose/animation/CrossfadeKt$Crossfade$4$1;->$this_Crossfade:Ljava/lang/Object;

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    invoke-direct {p0, p1}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    .line 7
    .line 8
    .line 9
    return-void
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 1
    iget-byte v0, p0, Landroidx/compose/animation/CrossfadeKt$Crossfade$4$1;->$r8$classId:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    .line 6
    iget-object p0, p0, Landroidx/compose/animation/CrossfadeKt$Crossfade$4$1;->$this_Crossfade:Ljava/lang/Object;

    .line 7
    .line 8
    packed-switch v0, :pswitch_data_de

    .line 9
    .line 10
    .line 11
    check-cast p1, Ljava/lang/Throwable;

    .line 12
    .line 13
    check-cast p0, Lcom/google/common/util/concurrent/ListenableFuture;

    .line 14
    .line 15
    invoke-interface {p0, v1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    .line 16
    .line 17
    .line 18
    return-object v2

    .line 19
    :pswitch_12
    check-cast p1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    .line 20
    .line 21
    check-cast p0, Landroidx/compose/ui/graphics/layer/GraphicsLayer;

    .line 22
    .line 23
    iget-object v0, p0, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->outlinePath:Landroidx/compose/ui/graphics/Path;

    .line 24
    .line 25
    iget-boolean v1, p0, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->usePathForClip:Z

    .line 26
    .line 27
    if-eqz v1, :cond_4c

    .line 28
    .line 29
    iget-boolean v1, p0, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->clip:Z

    .line 30
    .line 31
    if-eqz v1, :cond_4c

    .line 32
    .line 33
    if-eqz v0, :cond_4c

    .line 34
    .line 35
    invoke-interface {p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Lcoil/network/RealNetworkObserver;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-virtual {v1}, Lcoil/network/RealNetworkObserver;->getSize-NH-jbRc()J

    .line 40
    .line 41
    .line 42
    move-result-wide v3

    .line 43
    invoke-virtual {v1}, Lcoil/network/RealNetworkObserver;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    .line 44
    .line 45
    .line 46
    move-result-object v5

    .line 47
    invoke-interface {v5}, Landroidx/compose/ui/graphics/Canvas;->save()V

    .line 48
    .line 49
    .line 50
    :try_start_31
    iget-object v5, v1, Lcoil/network/RealNetworkObserver;->connectivityManager:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v5, Landroidx/compose/ui/draw/DrawResult;

    .line 53
    .line 54
    iget-object v5, v5, Landroidx/compose/ui/draw/DrawResult;->block:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast v5, Lcoil/network/RealNetworkObserver;

    .line 57
    .line 58
    invoke-virtual {v5}, Lcoil/network/RealNetworkObserver;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    .line 59
    .line 60
    .line 61
    move-result-object v5

    .line 62
    invoke-interface {v5, v0}, Landroidx/compose/ui/graphics/Canvas;->clipPath-mtrdD-E(Landroidx/compose/ui/graphics/Path;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {p0, p1}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->drawWithChildTracking(Landroidx/compose/ui/graphics/drawscope/DrawScope;)V
    :try_end_43
    .catchall {:try_start_31 .. :try_end_43} :catchall_47

    .line 66
    .line 67
    .line 68
    invoke-static {v1, v3, v4}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Lcoil/network/RealNetworkObserver;J)V

    .line 69
    .line 70
    .line 71
    goto :goto_4f

    .line 72
    :catchall_47
    move-exception p0

    .line 73
    invoke-static {v1, v3, v4}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Lcoil/network/RealNetworkObserver;J)V

    .line 74
    .line 75
    .line 76
    throw p0

    .line 77
    :cond_4c
    invoke-virtual {p0, p1}, Landroidx/compose/ui/graphics/layer/GraphicsLayer;->drawWithChildTracking(Landroidx/compose/ui/graphics/drawscope/DrawScope;)V

    .line 78
    .line 79
    .line 80
    :goto_4f
    return-object v2

    .line 81
    :pswitch_50
    check-cast p1, Landroidx/compose/ui/graphics/GraphicsLayerScope;

    .line 82
    .line 83
    check-cast p0, Landroidx/compose/runtime/State;

    .line 84
    .line 85
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object p0

    .line 89
    check-cast p0, Ljava/lang/Number;

    .line 90
    .line 91
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 92
    .line 93
    .line 94
    move-result p0

    .line 95
    check-cast p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;

    .line 96
    .line 97
    invoke-virtual {p1, p0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setAlpha(F)V

    .line 98
    .line 99
    .line 100
    return-object v2

    .line 101
    :pswitch_64
    check-cast p1, Landroidx/compose/animation/core/AnimationVector4D;

    .line 102
    .line 103
    iget v0, p1, Landroidx/compose/animation/core/AnimationVector4D;->v2:F

    .line 104
    .line 105
    const/4 v1, 0x0

    .line 106
    cmpg-float v2, v0, v1

    .line 107
    .line 108
    if-gez v2, :cond_6e

    .line 109
    .line 110
    move v0, v1

    .line 111
    :cond_6e
    const/high16 v2, 0x3f800000    # 1.0f

    .line 112
    .line 113
    cmpl-float v3, v0, v2

    .line 114
    .line 115
    if-lez v3, :cond_75

    .line 116
    .line 117
    move v0, v2

    .line 118
    :cond_75
    iget v3, p1, Landroidx/compose/animation/core/AnimationVector4D;->v3:F

    .line 119
    .line 120
    const/high16 v4, -0x41000000    # -0.5f

    .line 121
    .line 122
    cmpg-float v5, v3, v4

    .line 123
    .line 124
    if-gez v5, :cond_7e

    .line 125
    .line 126
    move v3, v4

    .line 127
    :cond_7e
    const/high16 v5, 0x3f000000    # 0.5f

    .line 128
    .line 129
    cmpl-float v6, v3, v5

    .line 130
    .line 131
    if-lez v6, :cond_85

    .line 132
    .line 133
    move v3, v5

    .line 134
    :cond_85
    iget v6, p1, Landroidx/compose/animation/core/AnimationVector4D;->v4:F

    .line 135
    .line 136
    cmpg-float v7, v6, v4

    .line 137
    .line 138
    if-gez v7, :cond_8c

    .line 139
    .line 140
    goto :goto_8d

    .line 141
    :cond_8c
    move v4, v6

    .line 142
    :goto_8d
    cmpl-float v6, v4, v5

    .line 143
    .line 144
    if-lez v6, :cond_92

    .line 145
    .line 146
    goto :goto_93

    .line 147
    :cond_92
    move v5, v4

    .line 148
    :goto_93
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector4D;->v1:F

    .line 149
    .line 150
    cmpg-float v4, p1, v1

    .line 151
    .line 152
    if-gez v4, :cond_9a

    .line 153
    .line 154
    goto :goto_9b

    .line 155
    :cond_9a
    move v1, p1

    .line 156
    :goto_9b
    cmpl-float p1, v1, v2

    .line 157
    .line 158
    if-lez p1, :cond_a0

    .line 159
    .line 160
    goto :goto_a1

    .line 161
    :cond_a0
    move v2, v1

    .line 162
    :goto_a1
    sget-object p1, Landroidx/compose/ui/graphics/colorspace/ColorSpaces;->Oklab:Landroidx/compose/ui/graphics/colorspace/Oklab;

    .line 163
    .line 164
    invoke-static {v0, v3, v5, v2, p1}, Landroidx/compose/ui/graphics/ColorKt;->Color(FFFFLandroidx/compose/ui/graphics/colorspace/ColorSpace;)J

    .line 165
    .line 166
    .line 167
    move-result-wide v0

    .line 168
    check-cast p0, Landroidx/compose/ui/graphics/colorspace/ColorSpace;

    .line 169
    .line 170
    invoke-static {v0, v1, p0}, Landroidx/compose/ui/graphics/Color;->convert-vNxB06k(JLandroidx/compose/ui/graphics/colorspace/ColorSpace;)J

    .line 171
    .line 172
    .line 173
    move-result-wide p0

    .line 174
    new-instance v0, Landroidx/compose/ui/graphics/Color;

    .line 175
    .line 176
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/graphics/Color;-><init>(J)V

    .line 177
    .line 178
    .line 179
    return-object v0

    .line 180
    :pswitch_b3
    check-cast p1, Landroidx/compose/ui/layout/Placeable$PlacementScope;

    .line 181
    .line 182
    check-cast p0, Ljava/util/ArrayList;

    .line 183
    .line 184
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 185
    .line 186
    .line 187
    move-result v0

    .line 188
    move v3, v1

    .line 189
    :goto_bc
    if-ge v3, v0, :cond_ca

    .line 190
    .line 191
    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v4

    .line 195
    check-cast v4, Landroidx/compose/ui/layout/Placeable;

    .line 196
    .line 197
    invoke-static {v4, v1, v1, p1}, Landroidx/compose/ui/layout/Placeable$PlacementScope;->place$default(Landroidx/compose/ui/layout/Placeable;IILandroidx/compose/ui/layout/Placeable$PlacementScope;)V

    .line 198
    .line 199
    .line 200
    add-int/lit8 v3, v3, 0x1

    .line 201
    .line 202
    goto :goto_bc

    .line 203
    :cond_ca
    return-object v2

    .line 204
    :pswitch_cb
    check-cast p0, Landroidx/compose/animation/core/TransitionInstance;

    .line 205
    .line 206
    iget-object p0, p0, Landroidx/compose/animation/core/TransitionInstance;->targetState$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 207
    .line 208
    invoke-virtual {p0}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object p0

    .line 212
    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    move-result p0

    .line 216
    xor-int/lit8 p0, p0, 0x1

    .line 217
    .line 218
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 219
    .line 220
    .line 221
    move-result-object p0

    .line 222
    return-object p0

    .line 223
    :pswitch_data_de
    .packed-switch 0x0
        :pswitch_cb
        :pswitch_b3
        :pswitch_64
        :pswitch_50
        :pswitch_12
    .end packed-switch
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
.end method
