.class public final Landroidx/compose/animation/EnterExitTransitionKt$createGraphicsLayerBlock$1$1$block$1;
.super Lkotlin/jvm/internal/Lambda;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic $alpha:Landroidx/compose/runtime/State;

.field public final synthetic $mutableTransformState:Landroidx/compose/animation/SharedMutableTransformState;

.field public final synthetic $scale:Landroidx/compose/runtime/State;

.field public final synthetic $transformOrigin:Landroidx/compose/runtime/State;


# direct methods
.method public constructor <init>(Landroidx/compose/animation/SharedMutableTransformState;Landroidx/compose/animation/core/Transition$DeferredAnimation$DeferredAnimationData;Landroidx/compose/animation/core/Transition$DeferredAnimation$DeferredAnimationData;Landroidx/compose/animation/core/Transition$DeferredAnimation$DeferredAnimationData;)V
    .registers 5

    .line 1
    iput-object p1, p0, Landroidx/compose/animation/EnterExitTransitionKt$createGraphicsLayerBlock$1$1$block$1;->$mutableTransformState:Landroidx/compose/animation/SharedMutableTransformState;

    .line 2
    .line 3
    iput-object p2, p0, Landroidx/compose/animation/EnterExitTransitionKt$createGraphicsLayerBlock$1$1$block$1;->$alpha:Landroidx/compose/runtime/State;

    .line 4
    .line 5
    iput-object p3, p0, Landroidx/compose/animation/EnterExitTransitionKt$createGraphicsLayerBlock$1$1$block$1;->$scale:Landroidx/compose/runtime/State;

    .line 6
    .line 7
    iput-object p4, p0, Landroidx/compose/animation/EnterExitTransitionKt$createGraphicsLayerBlock$1$1$block$1;->$transformOrigin:Landroidx/compose/runtime/State;

    .line 8
    .line 9
    const/4 p1, 0x1

    .line 10
    invoke-direct {p0, p1}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    .line 11
    .line 12
    .line 13
    return-void
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    .line 1
    check-cast p1, Landroidx/compose/ui/graphics/GraphicsLayerScope;

    .line 2
    .line 3
    const/high16 v0, 0x3f800000    # 1.0f

    .line 4
    .line 5
    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionKt$createGraphicsLayerBlock$1$1$block$1;->$alpha:Landroidx/compose/runtime/State;

    .line 6
    .line 7
    if-eqz v1, :cond_13

    .line 8
    .line 9
    invoke-interface {v1}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Ljava/lang/Number;

    .line 14
    .line 15
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    move v1, v0

    .line 21
    :goto_14
    iget-object v2, p0, Landroidx/compose/animation/EnterExitTransitionKt$createGraphicsLayerBlock$1$1$block$1;->$mutableTransformState:Landroidx/compose/animation/SharedMutableTransformState;

    .line 22
    .line 23
    iget-object v3, v2, Landroidx/compose/animation/SharedMutableTransformState;->transformScope:Landroidx/work/impl/WorkerWrapper$Builder;

    .line 24
    .line 25
    iget-object v4, v3, Landroidx/work/impl/WorkerWrapper$Builder;->workDatabase:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v4, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 28
    .line 29
    invoke-virtual {v2}, Landroidx/compose/animation/SharedMutableTransformState;->isMutating()Z

    .line 30
    .line 31
    .line 32
    move-result v5

    .line 33
    if-eqz v5, :cond_3b

    .line 34
    .line 35
    iget-object v5, v3, Landroidx/work/impl/WorkerWrapper$Builder;->configuration:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v5, Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 38
    .line 39
    invoke-virtual {v5}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v5

    .line 43
    check-cast v5, Ljava/lang/Boolean;

    .line 44
    .line 45
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 46
    .line 47
    .line 48
    move-result v5

    .line 49
    if-eqz v5, :cond_3b

    .line 50
    .line 51
    iget-object v5, v3, Landroidx/work/impl/WorkerWrapper$Builder;->workTaskExecutor:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v5, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 54
    .line 55
    invoke-virtual {v5}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;->getFloatValue()F

    .line 56
    .line 57
    .line 58
    move-result v5

    .line 59
    goto :goto_3c

    .line 60
    :cond_3b
    move v5, v0

    .line 61
    :goto_3c
    mul-float/2addr v1, v5

    .line 62
    invoke-virtual {v2}, Landroidx/compose/animation/SharedMutableTransformState;->isMutating()Z

    .line 63
    .line 64
    .line 65
    move-result v5

    .line 66
    if-eqz v5, :cond_45

    .line 67
    .line 68
    iput v1, v2, Landroidx/compose/animation/SharedMutableTransformState;->lastAlpha:F

    .line 69
    .line 70
    :cond_45
    check-cast p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;

    .line 71
    .line 72
    invoke-virtual {p1, v1}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setAlpha(F)V

    .line 73
    .line 74
    .line 75
    iget-object v1, p0, Landroidx/compose/animation/EnterExitTransitionKt$createGraphicsLayerBlock$1$1$block$1;->$scale:Landroidx/compose/runtime/State;

    .line 76
    .line 77
    if-eqz v1, :cond_59

    .line 78
    .line 79
    invoke-interface {v1}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    check-cast v1, Ljava/lang/Number;

    .line 84
    .line 85
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 86
    .line 87
    .line 88
    move-result v1

    .line 89
    goto :goto_5a

    .line 90
    :cond_59
    move v1, v0

    .line 91
    :goto_5a
    invoke-virtual {v2}, Landroidx/compose/animation/SharedMutableTransformState;->isMutating()Z

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    const/4 v6, 0x1

    .line 96
    const/4 v7, 0x0

    .line 97
    if-eqz v5, :cond_74

    .line 98
    .line 99
    iget-object v5, v3, Landroidx/work/impl/WorkerWrapper$Builder;->foregroundProcessor:Ljava/lang/Object;

    .line 100
    .line 101
    check-cast v5, Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 102
    .line 103
    invoke-virtual {v5}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v5

    .line 107
    check-cast v5, Ljava/lang/Boolean;

    .line 108
    .line 109
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 110
    .line 111
    .line 112
    move-result v5

    .line 113
    if-eqz v5, :cond_74

    .line 114
    .line 115
    move v5, v6

    .line 116
    goto :goto_75

    .line 117
    :cond_74
    move v5, v7

    .line 118
    :goto_75
    if-eqz v5, :cond_7b

    .line 119
    .line 120
    invoke-virtual {v4}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;->getFloatValue()F

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    :cond_7b
    mul-float/2addr v1, v0

    .line 125
    invoke-virtual {v2}, Landroidx/compose/animation/SharedMutableTransformState;->isMutating()Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    if-eqz v0, :cond_c7

    .line 130
    .line 131
    iput v1, v2, Landroidx/compose/animation/SharedMutableTransformState;->lastScale:F

    .line 132
    .line 133
    if-eqz v5, :cond_89

    .line 134
    .line 135
    invoke-virtual {v4}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;->getFloatValue()F

    .line 136
    .line 137
    .line 138
    :cond_89
    if-eqz v5, :cond_c7

    .line 139
    .line 140
    iget-object v0, v2, Landroidx/compose/animation/SharedMutableTransformState;->scaleVelocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;

    .line 141
    .line 142
    if-nez v0, :cond_96

    .line 143
    .line 144
    new-instance v0, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;

    .line 145
    .line 146
    invoke-direct {v0, v7}, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;-><init>(Z)V

    .line 147
    .line 148
    .line 149
    iput-object v0, v2, Landroidx/compose/animation/SharedMutableTransformState;->scaleVelocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;

    .line 150
    .line 151
    :cond_96
    iget-wide v4, v2, Landroidx/compose/animation/SharedMutableTransformState;->startTime:J

    .line 152
    .line 153
    invoke-static {}, Lkotlin/time/MonotonicTimeSource;->read()J

    .line 154
    .line 155
    .line 156
    move-result-wide v7

    .line 157
    const-wide/16 v9, 0x1

    .line 158
    .line 159
    sub-long v11, v4, v9

    .line 160
    .line 161
    or-long/2addr v9, v11

    .line 162
    const-wide v11, 0x7fffffffffffffffL

    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    cmp-long v9, v9, v11

    .line 168
    .line 169
    if-nez v9, :cond_bc

    .line 170
    .line 171
    invoke-static {v4, v5}, Lokhttp3/RequestBody;->infinityOfSign(J)J

    .line 172
    .line 173
    .line 174
    move-result-wide v4

    .line 175
    sget v7, Lkotlin/time/Duration;->$r8$clinit:I

    .line 176
    .line 177
    shr-long v7, v4, v6

    .line 178
    .line 179
    neg-long v7, v7

    .line 180
    long-to-int v4, v4

    .line 181
    and-int/2addr v4, v6

    .line 182
    shl-long v5, v7, v6

    .line 183
    .line 184
    int-to-long v7, v4

    .line 185
    add-long/2addr v5, v7

    .line 186
    sget v4, Lkotlin/time/DurationJvmKt;->$r8$clinit:I

    .line 187
    .line 188
    goto :goto_c0

    .line 189
    :cond_bc
    invoke-static {v7, v8, v4, v5}, Lokhttp3/RequestBody;->saturatingFiniteDiff(JJ)J

    .line 190
    .line 191
    .line 192
    move-result-wide v5

    .line 193
    :goto_c0
    invoke-static {v5, v6}, Lkotlin/time/Duration;->getInWholeMilliseconds-impl(J)J

    .line 194
    .line 195
    .line 196
    move-result-wide v4

    .line 197
    invoke-virtual {v0, v4, v5, v1}, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->addDataPoint(JF)V

    .line 198
    .line 199
    .line 200
    :cond_c7
    invoke-virtual {p1, v1}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setScaleX(F)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {p1, v1}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setScaleY(F)V

    .line 204
    .line 205
    .line 206
    iget-object p0, p0, Landroidx/compose/animation/EnterExitTransitionKt$createGraphicsLayerBlock$1$1$block$1;->$transformOrigin:Landroidx/compose/runtime/State;

    .line 207
    .line 208
    if-eqz p0, :cond_da

    .line 209
    .line 210
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 211
    .line 212
    .line 213
    move-result-object p0

    .line 214
    check-cast p0, Landroidx/compose/ui/graphics/TransformOrigin;

    .line 215
    .line 216
    iget-wide v0, p0, Landroidx/compose/ui/graphics/TransformOrigin;->packedValue:J

    .line 217
    .line 218
    goto :goto_dc

    .line 219
    :cond_da
    sget-wide v0, Landroidx/compose/ui/graphics/TransformOrigin;->Center:J

    .line 220
    .line 221
    :goto_dc
    invoke-virtual {v2}, Landroidx/compose/animation/SharedMutableTransformState;->isMutating()Z

    .line 222
    .line 223
    .line 224
    move-result p0

    .line 225
    if-eqz p0, :cond_fe

    .line 226
    .line 227
    iget-object p0, v3, Landroidx/work/impl/WorkerWrapper$Builder;->workSpec:Ljava/lang/Object;

    .line 228
    .line 229
    check-cast p0, Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 230
    .line 231
    invoke-virtual {p0}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object p0

    .line 235
    check-cast p0, Ljava/lang/Boolean;

    .line 236
    .line 237
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 238
    .line 239
    .line 240
    move-result p0

    .line 241
    if-eqz p0, :cond_fe

    .line 242
    .line 243
    iget-object p0, v3, Landroidx/work/impl/WorkerWrapper$Builder;->tags:Ljava/lang/Object;

    .line 244
    .line 245
    check-cast p0, Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 246
    .line 247
    invoke-virtual {p0}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object p0

    .line 251
    check-cast p0, Landroidx/compose/ui/graphics/TransformOrigin;

    .line 252
    .line 253
    iget-wide v0, p0, Landroidx/compose/ui/graphics/TransformOrigin;->packedValue:J

    .line 254
    .line 255
    :cond_fe
    invoke-virtual {v2}, Landroidx/compose/animation/SharedMutableTransformState;->isMutating()Z

    .line 256
    .line 257
    .line 258
    move-result p0

    .line 259
    if-eqz p0, :cond_106

    .line 260
    .line 261
    iput-wide v0, v2, Landroidx/compose/animation/SharedMutableTransformState;->lastTransformOrigin:J

    .line 262
    .line 263
    :cond_106
    invoke-virtual {p1, v0, v1}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setTransformOrigin-__ExYCQ(J)V

    .line 264
    .line 265
    .line 266
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 267
    .line 268
    return-object p0
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
.end method
