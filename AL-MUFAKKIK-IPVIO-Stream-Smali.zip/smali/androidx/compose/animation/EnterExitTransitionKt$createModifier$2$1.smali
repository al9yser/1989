.class public final Landroidx/compose/animation/EnterExitTransitionKt$createModifier$2$1;
.super Lkotlin/jvm/internal/Lambda;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic $activeMutableState:Landroidx/compose/animation/SharedMutableTransformState;

.field public final synthetic $r8$classId:B


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/SharedMutableTransformState;B)V
    .registers 3

    .line 1
    iput-byte p2, p0, Landroidx/compose/animation/EnterExitTransitionKt$createModifier$2$1;->$r8$classId:B

    .line 2
    .line 3
    iput-object p1, p0, Landroidx/compose/animation/EnterExitTransitionKt$createModifier$2$1;->$activeMutableState:Landroidx/compose/animation/SharedMutableTransformState;

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    invoke-direct {p0, p1}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    .line 7
    .line 8
    .line 9
    return-void
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 5

    .line 1
    iget-byte v0, p0, Landroidx/compose/animation/EnterExitTransitionKt$createModifier$2$1;->$r8$classId:B

    .line 2
    .line 3
    iget-object p0, p0, Landroidx/compose/animation/EnterExitTransitionKt$createModifier$2$1;->$activeMutableState:Landroidx/compose/animation/SharedMutableTransformState;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_52

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Landroidx/compose/animation/SharedMutableTransformState;->isHandoffActive$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 9
    .line 10
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->setValue(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    invoke-virtual {p0, v0}, Landroidx/compose/animation/SharedMutableTransformState;->setMutating(Z)V

    .line 17
    .line 18
    .line 19
    iget-object v2, p0, Landroidx/compose/animation/SharedMutableTransformState;->transformScope:Landroidx/work/impl/WorkerWrapper$Builder;

    .line 20
    .line 21
    iget-object v3, v2, Landroidx/work/impl/WorkerWrapper$Builder;->configuration:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v3, Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 24
    .line 25
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->setValue(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    iget-object v3, v2, Landroidx/work/impl/WorkerWrapper$Builder;->foregroundProcessor:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v3, Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 31
    .line 32
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->setValue(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    iget-object v3, v2, Landroidx/work/impl/WorkerWrapper$Builder;->workSpec:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v3, Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 38
    .line 39
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->setValue(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    iget-object v2, v2, Landroidx/work/impl/WorkerWrapper$Builder;->appContext:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v2, Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 45
    .line 46
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->setValue(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    sget-wide v1, Landroidx/compose/ui/graphics/Color;->Transparent:J

    .line 50
    .line 51
    iput-wide v1, p0, Landroidx/compose/animation/SharedMutableTransformState;->lastVeil:J

    .line 52
    .line 53
    const/high16 v1, 0x3f800000    # 1.0f

    .line 54
    .line 55
    iput v1, p0, Landroidx/compose/animation/SharedMutableTransformState;->lastAlpha:F

    .line 56
    .line 57
    iput v1, p0, Landroidx/compose/animation/SharedMutableTransformState;->lastScale:F

    .line 58
    .line 59
    iget-object v1, p0, Landroidx/compose/animation/SharedMutableTransformState;->scaleVelocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;

    .line 60
    .line 61
    if-eqz v1, :cond_46

    .line 62
    .line 63
    iget-object v2, v1, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->samples:[Landroidx/compose/ui/input/pointer/util/DataPointAtTime;

    .line 64
    .line 65
    const/4 v3, 0x0

    .line 66
    invoke-static {v2, v3}, Lkotlin/collections/ArraysKt;->fill$default([Ljava/lang/Object;Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    iput v0, v1, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->index:I

    .line 70
    .line 71
    :cond_46
    sget-wide v0, Landroidx/compose/ui/graphics/TransformOrigin;->Center:J

    .line 72
    .line 73
    iput-wide v0, p0, Landroidx/compose/animation/SharedMutableTransformState;->lastTransformOrigin:J

    .line 74
    .line 75
    const-wide/16 v0, 0x0

    .line 76
    .line 77
    iput-wide v0, p0, Landroidx/compose/animation/SharedMutableTransformState;->lastSlide:J

    .line 78
    .line 79
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 80
    .line 81
    :pswitch_50
    return-object p0

    .line 82
    nop

    .line 83
    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_50
    .end packed-switch
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
.end method
