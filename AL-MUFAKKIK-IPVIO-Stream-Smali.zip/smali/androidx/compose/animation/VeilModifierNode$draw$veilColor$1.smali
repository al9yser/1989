.class public final Landroidx/compose/animation/VeilModifierNode$draw$veilColor$1;
.super Lkotlin/jvm/internal/Lambda;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic this$0:Landroidx/compose/animation/VeilModifierNode;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/VeilModifierNode;B)V
    .registers 3

    .line 1
    iput-byte p2, p0, Landroidx/compose/animation/VeilModifierNode$draw$veilColor$1;->$r8$classId:B

    .line 2
    .line 3
    iput-object p1, p0, Landroidx/compose/animation/VeilModifierNode$draw$veilColor$1;->this$0:Landroidx/compose/animation/VeilModifierNode;

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    invoke-direct {p0, p1}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    .line 7
    .line 8
    .line 9
    return-void
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget-byte v0, p0, Landroidx/compose/animation/VeilModifierNode$draw$veilColor$1;->$r8$classId:B

    .line 2
    .line 3
    iget-object p0, p0, Landroidx/compose/animation/VeilModifierNode$draw$veilColor$1;->this$0:Landroidx/compose/animation/VeilModifierNode;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_60

    .line 6
    .line 7
    .line 8
    check-cast p1, Landroidx/compose/animation/EnterExitState;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    if-eqz p1, :cond_2e

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    if-eq p1, v0, :cond_23

    .line 18
    .line 19
    const/4 v0, 0x2

    .line 20
    if-ne p1, v0, :cond_1e

    .line 21
    .line 22
    iget-object p1, p0, Landroidx/compose/animation/VeilModifierNode;->exit:Landroidx/compose/animation/ExitTransitionImpl;

    .line 23
    .line 24
    iget-object p1, p1, Landroidx/compose/animation/ExitTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 25
    .line 26
    iget-object p0, p0, Landroidx/compose/animation/VeilModifierNode;->mutableTransformState:Landroidx/compose/animation/SharedMutableTransformState;

    .line 27
    .line 28
    iget-wide p0, p0, Landroidx/compose/animation/SharedMutableTransformState;->lastVeil:J

    .line 29
    .line 30
    goto :goto_34

    .line 31
    :cond_1e
    invoke-static {}, Lcoil/util/-Utils$$ExternalSyntheticBUOutline0;->m$1()V

    .line 32
    .line 33
    .line 34
    const/4 p0, 0x0

    .line 35
    goto :goto_3a

    .line 36
    :cond_23
    iget-object p1, p0, Landroidx/compose/animation/VeilModifierNode;->enter:Landroidx/compose/animation/EnterTransitionImpl;

    .line 37
    .line 38
    iget-object p1, p1, Landroidx/compose/animation/EnterTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 39
    .line 40
    iget-object p0, p0, Landroidx/compose/animation/VeilModifierNode;->exit:Landroidx/compose/animation/ExitTransitionImpl;

    .line 41
    .line 42
    iget-object p0, p0, Landroidx/compose/animation/ExitTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 43
    .line 44
    sget-wide p0, Landroidx/compose/ui/graphics/Color;->Transparent:J

    .line 45
    .line 46
    goto :goto_34

    .line 47
    :cond_2e
    iget-object p0, p0, Landroidx/compose/animation/VeilModifierNode;->enter:Landroidx/compose/animation/EnterTransitionImpl;

    .line 48
    .line 49
    iget-object p0, p0, Landroidx/compose/animation/EnterTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 50
    .line 51
    sget-wide p0, Landroidx/compose/ui/graphics/Color;->Transparent:J

    .line 52
    .line 53
    :goto_34
    new-instance v0, Landroidx/compose/ui/graphics/Color;

    .line 54
    .line 55
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/graphics/Color;-><init>(J)V

    .line 56
    .line 57
    .line 58
    move-object p0, v0

    .line 59
    :goto_3a
    return-object p0

    .line 60
    :pswitch_3b
    check-cast p1, Landroidx/compose/animation/core/Transition$SegmentImpl;

    .line 61
    .line 62
    sget-object v0, Landroidx/compose/animation/EnterExitState;->PreEnter:Landroidx/compose/animation/EnterExitState;

    .line 63
    .line 64
    sget-object v1, Landroidx/compose/animation/EnterExitState;->Visible:Landroidx/compose/animation/EnterExitState;

    .line 65
    .line 66
    invoke-virtual {p1, v0, v1}, Landroidx/compose/animation/core/Transition$SegmentImpl;->isTransitioningTo(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_4e

    .line 71
    .line 72
    iget-object p0, p0, Landroidx/compose/animation/VeilModifierNode;->enter:Landroidx/compose/animation/EnterTransitionImpl;

    .line 73
    .line 74
    iget-object p0, p0, Landroidx/compose/animation/EnterTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 75
    .line 76
    sget-object p0, Landroidx/compose/animation/EnterExitTransitionKt;->DefaultColorAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    .line 77
    .line 78
    goto :goto_5f

    .line 79
    :cond_4e
    sget-object v0, Landroidx/compose/animation/EnterExitState;->PostExit:Landroidx/compose/animation/EnterExitState;

    .line 80
    .line 81
    invoke-virtual {p1, v1, v0}, Landroidx/compose/animation/core/Transition$SegmentImpl;->isTransitioningTo(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    if-eqz p1, :cond_5d

    .line 86
    .line 87
    iget-object p0, p0, Landroidx/compose/animation/VeilModifierNode;->exit:Landroidx/compose/animation/ExitTransitionImpl;

    .line 88
    .line 89
    iget-object p0, p0, Landroidx/compose/animation/ExitTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 90
    .line 91
    sget-object p0, Landroidx/compose/animation/EnterExitTransitionKt;->DefaultColorAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    .line 92
    .line 93
    goto :goto_5f

    .line 94
    :cond_5d
    sget-object p0, Landroidx/compose/animation/EnterExitTransitionKt;->DefaultColorAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    .line 95
    .line 96
    :goto_5f
    return-object p0

    .line 97
    :pswitch_data_60
    .packed-switch 0x0
        :pswitch_3b
    .end packed-switch
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
.end method
