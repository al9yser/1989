.class public final Landroidx/compose/animation/core/CubicBezierEasing;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Landroidx/compose/animation/core/Easing;


# instance fields
.field public final a:F

.field public final c:F

.field public final max:F

.field public final min:F


# direct methods
.method public constructor <init>(FF)V
    .registers 14

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Landroidx/compose/animation/core/CubicBezierEasing;->a:F

    .line 5
    .line 6
    iput p2, p0, Landroidx/compose/animation/core/CubicBezierEasing;->c:F

    .line 7
    .line 8
    invoke-static {p1}, Ljava/lang/Float;->isNaN(F)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    const/4 v1, 0x0

    .line 13
    const/high16 v2, 0x3f800000    # 1.0f

    .line 14
    .line 15
    if-nez v0, :cond_23

    .line 16
    .line 17
    invoke-static {v1}, Ljava/lang/Float;->isNaN(F)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_23

    .line 22
    .line 23
    invoke-static {p2}, Ljava/lang/Float;->isNaN(F)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-nez v0, :cond_23

    .line 28
    .line 29
    invoke-static {v2}, Ljava/lang/Float;->isNaN(F)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_23

    .line 34
    .line 35
    goto :goto_41

    .line 36
    :cond_23
    new-instance v0, Ljava/lang/StringBuilder;

    .line 37
    .line 38
    const-string v3, "Parameters to CubicBezierEasing cannot be NaN. Actual parameters are: "

    .line 39
    .line 40
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    const-string p1, ", 0.0, "

    .line 47
    .line 48
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    const-string p1, ", 1.0."

    .line 55
    .line 56
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-static {p1}, Landroidx/compose/animation/core/PreconditionsKt;->throwIllegalArgumentException(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    :goto_41
    const/4 p1, 0x5

    .line 67
    new-array p1, p1, [F

    .line 68
    .line 69
    const-wide/high16 v3, 0x4022000000000000L    # 9.0

    .line 70
    .line 71
    invoke-static {v3, v4}, Ljava/lang/Math;->sqrt(D)D

    .line 72
    .line 73
    .line 74
    move-result-wide v3

    .line 75
    neg-double v3, v3

    .line 76
    const-wide/high16 v5, 0x4008000000000000L    # 3.0

    .line 77
    .line 78
    add-double v7, v3, v5

    .line 79
    .line 80
    neg-double v7, v7

    .line 81
    const-wide/high16 v9, -0x3fe8000000000000L    # -6.0

    .line 82
    .line 83
    div-double/2addr v7, v9

    .line 84
    double-to-float p2, v7

    .line 85
    const/4 v0, 0x0

    .line 86
    invoke-static {p2, p1, v0}, Landroidx/compose/ui/graphics/ColorKt;->writeValidRootInUnitRange(F[FI)I

    .line 87
    .line 88
    .line 89
    move-result p2

    .line 90
    sub-double/2addr v3, v5

    .line 91
    div-double/2addr v3, v9

    .line 92
    double-to-float v3, v3

    .line 93
    invoke-static {v3, p1, p2}, Landroidx/compose/ui/graphics/ColorKt;->writeValidRootInUnitRange(F[FI)I

    .line 94
    .line 95
    .line 96
    move-result v3

    .line 97
    add-int/2addr v3, p2

    .line 98
    const/4 p2, 0x1

    .line 99
    if-le v3, p2, :cond_77

    .line 100
    .line 101
    aget v4, p1, v0

    .line 102
    .line 103
    aget v5, p1, p2

    .line 104
    .line 105
    cmpl-float v6, v4, v5

    .line 106
    .line 107
    if-lez v6, :cond_71

    .line 108
    .line 109
    aput v5, p1, v0

    .line 110
    .line 111
    aput v4, p1, p2

    .line 112
    .line 113
    goto :goto_77

    .line 114
    :cond_71
    cmpg-float p2, v4, v5

    .line 115
    .line 116
    if-nez p2, :cond_77

    .line 117
    .line 118
    add-int/lit8 v3, v3, -0x1

    .line 119
    .line 120
    :cond_77
    :goto_77
    const/high16 p2, 0x3f000000    # 0.5f

    .line 121
    .line 122
    invoke-static {p2, p1, v3}, Landroidx/compose/ui/graphics/ColorKt;->writeValidRootInUnitRange(F[FI)I

    .line 123
    .line 124
    .line 125
    move-result p2

    .line 126
    add-int/2addr p2, v3

    .line 127
    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    .line 128
    .line 129
    .line 130
    move-result v3

    .line 131
    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    .line 132
    .line 133
    .line 134
    move-result v2

    .line 135
    :goto_86
    if-ge v0, p2, :cond_9f

    .line 136
    .line 137
    aget v4, p1, v0

    .line 138
    .line 139
    const/high16 v5, 0x40400000    # 3.0f

    .line 140
    .line 141
    const/high16 v6, -0x40000000    # -2.0f

    .line 142
    .line 143
    mul-float/2addr v6, v4

    .line 144
    add-float/2addr v6, v5

    .line 145
    mul-float/2addr v6, v4

    .line 146
    add-float/2addr v6, v1

    .line 147
    mul-float/2addr v6, v4

    .line 148
    add-float/2addr v6, v1

    .line 149
    invoke-static {v3, v6}, Ljava/lang/Math;->min(FF)F

    .line 150
    .line 151
    .line 152
    move-result v3

    .line 153
    invoke-static {v2, v6}, Ljava/lang/Math;->max(FF)F

    .line 154
    .line 155
    .line 156
    move-result v2

    .line 157
    add-int/lit8 v0, v0, 0x1

    .line 158
    .line 159
    goto :goto_86

    .line 160
    :cond_9f
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 161
    .line 162
    .line 163
    move-result p1

    .line 164
    int-to-long p1, p1

    .line 165
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 166
    .line 167
    .line 168
    move-result v0

    .line 169
    int-to-long v0, v0

    .line 170
    const/16 v2, 0x20

    .line 171
    .line 172
    shl-long/2addr p1, v2

    .line 173
    const-wide v3, 0xffffffffL

    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    and-long/2addr v0, v3

    .line 179
    or-long/2addr p1, v0

    .line 180
    shr-long v0, p1, v2

    .line 181
    .line 182
    long-to-int v0, v0

    .line 183
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 184
    .line 185
    .line 186
    move-result v0

    .line 187
    iput v0, p0, Landroidx/compose/animation/core/CubicBezierEasing;->min:F

    .line 188
    .line 189
    and-long/2addr p1, v3

    .line 190
    long-to-int p1, p1

    .line 191
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 192
    .line 193
    .line 194
    move-result p1

    .line 195
    iput p1, p0, Landroidx/compose/animation/core/CubicBezierEasing;->max:F

    .line 196
    .line 197
    return-void
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    instance-of v0, p1, Landroidx/compose/animation/core/CubicBezierEasing;

    .line 2
    .line 3
    if-eqz v0, :cond_18

    .line 4
    .line 5
    check-cast p1, Landroidx/compose/animation/core/CubicBezierEasing;

    .line 6
    .line 7
    iget v0, p1, Landroidx/compose/animation/core/CubicBezierEasing;->a:F

    .line 8
    .line 9
    iget v1, p0, Landroidx/compose/animation/core/CubicBezierEasing;->a:F

    .line 10
    .line 11
    cmpg-float v0, v1, v0

    .line 12
    .line 13
    if-nez v0, :cond_18

    .line 14
    .line 15
    iget p0, p0, Landroidx/compose/animation/core/CubicBezierEasing;->c:F

    .line 16
    .line 17
    iget p1, p1, Landroidx/compose/animation/core/CubicBezierEasing;->c:F

    .line 18
    .line 19
    cmpg-float p0, p0, p1

    .line 20
    .line 21
    if-nez p0, :cond_18

    .line 22
    .line 23
    const/4 p0, 0x1

    .line 24
    return p0

    .line 25
    :cond_18
    const/4 p0, 0x0

    .line 26
    return p0
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    iget v0, p0, Landroidx/compose/animation/core/CubicBezierEasing;->a:F

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-static {v2, v0, v1}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(FII)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    iget p0, p0, Landroidx/compose/animation/core/CubicBezierEasing;->c:F

    .line 16
    .line 17
    invoke-static {p0, v0, v1}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(FII)I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    const/high16 v0, 0x3f800000    # 1.0f

    .line 22
    .line 23
    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    add-int/2addr v0, p0

    .line 28
    return v0
    .line 29
    .line 30
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "CubicBezierEasing(a="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget v1, p0, Landroidx/compose/animation/core/CubicBezierEasing;->a:F

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", b=0.0, c="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget p0, p0, Landroidx/compose/animation/core/CubicBezierEasing;->c:F

    .line 19
    .line 20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p0, ", d=1.0)"

    .line 24
    .line 25
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    return-object p0
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
.end method

.method public final transform(F)F
    .registers 28

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    cmpl-float v3, v1, v2

    .line 7
    .line 8
    if-lez v3, :cond_266

    .line 9
    .line 10
    const/high16 v3, 0x3f800000    # 1.0f

    .line 11
    .line 12
    cmpg-float v4, v1, v3

    .line 13
    .line 14
    if-gez v4, :cond_266

    .line 15
    .line 16
    const/high16 v4, 0x34000000

    .line 17
    .line 18
    invoke-static {v1, v4}, Ljava/lang/Math;->max(FF)F

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    sub-float v5, v2, v4

    .line 23
    .line 24
    iget v6, v0, Landroidx/compose/animation/core/CubicBezierEasing;->a:F

    .line 25
    .line 26
    sub-float v7, v6, v4

    .line 27
    .line 28
    iget v8, v0, Landroidx/compose/animation/core/CubicBezierEasing;->c:F

    .line 29
    .line 30
    sub-float v9, v8, v4

    .line 31
    .line 32
    sub-float v4, v3, v4

    .line 33
    .line 34
    float-to-double v10, v5

    .line 35
    float-to-double v12, v7

    .line 36
    const-wide/high16 v14, 0x4000000000000000L    # 2.0

    .line 37
    .line 38
    mul-double/2addr v12, v14

    .line 39
    sub-double v12, v10, v12

    .line 40
    .line 41
    move/from16 v16, v2

    .line 42
    .line 43
    move/from16 v17, v3

    .line 44
    .line 45
    float-to-double v2, v9

    .line 46
    add-double/2addr v12, v2

    .line 47
    const-wide/high16 v2, 0x4008000000000000L    # 3.0

    .line 48
    .line 49
    mul-double/2addr v12, v2

    .line 50
    move-wide/from16 v18, v2

    .line 51
    .line 52
    sub-float v2, v7, v5

    .line 53
    .line 54
    float-to-double v2, v2

    .line 55
    mul-double v2, v2, v18

    .line 56
    .line 57
    neg-float v5, v5

    .line 58
    move-wide/from16 v20, v14

    .line 59
    .line 60
    float-to-double v14, v5

    .line 61
    sub-float/2addr v7, v9

    .line 62
    move-wide/from16 v22, v12

    .line 63
    .line 64
    float-to-double v12, v7

    .line 65
    mul-double v12, v12, v18

    .line 66
    .line 67
    add-double/2addr v12, v14

    .line 68
    float-to-double v4, v4

    .line 69
    add-double/2addr v12, v4

    .line 70
    const-wide/16 v4, 0x0

    .line 71
    .line 72
    sub-double v14, v12, v4

    .line 73
    .line 74
    invoke-static {v14, v15}, Ljava/lang/Math;->abs(D)D

    .line 75
    .line 76
    .line 77
    move-result-wide v14

    .line 78
    const-wide v24, 0x3e7ad7f29abcaf48L    # 1.0E-7

    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    cmpg-double v7, v14, v24

    .line 84
    .line 85
    const v9, 0x358cedba    # 1.05E-6f

    .line 86
    .line 87
    .line 88
    const/high16 v14, 0x7fc00000    # Float.NaN

    .line 89
    .line 90
    if-gez v7, :cond_e3

    .line 91
    .line 92
    sub-double v12, v22, v4

    .line 93
    .line 94
    invoke-static {v12, v13}, Ljava/lang/Math;->abs(D)D

    .line 95
    .line 96
    .line 97
    move-result-wide v12

    .line 98
    cmpg-double v7, v12, v24

    .line 99
    .line 100
    if-gez v7, :cond_91

    .line 101
    .line 102
    sub-double v4, v2, v4

    .line 103
    .line 104
    invoke-static {v4, v5}, Ljava/lang/Math;->abs(D)D

    .line 105
    .line 106
    .line 107
    move-result-wide v4

    .line 108
    cmpg-double v4, v4, v24

    .line 109
    .line 110
    if-gez v4, :cond_71

    .line 111
    .line 112
    goto/16 :goto_22d

    .line 113
    .line 114
    :cond_71
    neg-double v4, v10

    .line 115
    div-double/2addr v4, v2

    .line 116
    double-to-float v2, v4

    .line 117
    cmpg-float v3, v2, v16

    .line 118
    .line 119
    if-gez v3, :cond_7b

    .line 120
    .line 121
    move/from16 v3, v16

    .line 122
    .line 123
    goto :goto_7c

    .line 124
    :cond_7b
    move v3, v2

    .line 125
    :goto_7c
    cmpl-float v4, v3, v17

    .line 126
    .line 127
    if-lez v4, :cond_82

    .line 128
    .line 129
    move/from16 v3, v17

    .line 130
    .line 131
    :cond_82
    sub-float v2, v3, v2

    .line 132
    .line 133
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    .line 134
    .line 135
    .line 136
    move-result v2

    .line 137
    cmpl-float v2, v2, v9

    .line 138
    .line 139
    if-lez v2, :cond_8e

    .line 140
    .line 141
    goto/16 :goto_22d

    .line 142
    .line 143
    :cond_8e
    move v14, v3

    .line 144
    goto/16 :goto_22d

    .line 145
    .line 146
    :cond_91
    mul-double v4, v2, v2

    .line 147
    .line 148
    const-wide/high16 v12, 0x4010000000000000L    # 4.0

    .line 149
    .line 150
    mul-double v12, v12, v22

    .line 151
    .line 152
    mul-double/2addr v12, v10

    .line 153
    sub-double/2addr v4, v12

    .line 154
    invoke-static {v4, v5}, Ljava/lang/Math;->sqrt(D)D

    .line 155
    .line 156
    .line 157
    move-result-wide v4

    .line 158
    mul-double v12, v22, v20

    .line 159
    .line 160
    sub-double v10, v4, v2

    .line 161
    .line 162
    div-double/2addr v10, v12

    .line 163
    double-to-float v7, v10

    .line 164
    cmpg-float v10, v7, v16

    .line 165
    .line 166
    if-gez v10, :cond_aa

    .line 167
    .line 168
    move/from16 v10, v16

    .line 169
    .line 170
    goto :goto_ab

    .line 171
    :cond_aa
    move v10, v7

    .line 172
    :goto_ab
    cmpl-float v11, v10, v17

    .line 173
    .line 174
    if-lez v11, :cond_b1

    .line 175
    .line 176
    move/from16 v10, v17

    .line 177
    .line 178
    :cond_b1
    sub-float v7, v10, v7

    .line 179
    .line 180
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    .line 181
    .line 182
    .line 183
    move-result v7

    .line 184
    cmpl-float v7, v7, v9

    .line 185
    .line 186
    if-lez v7, :cond_bc

    .line 187
    .line 188
    move v10, v14

    .line 189
    :cond_bc
    invoke-static {v10}, Ljava/lang/Float;->isNaN(F)Z

    .line 190
    .line 191
    .line 192
    move-result v7

    .line 193
    if-nez v7, :cond_c5

    .line 194
    .line 195
    move v14, v10

    .line 196
    goto/16 :goto_22d

    .line 197
    .line 198
    :cond_c5
    neg-double v2, v2

    .line 199
    sub-double/2addr v2, v4

    .line 200
    div-double/2addr v2, v12

    .line 201
    double-to-float v2, v2

    .line 202
    cmpg-float v3, v2, v16

    .line 203
    .line 204
    if-gez v3, :cond_d0

    .line 205
    .line 206
    move/from16 v3, v16

    .line 207
    .line 208
    goto :goto_d1

    .line 209
    :cond_d0
    move v3, v2

    .line 210
    :goto_d1
    cmpl-float v4, v3, v17

    .line 211
    .line 212
    if-lez v4, :cond_d7

    .line 213
    .line 214
    move/from16 v3, v17

    .line 215
    .line 216
    :cond_d7
    sub-float v2, v3, v2

    .line 217
    .line 218
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    .line 219
    .line 220
    .line 221
    move-result v2

    .line 222
    cmpl-float v2, v2, v9

    .line 223
    .line 224
    if-lez v2, :cond_8e

    .line 225
    .line 226
    goto/16 :goto_22d

    .line 227
    .line 228
    :cond_e3
    div-double v22, v22, v12

    .line 229
    .line 230
    div-double/2addr v2, v12

    .line 231
    div-double/2addr v10, v12

    .line 232
    mul-double v12, v2, v18

    .line 233
    .line 234
    mul-double v24, v22, v22

    .line 235
    .line 236
    sub-double v12, v12, v24

    .line 237
    .line 238
    const-wide/high16 v24, 0x4022000000000000L    # 9.0

    .line 239
    .line 240
    div-double v12, v12, v24

    .line 241
    .line 242
    mul-double v20, v20, v22

    .line 243
    .line 244
    mul-double v20, v20, v22

    .line 245
    .line 246
    mul-double v20, v20, v22

    .line 247
    .line 248
    mul-double v24, v24, v22

    .line 249
    .line 250
    mul-double v24, v24, v2

    .line 251
    .line 252
    sub-double v20, v20, v24

    .line 253
    .line 254
    const-wide/high16 v2, 0x403b000000000000L    # 27.0

    .line 255
    .line 256
    mul-double/2addr v10, v2

    .line 257
    add-double v10, v10, v20

    .line 258
    .line 259
    const-wide/high16 v2, 0x404b000000000000L    # 54.0

    .line 260
    .line 261
    div-double/2addr v10, v2

    .line 262
    mul-double v2, v10, v10

    .line 263
    .line 264
    mul-double v20, v12, v12

    .line 265
    .line 266
    mul-double v12, v12, v20

    .line 267
    .line 268
    add-double/2addr v2, v12

    .line 269
    move-wide/from16 v20, v4

    .line 270
    .line 271
    div-double v4, v22, v18

    .line 272
    .line 273
    cmpg-double v7, v2, v20

    .line 274
    .line 275
    const/high16 v15, 0x40000000    # 2.0f

    .line 276
    .line 277
    if-gez v7, :cond_1b9

    .line 278
    .line 279
    neg-double v2, v12

    .line 280
    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    .line 281
    .line 282
    .line 283
    move-result-wide v2

    .line 284
    neg-double v10, v10

    .line 285
    div-double/2addr v10, v2

    .line 286
    const-wide/high16 v12, -0x4010000000000000L    # -1.0

    .line 287
    .line 288
    cmpg-double v7, v10, v12

    .line 289
    .line 290
    if-gez v7, :cond_124

    .line 291
    .line 292
    move-wide v10, v12

    .line 293
    :cond_124
    const-wide/high16 v12, 0x3ff0000000000000L    # 1.0

    .line 294
    .line 295
    cmpl-double v7, v10, v12

    .line 296
    .line 297
    if-lez v7, :cond_12b

    .line 298
    .line 299
    move-wide v10, v12

    .line 300
    :cond_12b
    invoke-static {v10, v11}, Ljava/lang/Math;->acos(D)D

    .line 301
    .line 302
    .line 303
    move-result-wide v10

    .line 304
    double-to-float v2, v2

    .line 305
    invoke-static {v2}, Lkotlin/math/MathKt;->fastCbrt(F)F

    .line 306
    .line 307
    .line 308
    move-result v2

    .line 309
    mul-float/2addr v2, v15

    .line 310
    float-to-double v2, v2

    .line 311
    div-double v12, v10, v18

    .line 312
    .line 313
    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    .line 314
    .line 315
    .line 316
    move-result-wide v12

    .line 317
    mul-double/2addr v12, v2

    .line 318
    sub-double/2addr v12, v4

    .line 319
    double-to-float v7, v12

    .line 320
    cmpg-float v12, v7, v16

    .line 321
    .line 322
    if-gez v12, :cond_146

    .line 323
    .line 324
    move/from16 v12, v16

    .line 325
    .line 326
    goto :goto_147

    .line 327
    :cond_146
    move v12, v7

    .line 328
    :goto_147
    cmpl-float v13, v12, v17

    .line 329
    .line 330
    if-lez v13, :cond_14d

    .line 331
    .line 332
    move/from16 v12, v17

    .line 333
    .line 334
    :cond_14d
    sub-float v7, v12, v7

    .line 335
    .line 336
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    .line 337
    .line 338
    .line 339
    move-result v7

    .line 340
    cmpl-float v7, v7, v9

    .line 341
    .line 342
    if-lez v7, :cond_158

    .line 343
    .line 344
    move v12, v14

    .line 345
    :cond_158
    invoke-static {v12}, Ljava/lang/Float;->isNaN(F)Z

    .line 346
    .line 347
    .line 348
    move-result v7

    .line 349
    if-nez v7, :cond_161

    .line 350
    .line 351
    :goto_15e
    move v14, v12

    .line 352
    goto/16 :goto_22d

    .line 353
    .line 354
    :cond_161
    const-wide v12, 0x401921fb54442d18L    # 6.283185307179586

    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    add-double/2addr v12, v10

    .line 360
    div-double v12, v12, v18

    .line 361
    .line 362
    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    .line 363
    .line 364
    .line 365
    move-result-wide v12

    .line 366
    mul-double/2addr v12, v2

    .line 367
    sub-double/2addr v12, v4

    .line 368
    double-to-float v7, v12

    .line 369
    cmpg-float v12, v7, v16

    .line 370
    .line 371
    if-gez v12, :cond_177

    .line 372
    .line 373
    move/from16 v12, v16

    .line 374
    .line 375
    goto :goto_178

    .line 376
    :cond_177
    move v12, v7

    .line 377
    :goto_178
    cmpl-float v13, v12, v17

    .line 378
    .line 379
    if-lez v13, :cond_17e

    .line 380
    .line 381
    move/from16 v12, v17

    .line 382
    .line 383
    :cond_17e
    sub-float v7, v12, v7

    .line 384
    .line 385
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    .line 386
    .line 387
    .line 388
    move-result v7

    .line 389
    cmpl-float v7, v7, v9

    .line 390
    .line 391
    if-lez v7, :cond_189

    .line 392
    .line 393
    move v12, v14

    .line 394
    :cond_189
    invoke-static {v12}, Ljava/lang/Float;->isNaN(F)Z

    .line 395
    .line 396
    .line 397
    move-result v7

    .line 398
    if-nez v7, :cond_190

    .line 399
    .line 400
    goto :goto_15e

    .line 401
    :cond_190
    const-wide v12, 0x402921fb54442d18L    # 12.566370614359172

    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    add-double/2addr v10, v12

    .line 407
    div-double v10, v10, v18

    .line 408
    .line 409
    invoke-static {v10, v11}, Ljava/lang/Math;->cos(D)D

    .line 410
    .line 411
    .line 412
    move-result-wide v10

    .line 413
    mul-double/2addr v10, v2

    .line 414
    sub-double/2addr v10, v4

    .line 415
    double-to-float v2, v10

    .line 416
    cmpg-float v3, v2, v16

    .line 417
    .line 418
    if-gez v3, :cond_1a6

    .line 419
    .line 420
    move/from16 v3, v16

    .line 421
    .line 422
    goto :goto_1a7

    .line 423
    :cond_1a6
    move v3, v2

    .line 424
    :goto_1a7
    cmpl-float v4, v3, v17

    .line 425
    .line 426
    if-lez v4, :cond_1ad

    .line 427
    .line 428
    move/from16 v3, v17

    .line 429
    .line 430
    :cond_1ad
    sub-float v2, v3, v2

    .line 431
    .line 432
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    .line 433
    .line 434
    .line 435
    move-result v2

    .line 436
    cmpl-float v2, v2, v9

    .line 437
    .line 438
    if-lez v2, :cond_8e

    .line 439
    .line 440
    goto/16 :goto_22d

    .line 441
    .line 442
    :cond_1b9
    if-nez v7, :cond_200

    .line 443
    .line 444
    double-to-float v2, v10

    .line 445
    invoke-static {v2}, Lkotlin/math/MathKt;->fastCbrt(F)F

    .line 446
    .line 447
    .line 448
    move-result v2

    .line 449
    neg-float v2, v2

    .line 450
    mul-float/2addr v15, v2

    .line 451
    double-to-float v3, v4

    .line 452
    sub-float/2addr v15, v3

    .line 453
    cmpg-float v4, v15, v16

    .line 454
    .line 455
    if-gez v4, :cond_1cb

    .line 456
    .line 457
    move/from16 v4, v16

    .line 458
    .line 459
    goto :goto_1cc

    .line 460
    :cond_1cb
    move v4, v15

    .line 461
    :goto_1cc
    cmpl-float v5, v4, v17

    .line 462
    .line 463
    if-lez v5, :cond_1d2

    .line 464
    .line 465
    move/from16 v4, v17

    .line 466
    .line 467
    :cond_1d2
    sub-float v5, v4, v15

    .line 468
    .line 469
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 470
    .line 471
    .line 472
    move-result v5

    .line 473
    cmpl-float v5, v5, v9

    .line 474
    .line 475
    if-lez v5, :cond_1dd

    .line 476
    .line 477
    move v4, v14

    .line 478
    :cond_1dd
    invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z

    .line 479
    .line 480
    .line 481
    move-result v5

    .line 482
    if-nez v5, :cond_1e5

    .line 483
    .line 484
    move v14, v4

    .line 485
    goto :goto_22d

    .line 486
    :cond_1e5
    neg-float v2, v2

    .line 487
    sub-float/2addr v2, v3

    .line 488
    cmpg-float v3, v2, v16

    .line 489
    .line 490
    if-gez v3, :cond_1ee

    .line 491
    .line 492
    move/from16 v3, v16

    .line 493
    .line 494
    goto :goto_1ef

    .line 495
    :cond_1ee
    move v3, v2

    .line 496
    :goto_1ef
    cmpl-float v4, v3, v17

    .line 497
    .line 498
    if-lez v4, :cond_1f5

    .line 499
    .line 500
    move/from16 v3, v17

    .line 501
    .line 502
    :cond_1f5
    sub-float v2, v3, v2

    .line 503
    .line 504
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    .line 505
    .line 506
    .line 507
    move-result v2

    .line 508
    cmpl-float v2, v2, v9

    .line 509
    .line 510
    if-lez v2, :cond_8e

    .line 511
    .line 512
    goto :goto_22d

    .line 513
    :cond_200
    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    .line 514
    .line 515
    .line 516
    move-result-wide v2

    .line 517
    neg-double v12, v10

    .line 518
    add-double/2addr v12, v2

    .line 519
    double-to-float v7, v12

    .line 520
    invoke-static {v7}, Lkotlin/math/MathKt;->fastCbrt(F)F

    .line 521
    .line 522
    .line 523
    move-result v7

    .line 524
    add-double/2addr v10, v2

    .line 525
    double-to-float v2, v10

    .line 526
    invoke-static {v2}, Lkotlin/math/MathKt;->fastCbrt(F)F

    .line 527
    .line 528
    .line 529
    move-result v2

    .line 530
    sub-float/2addr v7, v2

    .line 531
    float-to-double v2, v7

    .line 532
    sub-double/2addr v2, v4

    .line 533
    double-to-float v2, v2

    .line 534
    cmpg-float v3, v2, v16

    .line 535
    .line 536
    if-gez v3, :cond_21c

    .line 537
    .line 538
    move/from16 v3, v16

    .line 539
    .line 540
    goto :goto_21d

    .line 541
    :cond_21c
    move v3, v2

    .line 542
    :goto_21d
    cmpl-float v4, v3, v17

    .line 543
    .line 544
    if-lez v4, :cond_223

    .line 545
    .line 546
    move/from16 v3, v17

    .line 547
    .line 548
    :cond_223
    sub-float v2, v3, v2

    .line 549
    .line 550
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    .line 551
    .line 552
    .line 553
    move-result v2

    .line 554
    cmpl-float v2, v2, v9

    .line 555
    .line 556
    if-lez v2, :cond_8e

    .line 557
    .line 558
    :goto_22d
    invoke-static {v14}, Ljava/lang/Float;->isNaN(F)Z

    .line 559
    .line 560
    .line 561
    move-result v2

    .line 562
    if-nez v2, :cond_24f

    .line 563
    .line 564
    const v1, -0x40d55556

    .line 565
    .line 566
    .line 567
    mul-float/2addr v1, v14

    .line 568
    add-float v1, v1, v17

    .line 569
    .line 570
    mul-float/2addr v1, v14

    .line 571
    add-float v1, v1, v16

    .line 572
    .line 573
    const/high16 v2, 0x40400000    # 3.0f

    .line 574
    .line 575
    mul-float/2addr v1, v2

    .line 576
    mul-float/2addr v1, v14

    .line 577
    iget v2, v0, Landroidx/compose/animation/core/CubicBezierEasing;->min:F

    .line 578
    .line 579
    cmpg-float v3, v1, v2

    .line 580
    .line 581
    if-gez v3, :cond_247

    .line 582
    .line 583
    move v1, v2

    .line 584
    :cond_247
    iget v0, v0, Landroidx/compose/animation/core/CubicBezierEasing;->max:F

    .line 585
    .line 586
    cmpl-float v2, v1, v0

    .line 587
    .line 588
    if-lez v2, :cond_24e

    .line 589
    .line 590
    return v0

    .line 591
    :cond_24e
    return v1

    .line 592
    :cond_24f
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 593
    .line 594
    const-string v2, ", 0.0, "

    .line 595
    .line 596
    const-string v3, ", 1.0) has no solution at "

    .line 597
    .line 598
    const-string v4, "The cubic curve with parameters ("

    .line 599
    .line 600
    invoke-static {v4, v6, v2, v8, v3}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;FLjava/lang/String;FLjava/lang/String;)Ljava/lang/StringBuilder;

    .line 601
    .line 602
    .line 603
    move-result-object v2

    .line 604
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 605
    .line 606
    .line 607
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 608
    .line 609
    .line 610
    move-result-object v1

    .line 611
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 612
    .line 613
    .line 614
    throw v0

    .line 615
    :cond_266
    return v1
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
.end method
