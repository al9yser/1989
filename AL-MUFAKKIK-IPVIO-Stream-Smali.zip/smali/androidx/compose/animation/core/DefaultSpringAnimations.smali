.class public final Landroidx/compose/animation/core/DefaultSpringAnimations;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Landroidx/compose/animation/core/Animations;


# static fields
.field public static final INSTANCE:Landroidx/compose/animation/core/DefaultSpringAnimations;

.field public static final anim:Landroidx/compose/animation/core/FloatSpringSpec;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Landroidx/compose/animation/core/DefaultSpringAnimations;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Landroidx/compose/animation/core/DefaultSpringAnimations;->INSTANCE:Landroidx/compose/animation/core/DefaultSpringAnimations;

    .line 7
    .line 8
    new-instance v0, Landroidx/compose/animation/core/FloatSpringSpec;

    .line 9
    .line 10
    const/high16 v1, 0x3f800000    # 1.0f

    .line 11
    .line 12
    const v2, 0x44bb8000    # 1500.0f

    .line 13
    .line 14
    .line 15
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/core/FloatSpringSpec;-><init>(FF)V

    .line 16
    .line 17
    .line 18
    sput-object v0, Landroidx/compose/animation/core/DefaultSpringAnimations;->anim:Landroidx/compose/animation/core/FloatSpringSpec;

    .line 19
    .line 20
    return-void
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
.end method


# virtual methods
.method public final get(I)Landroidx/compose/animation/core/FloatAnimationSpec;
    .registers 2

    .line 1
    sget-object p0, Landroidx/compose/animation/core/DefaultSpringAnimations;->anim:Landroidx/compose/animation/core/FloatSpringSpec;

    .line 2
    .line 3
    return-object p0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
.end method
