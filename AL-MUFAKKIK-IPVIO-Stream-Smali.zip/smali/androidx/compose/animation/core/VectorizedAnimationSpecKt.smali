.class public abstract Landroidx/compose/animation/core/VectorizedAnimationSpecKt;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"


# static fields
.field public static final synthetic $r8$clinit:I


# direct methods
.method static constructor <clinit>()V
    .registers 25

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v1, v0, [I

    .line 3
    .line 4
    new-array v2, v0, [F

    .line 5
    .line 6
    new-array v3, v0, [F

    .line 7
    .line 8
    filled-new-array {v2, v3}, [[F

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    const/4 v3, 0x0

    .line 13
    aget v1, v1, v3

    .line 14
    .line 15
    const/4 v4, 0x5

    .line 16
    const/4 v5, 0x4

    .line 17
    const/4 v6, 0x3

    .line 18
    const/4 v7, 0x1

    .line 19
    if-eqz v1, :cond_26

    .line 20
    .line 21
    if-eq v1, v7, :cond_1e

    .line 22
    .line 23
    if-eq v1, v0, :cond_24

    .line 24
    .line 25
    if-eq v1, v6, :cond_24

    .line 26
    .line 27
    if-eq v1, v5, :cond_22

    .line 28
    .line 29
    if-eq v1, v4, :cond_20

    .line 30
    .line 31
    :cond_1e
    move v1, v7

    .line 32
    goto :goto_27

    .line 33
    :cond_20
    move v1, v4

    .line 34
    goto :goto_27

    .line 35
    :cond_22
    move v1, v5

    .line 36
    goto :goto_27

    .line 37
    :cond_24
    move v1, v0

    .line 38
    goto :goto_27

    .line 39
    :cond_26
    move v1, v6

    .line 40
    :goto_27
    aget-object v8, v2, v3

    .line 41
    .line 42
    aget-object v2, v2, v7

    .line 43
    .line 44
    array-length v9, v8

    .line 45
    div-int/2addr v9, v0

    .line 46
    array-length v10, v8

    .line 47
    rem-int/2addr v10, v0

    .line 48
    add-int/2addr v10, v9

    .line 49
    new-array v0, v10, [Landroidx/collection/internal/Lock;

    .line 50
    .line 51
    move v9, v3

    .line 52
    :goto_33
    if-ge v9, v10, :cond_114

    .line 53
    .line 54
    mul-int/lit8 v11, v9, 0x2

    .line 55
    .line 56
    new-instance v12, Landroidx/collection/internal/Lock;

    .line 57
    .line 58
    aget v13, v8, v11

    .line 59
    .line 60
    add-int/lit8 v14, v11, 0x1

    .line 61
    .line 62
    aget v15, v8, v14

    .line 63
    .line 64
    aget v11, v2, v11

    .line 65
    .line 66
    aget v14, v2, v14

    .line 67
    .line 68
    invoke-direct {v12, v7}, Landroidx/collection/internal/Lock;-><init>(B)V

    .line 69
    .line 70
    .line 71
    sub-float/2addr v11, v13

    .line 72
    sub-float v13, v14, v15

    .line 73
    .line 74
    const/16 v4, 0x65

    .line 75
    .line 76
    new-array v5, v4, [F

    .line 77
    .line 78
    if-ne v1, v6, :cond_56

    .line 79
    .line 80
    :cond_4f
    :goto_4f
    move/from16 v20, v7

    .line 81
    .line 82
    move-object/from16 v21, v8

    .line 83
    .line 84
    move v7, v3

    .line 85
    goto/16 :goto_101

    .line 86
    .line 87
    :cond_56
    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    .line 88
    .line 89
    .line 90
    move-result v16

    .line 91
    const v17, 0x3a83126f    # 0.001f

    .line 92
    .line 93
    .line 94
    cmpg-float v16, v16, v17

    .line 95
    .line 96
    if-ltz v16, :cond_4f

    .line 97
    .line 98
    invoke-static {v13}, Ljava/lang/Math;->abs(F)F

    .line 99
    .line 100
    .line 101
    move-result v16

    .line 102
    cmpg-float v16, v16, v17

    .line 103
    .line 104
    if-gez v16, :cond_6a

    .line 105
    .line 106
    goto :goto_4f

    .line 107
    :cond_6a
    sub-float/2addr v15, v14

    .line 108
    sget-object v13, Landroidx/compose/animation/core/ArcSplineKt;->OurPercentCache:[F

    .line 109
    .line 110
    move v6, v7

    .line 111
    move/from16 v20, v6

    .line 112
    .line 113
    move-object/from16 v21, v8

    .line 114
    .line 115
    move/from16 v19, v15

    .line 116
    .line 117
    const/16 v17, 0x0

    .line 118
    .line 119
    const/16 v18, 0x0

    .line 120
    .line 121
    :goto_78
    int-to-double v7, v6

    .line 122
    const-wide v22, 0x4056800000000000L    # 90.0

    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    mul-double v7, v7, v22

    .line 128
    .line 129
    div-double v7, v7, v22

    .line 130
    .line 131
    const-wide v22, 0x3f91df46a2529d39L    # 0.017453292519943295

    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    mul-double v7, v7, v22

    .line 137
    .line 138
    double-to-float v7, v7

    .line 139
    float-to-double v7, v7

    .line 140
    move/from16 v22, v15

    .line 141
    .line 142
    const/16 v23, 0x0

    .line 143
    .line 144
    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    .line 145
    .line 146
    .line 147
    move-result-wide v14

    .line 148
    double-to-float v14, v14

    .line 149
    invoke-static {v7, v8}, Ljava/lang/Math;->cos(D)D

    .line 150
    .line 151
    .line 152
    move-result-wide v7

    .line 153
    double-to-float v7, v7

    .line 154
    mul-float/2addr v14, v11

    .line 155
    mul-float v15, v22, v7

    .line 156
    .line 157
    sub-float v7, v14, v18

    .line 158
    .line 159
    float-to-double v7, v7

    .line 160
    sub-float v3, v15, v19

    .line 161
    .line 162
    move-object/from16 v24, v5

    .line 163
    .line 164
    float-to-double v4, v3

    .line 165
    invoke-static {v7, v8, v4, v5}, Ljava/lang/Math;->hypot(DD)D

    .line 166
    .line 167
    .line 168
    move-result-wide v3

    .line 169
    double-to-float v3, v3

    .line 170
    add-float v17, v17, v3

    .line 171
    .line 172
    aput v17, v13, v6

    .line 173
    .line 174
    const/16 v3, 0x5a

    .line 175
    .line 176
    if-eq v6, v3, :cond_bf

    .line 177
    .line 178
    add-int/lit8 v6, v6, 0x1

    .line 179
    .line 180
    move/from16 v18, v14

    .line 181
    .line 182
    move/from16 v19, v15

    .line 183
    .line 184
    move/from16 v15, v22

    .line 185
    .line 186
    move-object/from16 v5, v24

    .line 187
    .line 188
    const/4 v3, 0x0

    .line 189
    const/16 v4, 0x65

    .line 190
    .line 191
    goto :goto_78

    .line 192
    :cond_bf
    move/from16 v4, v20

    .line 193
    .line 194
    :goto_c1
    aget v5, v13, v4

    .line 195
    .line 196
    div-float v5, v5, v17

    .line 197
    .line 198
    aput v5, v13, v4

    .line 199
    .line 200
    if-eq v4, v3, :cond_cc

    .line 201
    .line 202
    add-int/lit8 v4, v4, 0x1

    .line 203
    .line 204
    goto :goto_c1

    .line 205
    :cond_cc
    const/4 v3, 0x0

    .line 206
    const/16 v4, 0x65

    .line 207
    .line 208
    :goto_cf
    if-ge v3, v4, :cond_ff

    .line 209
    .line 210
    int-to-float v5, v3

    .line 211
    const/high16 v6, 0x42c80000    # 100.0f

    .line 212
    .line 213
    div-float/2addr v5, v6

    .line 214
    const/16 v6, 0x5b

    .line 215
    .line 216
    const/4 v7, 0x0

    .line 217
    invoke-static {v13, v7, v6, v5}, Ljava/util/Arrays;->binarySearch([FIIF)I

    .line 218
    .line 219
    .line 220
    move-result v6

    .line 221
    const/high16 v8, 0x42b40000    # 90.0f

    .line 222
    .line 223
    if-ltz v6, :cond_e5

    .line 224
    .line 225
    int-to-float v5, v6

    .line 226
    div-float/2addr v5, v8

    .line 227
    aput v5, v24, v3

    .line 228
    .line 229
    goto :goto_fc

    .line 230
    :cond_e5
    const/4 v11, -0x1

    .line 231
    if-ne v6, v11, :cond_eb

    .line 232
    .line 233
    aput v23, v24, v3

    .line 234
    .line 235
    goto :goto_fc

    .line 236
    :cond_eb
    neg-int v6, v6

    .line 237
    add-int/lit8 v11, v6, -0x2

    .line 238
    .line 239
    add-int/lit8 v6, v6, -0x1

    .line 240
    .line 241
    int-to-float v14, v11

    .line 242
    aget v11, v13, v11

    .line 243
    .line 244
    sub-float/2addr v5, v11

    .line 245
    aget v6, v13, v6

    .line 246
    .line 247
    sub-float/2addr v6, v11

    .line 248
    div-float/2addr v5, v6

    .line 249
    add-float/2addr v5, v14

    .line 250
    div-float/2addr v5, v8

    .line 251
    aput v5, v24, v3

    .line 252
    .line 253
    :goto_fc
    add-int/lit8 v3, v3, 0x1

    .line 254
    .line 255
    goto :goto_cf

    .line 256
    :cond_ff
    const/4 v7, 0x0

    .line 257
    goto :goto_106

    .line 258
    :goto_101
    float-to-double v3, v13

    .line 259
    float-to-double v5, v11

    .line 260
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->hypot(DD)D

    .line 261
    .line 262
    .line 263
    :goto_106
    aput-object v12, v0, v9

    .line 264
    .line 265
    add-int/lit8 v9, v9, 0x1

    .line 266
    .line 267
    move v3, v7

    .line 268
    move/from16 v7, v20

    .line 269
    .line 270
    move-object/from16 v8, v21

    .line 271
    .line 272
    const/4 v4, 0x5

    .line 273
    const/4 v5, 0x4

    .line 274
    const/4 v6, 0x3

    .line 275
    goto/16 :goto_33

    .line 276
    .line 277
    :cond_114
    return-void
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
.end method
