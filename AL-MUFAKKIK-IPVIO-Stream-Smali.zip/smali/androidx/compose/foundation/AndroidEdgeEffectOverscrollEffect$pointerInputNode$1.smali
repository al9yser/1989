.class public final Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect$pointerInputNode$1;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic this$0:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .registers 3

    .line 1
    iput-byte p2, p0, Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect$pointerInputNode$1;->$r8$classId:B

    .line 2
    .line 3
    iput-object p1, p0, Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect$pointerInputNode$1;->this$0:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
.end method


# virtual methods
.method public final invoke(Landroidx/compose/ui/input/pointer/PointerInputScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 15

    .line 1
    iget-byte v0, p0, Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect$pointerInputNode$1;->$r8$classId:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object p0, p0, Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect$pointerInputNode$1;->this$0:Ljava/lang/Object;

    .line 5
    .line 6
    sget-object v2, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 7
    .line 8
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 9
    .line 10
    packed-switch v0, :pswitch_data_9a

    .line 11
    .line 12
    .line 13
    check-cast p0, Landroidx/compose/foundation/text/TextDragObserver;

    .line 14
    .line 15
    new-instance v0, Landroidx/compose/foundation/text/LongPressTextDragObserverKt$detectDownAndDragGesturesWithObserver$2;

    .line 16
    .line 17
    invoke-direct {v0, p1, p0, v1}, Landroidx/compose/foundation/text/LongPressTextDragObserverKt$detectDownAndDragGesturesWithObserver$2;-><init>(Landroidx/compose/ui/input/pointer/PointerInputScope;Landroidx/compose/foundation/text/TextDragObserver;Lkotlin/coroutines/Continuation;)V

    .line 18
    .line 19
    .line 20
    invoke-static {v0, p2}, Lkotlinx/coroutines/AwaitKt;->coroutineScope(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    if-ne p0, v2, :cond_1a

    .line 25
    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    move-object p0, v3

    .line 28
    :goto_1b
    if-ne p0, v2, :cond_1e

    .line 29
    .line 30
    move-object v3, p0

    .line 31
    :cond_1e
    return-object v3

    .line 32
    :pswitch_1f
    new-instance v0, Landroidx/compose/foundation/text/selection/SelectionGesturesKt$updateSelectionTouchMode$1$1;

    .line 33
    .line 34
    check-cast p0, Landroidx/compose/foundation/text/CoreTextFieldKt$$ExternalSyntheticLambda2;

    .line 35
    .line 36
    invoke-direct {v0, p0, v1}, Landroidx/compose/foundation/text/selection/SelectionGesturesKt$updateSelectionTouchMode$1$1;-><init>(Landroidx/compose/foundation/text/CoreTextFieldKt$$ExternalSyntheticLambda2;Lkotlin/coroutines/Continuation;)V

    .line 37
    .line 38
    .line 39
    check-cast p1, Landroidx/compose/ui/input/pointer/SuspendingPointerInputModifierNodeImpl;

    .line 40
    .line 41
    invoke-virtual {p1, v0, p2}, Landroidx/compose/ui/input/pointer/SuspendingPointerInputModifierNodeImpl;->awaitPointerEventScope(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    if-ne p0, v2, :cond_2f

    .line 46
    .line 47
    move-object v3, p0

    .line 48
    :cond_2f
    return-object v3

    .line 49
    :pswitch_30
    new-instance v0, Landroidx/compose/foundation/text/selection/SelectionGesturesKt$awaitSelectionGestures$2;

    .line 50
    .line 51
    check-cast p0, Landroidx/compose/foundation/text/handwriting/StylusHandwritingNode;

    .line 52
    .line 53
    invoke-direct {v0, p0, v1}, Landroidx/compose/foundation/text/selection/SelectionGesturesKt$awaitSelectionGestures$2;-><init>(Landroidx/compose/foundation/text/handwriting/StylusHandwritingNode;Lkotlin/coroutines/Continuation;)V

    .line 54
    .line 55
    .line 56
    invoke-static {p1, v0, p2}, Landroidx/compose/foundation/gestures/ForEachGestureKt;->awaitEachGesture(Landroidx/compose/ui/input/pointer/PointerInputScope;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    if-ne p0, v2, :cond_3e

    .line 61
    .line 62
    move-object v3, p0

    .line 63
    :cond_3e
    return-object v3

    .line 64
    :pswitch_3f
    new-instance v4, Lkotlinx/coroutines/JobKt__JobKt$invokeOnCompletion$1;

    .line 65
    .line 66
    move-object v6, p0

    .line 67
    check-cast v6, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode;

    .line 68
    .line 69
    const/4 v10, 0x0

    .line 70
    const/4 v11, 0x3

    .line 71
    const/4 v5, 0x1

    .line 72
    const-class v7, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode;

    .line 73
    .line 74
    const-string v8, "tryShowContextMenu"

    .line 75
    .line 76
    const-string v9, "tryShowContextMenu-k-4lQ0M(J)V"

    .line 77
    .line 78
    invoke-direct/range {v4 .. v11}, Lkotlinx/coroutines/JobKt__JobKt$invokeOnCompletion$1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 79
    .line 80
    .line 81
    new-instance p0, Landroidx/core/view/ViewKt$allViews$1;

    .line 82
    .line 83
    const/4 v0, 0x2

    .line 84
    invoke-direct {p0, v4, v1, v0}, Landroidx/core/view/ViewKt$allViews$1;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;B)V

    .line 85
    .line 86
    .line 87
    invoke-static {p1, p0, p2}, Landroidx/compose/foundation/gestures/ForEachGestureKt;->awaitEachGesture(Landroidx/compose/ui/input/pointer/PointerInputScope;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    if-ne p0, v2, :cond_5d

    .line 92
    .line 93
    goto :goto_5e

    .line 94
    :cond_5d
    move-object p0, v3

    .line 95
    :goto_5e
    if-ne p0, v2, :cond_61

    .line 96
    .line 97
    move-object v3, p0

    .line 98
    :cond_61
    return-object v3

    .line 99
    :pswitch_62
    check-cast p0, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;

    .line 100
    .line 101
    iget-object v0, p0, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;->mouseSelectionObserver:Landroidx/compose/ui/input/pointer/InternalPointerEvent;

    .line 102
    .line 103
    iget-object p0, p0, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;->touchSelectionObserver:Landroidx/compose/foundation/text/selection/TextFieldSelectionManager$touchSelectionObserver$1;

    .line 104
    .line 105
    new-instance v4, Landroidx/room/RoomOpenHelper;

    .line 106
    .line 107
    move-object v5, p1

    .line 108
    check-cast v5, Landroidx/compose/ui/input/pointer/SuspendingPointerInputModifierNodeImpl;

    .line 109
    .line 110
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 111
    .line 112
    .line 113
    invoke-static {v5}, Landroidx/compose/ui/node/HitTestResultKt;->requireLayoutNode(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/node/LayoutNode;

    .line 114
    .line 115
    .line 116
    move-result-object v5

    .line 117
    iget-object v5, v5, Landroidx/compose/ui/node/LayoutNode;->viewConfiguration:Landroidx/compose/ui/platform/ViewConfiguration;

    .line 118
    .line 119
    invoke-direct {v4, v5}, Landroidx/room/RoomOpenHelper;-><init>(Landroidx/compose/ui/platform/ViewConfiguration;)V

    .line 120
    .line 121
    .line 122
    new-instance v5, Landroidx/compose/foundation/text/selection/SelectionGesturesKt$awaitSelectionGestures$2;

    .line 123
    .line 124
    invoke-direct {v5, v4, v0, p0, v1}, Landroidx/compose/foundation/text/selection/SelectionGesturesKt$awaitSelectionGestures$2;-><init>(Landroidx/room/RoomOpenHelper;Landroidx/compose/ui/input/pointer/InternalPointerEvent;Landroidx/compose/foundation/text/TextDragObserver;Lkotlin/coroutines/Continuation;)V

    .line 125
    .line 126
    .line 127
    invoke-static {p1, v5, p2}, Landroidx/compose/foundation/gestures/ForEachGestureKt;->awaitEachGesture(Landroidx/compose/ui/input/pointer/PointerInputScope;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object p0

    .line 131
    if-ne p0, v2, :cond_85

    .line 132
    .line 133
    goto :goto_86

    .line 134
    :cond_85
    move-object p0, v3

    .line 135
    :goto_86
    if-ne p0, v2, :cond_89

    .line 136
    .line 137
    move-object v3, p0

    .line 138
    :cond_89
    return-object v3

    .line 139
    :pswitch_8a
    new-instance v0, Landroidx/core/view/ViewKt$allViews$1;

    .line 140
    .line 141
    check-cast p0, Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect;

    .line 142
    .line 143
    const/4 v4, 0x1

    .line 144
    invoke-direct {v0, p0, v1, v4}, Landroidx/core/view/ViewKt$allViews$1;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;B)V

    .line 145
    .line 146
    .line 147
    invoke-static {p1, v0, p2}, Landroidx/compose/foundation/gestures/ForEachGestureKt;->awaitEachGesture(Landroidx/compose/ui/input/pointer/PointerInputScope;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    if-ne p0, v2, :cond_99

    .line 152
    .line 153
    move-object v3, p0

    .line 154
    :cond_99
    return-object v3

    .line 155
    :pswitch_data_9a
    .packed-switch 0x0
        :pswitch_8a
        :pswitch_62
        :pswitch_3f
        :pswitch_30
        :pswitch_1f
    .end packed-switch
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
.end method
