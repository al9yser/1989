.class public final Landroidx/compose/foundation/BackgroundNode;
.super Landroidx/compose/ui/Modifier$Node;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Landroidx/compose/ui/node/DrawModifierNode;
.implements Landroidx/compose/ui/node/ObserverModifierNode;
.implements Landroidx/compose/ui/node/SemanticsModifierNode;


# instance fields
.field public alpha:F

.field public brush:Landroidx/compose/ui/graphics/Brush;

.field public color:J

.field public lastLayoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

.field public lastOutline:Landroidx/compose/ui/graphics/ColorKt;

.field public lastShape:Landroidx/compose/ui/graphics/Shape;

.field public lastSize:J

.field public shape:Landroidx/compose/ui/graphics/Shape;

.field public tmpOutline:Landroidx/compose/ui/graphics/ColorKt;


# virtual methods
.method public final applySemantics(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)V
    .registers 2

    .line 1
    iget-object p0, p0, Landroidx/compose/foundation/BackgroundNode;->shape:Landroidx/compose/ui/graphics/Shape;

    .line 2
    .line 3
    invoke-static {p1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setShape(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Landroidx/compose/ui/graphics/Shape;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
.end method

.method public final draw(Landroidx/compose/ui/node/LayoutNodeDrawScope;)V
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v1, Landroidx/compose/ui/node/LayoutNodeDrawScope;->canvasDrawScope:Landroidx/compose/ui/graphics/drawscope/CanvasDrawScope;

    .line 6
    .line 7
    iget-object v3, v0, Landroidx/compose/foundation/BackgroundNode;->shape:Landroidx/compose/ui/graphics/Shape;

    .line 8
    .line 9
    sget-object v4, Landroidx/compose/ui/graphics/ColorKt;->RectangleShape:Landroidx/compose/ui/graphics/RectangleShapeKt$RectangleShape$1;

    .line 10
    .line 11
    if-ne v3, v4, :cond_3b

    .line 12
    .line 13
    iget-wide v2, v0, Landroidx/compose/foundation/BackgroundNode;->color:J

    .line 14
    .line 15
    sget-wide v4, Landroidx/compose/ui/graphics/Color;->Unspecified:J

    .line 16
    .line 17
    invoke-static {v2, v3, v4, v5}, Lkotlin/ULong;->equals-impl0(JJ)Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    if-nez v2, :cond_22

    .line 22
    .line 23
    iget-wide v2, v0, Landroidx/compose/foundation/BackgroundNode;->color:J

    .line 24
    .line 25
    const/4 v8, 0x0

    .line 26
    const/16 v9, 0x7e

    .line 27
    .line 28
    const-wide/16 v4, 0x0

    .line 29
    .line 30
    const-wide/16 v6, 0x0

    .line 31
    .line 32
    invoke-static/range {v1 .. v9}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJLandroidx/compose/ui/graphics/drawscope/Stroke;I)V

    .line 33
    .line 34
    .line 35
    :cond_22
    iget-object v1, v0, Landroidx/compose/foundation/BackgroundNode;->brush:Landroidx/compose/ui/graphics/Brush;

    .line 36
    .line 37
    if-eqz v1, :cond_37

    .line 38
    .line 39
    iget v6, v0, Landroidx/compose/foundation/BackgroundNode;->alpha:F

    .line 40
    .line 41
    const/4 v7, 0x0

    .line 42
    const/16 v8, 0x76

    .line 43
    .line 44
    const-wide/16 v2, 0x0

    .line 45
    .line 46
    const-wide/16 v4, 0x0

    .line 47
    .line 48
    move-object/from16 v0, p1

    .line 49
    .line 50
    invoke-static/range {v0 .. v8}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-AsUm42w$default(Landroidx/compose/ui/node/LayoutNodeDrawScope;Landroidx/compose/ui/graphics/Brush;JJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;I)V

    .line 51
    .line 52
    .line 53
    move-object v1, v0

    .line 54
    goto/16 :goto_1e9

    .line 55
    .line 56
    :cond_37
    move-object/from16 v1, p1

    .line 57
    .line 58
    goto/16 :goto_1e9

    .line 59
    .line 60
    :cond_3b
    invoke-interface {v2}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 61
    .line 62
    .line 63
    move-result-wide v3

    .line 64
    iget-wide v5, v0, Landroidx/compose/foundation/BackgroundNode;->lastSize:J

    .line 65
    .line 66
    invoke-static {v3, v4, v5, v6}, Landroidx/compose/ui/geometry/Size;->equals-impl0(JJ)Z

    .line 67
    .line 68
    .line 69
    move-result v3

    .line 70
    if-eqz v3, :cond_60

    .line 71
    .line 72
    invoke-virtual {v1}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    iget-object v4, v0, Landroidx/compose/foundation/BackgroundNode;->lastLayoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

    .line 77
    .line 78
    if-ne v3, v4, :cond_60

    .line 79
    .line 80
    iget-object v3, v0, Landroidx/compose/foundation/BackgroundNode;->lastShape:Landroidx/compose/ui/graphics/Shape;

    .line 81
    .line 82
    iget-object v4, v0, Landroidx/compose/foundation/BackgroundNode;->shape:Landroidx/compose/ui/graphics/Shape;

    .line 83
    .line 84
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v3

    .line 88
    if-eqz v3, :cond_60

    .line 89
    .line 90
    iget-object v3, v0, Landroidx/compose/foundation/BackgroundNode;->lastOutline:Landroidx/compose/ui/graphics/ColorKt;

    .line 91
    .line 92
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 93
    .line 94
    .line 95
    :goto_5e
    move-object v11, v3

    .line 96
    goto :goto_6f

    .line 97
    :cond_60
    new-instance v3, Lkotlin/text/Regex$$ExternalSyntheticLambda0;

    .line 98
    .line 99
    const/4 v4, 0x3

    .line 100
    invoke-direct {v3, v0, v1, v4}, Lkotlin/text/Regex$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 101
    .line 102
    .line 103
    invoke-static {v0, v3}, Landroidx/compose/ui/node/HitTestResultKt;->observeReads(Landroidx/compose/ui/Modifier$Node;Lkotlin/jvm/functions/Function0;)V

    .line 104
    .line 105
    .line 106
    iget-object v3, v0, Landroidx/compose/foundation/BackgroundNode;->tmpOutline:Landroidx/compose/ui/graphics/ColorKt;

    .line 107
    .line 108
    const/4 v4, 0x0

    .line 109
    iput-object v4, v0, Landroidx/compose/foundation/BackgroundNode;->tmpOutline:Landroidx/compose/ui/graphics/ColorKt;

    .line 110
    .line 111
    goto :goto_5e

    .line 112
    :goto_6f
    iput-object v11, v0, Landroidx/compose/foundation/BackgroundNode;->lastOutline:Landroidx/compose/ui/graphics/ColorKt;

    .line 113
    .line 114
    invoke-interface {v2}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 115
    .line 116
    .line 117
    move-result-wide v2

    .line 118
    iput-wide v2, v0, Landroidx/compose/foundation/BackgroundNode;->lastSize:J

    .line 119
    .line 120
    invoke-virtual {v1}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    iput-object v2, v0, Landroidx/compose/foundation/BackgroundNode;->lastLayoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

    .line 125
    .line 126
    iget-object v2, v0, Landroidx/compose/foundation/BackgroundNode;->shape:Landroidx/compose/ui/graphics/Shape;

    .line 127
    .line 128
    iput-object v2, v0, Landroidx/compose/foundation/BackgroundNode;->lastShape:Landroidx/compose/ui/graphics/Shape;

    .line 129
    .line 130
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 131
    .line 132
    .line 133
    iget-wide v2, v0, Landroidx/compose/foundation/BackgroundNode;->color:J

    .line 134
    .line 135
    sget-wide v4, Landroidx/compose/ui/graphics/Color;->Unspecified:J

    .line 136
    .line 137
    invoke-static {v2, v3, v4, v5}, Lkotlin/ULong;->equals-impl0(JJ)Z

    .line 138
    .line 139
    .line 140
    move-result v2

    .line 141
    const/16 v12, 0x20

    .line 142
    .line 143
    const-wide v13, 0xffffffffL

    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    sget-object v4, Landroidx/compose/ui/graphics/drawscope/Fill;->INSTANCE:Landroidx/compose/ui/graphics/drawscope/Fill;

    .line 149
    .line 150
    if-nez v2, :cond_139

    .line 151
    .line 152
    iget-wide v2, v0, Landroidx/compose/foundation/BackgroundNode;->color:J

    .line 153
    .line 154
    instance-of v5, v11, Landroidx/compose/ui/graphics/Outline$Rectangle;

    .line 155
    .line 156
    if-eqz v5, :cond_c4

    .line 157
    .line 158
    move-object v5, v11

    .line 159
    check-cast v5, Landroidx/compose/ui/graphics/Outline$Rectangle;

    .line 160
    .line 161
    iget-object v5, v5, Landroidx/compose/ui/graphics/Outline$Rectangle;->rect:Landroidx/compose/ui/geometry/Rect;

    .line 162
    .line 163
    iget v6, v5, Landroidx/compose/ui/geometry/Rect;->left:F

    .line 164
    .line 165
    iget v7, v5, Landroidx/compose/ui/geometry/Rect;->top:F

    .line 166
    .line 167
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 168
    .line 169
    .line 170
    move-result v6

    .line 171
    int-to-long v8, v6

    .line 172
    invoke-static {v7}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 173
    .line 174
    .line 175
    move-result v6

    .line 176
    int-to-long v6, v6

    .line 177
    shl-long/2addr v8, v12

    .line 178
    and-long/2addr v6, v13

    .line 179
    or-long/2addr v6, v8

    .line 180
    invoke-static {v5}, Landroidx/compose/ui/graphics/ColorKt;->size(Landroidx/compose/ui/geometry/Rect;)J

    .line 181
    .line 182
    .line 183
    move-result-wide v8

    .line 184
    move-wide/from16 v19, v8

    .line 185
    .line 186
    move-object v8, v4

    .line 187
    move-wide v4, v6

    .line 188
    move-wide/from16 v6, v19

    .line 189
    .line 190
    const/4 v9, 0x3

    .line 191
    invoke-virtual/range {v1 .. v9}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->drawRect-n-J9OG0(JJJLandroidx/compose/ui/graphics/drawscope/DrawStyle;I)V

    .line 192
    .line 193
    .line 194
    move-object v4, v8

    .line 195
    goto/16 :goto_139

    .line 196
    .line 197
    :cond_c4
    instance-of v5, v11, Landroidx/compose/ui/graphics/Outline$Rounded;

    .line 198
    .line 199
    if-eqz v5, :cond_124

    .line 200
    .line 201
    move-object v5, v11

    .line 202
    check-cast v5, Landroidx/compose/ui/graphics/Outline$Rounded;

    .line 203
    .line 204
    iget-object v6, v5, Landroidx/compose/ui/graphics/Outline$Rounded;->roundRectPath:Landroidx/compose/ui/graphics/AndroidPath;

    .line 205
    .line 206
    if-eqz v6, :cond_d3

    .line 207
    .line 208
    invoke-virtual {v1, v6, v2, v3, v4}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->drawPath-LG529CI(Landroidx/compose/ui/graphics/Path;JLandroidx/compose/ui/graphics/drawscope/DrawStyle;)V

    .line 209
    .line 210
    .line 211
    goto :goto_139

    .line 212
    :cond_d3
    iget-object v5, v5, Landroidx/compose/ui/graphics/Outline$Rounded;->roundRect:Landroidx/compose/ui/geometry/RoundRect;

    .line 213
    .line 214
    iget v6, v5, Landroidx/compose/ui/geometry/RoundRect;->top:F

    .line 215
    .line 216
    iget v7, v5, Landroidx/compose/ui/geometry/RoundRect;->left:F

    .line 217
    .line 218
    iget-wide v8, v5, Landroidx/compose/ui/geometry/RoundRect;->bottomLeftCornerRadius:J

    .line 219
    .line 220
    shr-long/2addr v8, v12

    .line 221
    long-to-int v8, v8

    .line 222
    invoke-static {v8}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 223
    .line 224
    .line 225
    move-result v8

    .line 226
    invoke-static {v7}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 227
    .line 228
    .line 229
    move-result v9

    .line 230
    int-to-long v9, v9

    .line 231
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 232
    .line 233
    .line 234
    move-result v15

    .line 235
    move/from16 v16, v12

    .line 236
    .line 237
    move-wide/from16 v17, v13

    .line 238
    .line 239
    int-to-long v12, v15

    .line 240
    shl-long v9, v9, v16

    .line 241
    .line 242
    and-long v12, v12, v17

    .line 243
    .line 244
    or-long/2addr v9, v12

    .line 245
    iget v12, v5, Landroidx/compose/ui/geometry/RoundRect;->right:F

    .line 246
    .line 247
    sub-float/2addr v12, v7

    .line 248
    iget v5, v5, Landroidx/compose/ui/geometry/RoundRect;->bottom:F

    .line 249
    .line 250
    sub-float/2addr v5, v6

    .line 251
    invoke-static {v12}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 252
    .line 253
    .line 254
    move-result v6

    .line 255
    int-to-long v6, v6

    .line 256
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 257
    .line 258
    .line 259
    move-result v5

    .line 260
    int-to-long v12, v5

    .line 261
    shl-long v5, v6, v16

    .line 262
    .line 263
    and-long v12, v12, v17

    .line 264
    .line 265
    or-long v6, v5, v12

    .line 266
    .line 267
    invoke-static {v8}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 268
    .line 269
    .line 270
    move-result v5

    .line 271
    int-to-long v12, v5

    .line 272
    invoke-static {v8}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 273
    .line 274
    .line 275
    move-result v5

    .line 276
    int-to-long v14, v5

    .line 277
    shl-long v12, v12, v16

    .line 278
    .line 279
    and-long v14, v14, v17

    .line 280
    .line 281
    or-long/2addr v12, v14

    .line 282
    move-wide/from16 v19, v9

    .line 283
    .line 284
    move-object v10, v4

    .line 285
    move-wide/from16 v4, v19

    .line 286
    .line 287
    move-wide v8, v12

    .line 288
    invoke-virtual/range {v1 .. v10}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->drawRoundRect-u-Aw5IA(JJJJLandroidx/compose/ui/graphics/drawscope/DrawStyle;)V

    .line 289
    .line 290
    .line 291
    move-object v4, v10

    .line 292
    goto :goto_13d

    .line 293
    :cond_124
    move/from16 v16, v12

    .line 294
    .line 295
    move-wide/from16 v17, v13

    .line 296
    .line 297
    instance-of v5, v11, Landroidx/compose/ui/graphics/Outline$Generic;

    .line 298
    .line 299
    if-eqz v5, :cond_135

    .line 300
    .line 301
    move-object v5, v11

    .line 302
    check-cast v5, Landroidx/compose/ui/graphics/Outline$Generic;

    .line 303
    .line 304
    iget-object v5, v5, Landroidx/compose/ui/graphics/Outline$Generic;->path:Landroidx/compose/ui/graphics/Path;

    .line 305
    .line 306
    invoke-virtual {v1, v5, v2, v3, v4}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->drawPath-LG529CI(Landroidx/compose/ui/graphics/Path;JLandroidx/compose/ui/graphics/drawscope/DrawStyle;)V

    .line 307
    .line 308
    .line 309
    goto :goto_13d

    .line 310
    :cond_135
    invoke-static {}, Lcoil/util/-Utils$$ExternalSyntheticBUOutline0;->m$1()V

    .line 311
    .line 312
    .line 313
    return-void

    .line 314
    :cond_139
    :goto_139
    move/from16 v16, v12

    .line 315
    .line 316
    move-wide/from16 v17, v13

    .line 317
    .line 318
    :goto_13d
    iget-object v2, v0, Landroidx/compose/foundation/BackgroundNode;->brush:Landroidx/compose/ui/graphics/Brush;

    .line 319
    .line 320
    if-eqz v2, :cond_1e9

    .line 321
    .line 322
    iget v3, v0, Landroidx/compose/foundation/BackgroundNode;->alpha:F

    .line 323
    .line 324
    instance-of v0, v11, Landroidx/compose/ui/graphics/Outline$Rectangle;

    .line 325
    .line 326
    if-eqz v0, :cond_173

    .line 327
    .line 328
    check-cast v11, Landroidx/compose/ui/graphics/Outline$Rectangle;

    .line 329
    .line 330
    iget-object v0, v11, Landroidx/compose/ui/graphics/Outline$Rectangle;->rect:Landroidx/compose/ui/geometry/Rect;

    .line 331
    .line 332
    iget v5, v0, Landroidx/compose/ui/geometry/Rect;->left:F

    .line 333
    .line 334
    iget v6, v0, Landroidx/compose/ui/geometry/Rect;->top:F

    .line 335
    .line 336
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 337
    .line 338
    .line 339
    move-result v5

    .line 340
    int-to-long v7, v5

    .line 341
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 342
    .line 343
    .line 344
    move-result v5

    .line 345
    int-to-long v5, v5

    .line 346
    shl-long v7, v7, v16

    .line 347
    .line 348
    and-long v5, v5, v17

    .line 349
    .line 350
    or-long/2addr v5, v7

    .line 351
    invoke-static {v0}, Landroidx/compose/ui/graphics/ColorKt;->size(Landroidx/compose/ui/geometry/Rect;)J

    .line 352
    .line 353
    .line 354
    move-result-wide v7

    .line 355
    move-object v0, v1

    .line 356
    move-object v1, v2

    .line 357
    move-wide/from16 v19, v5

    .line 358
    .line 359
    move v6, v3

    .line 360
    move-wide/from16 v2, v19

    .line 361
    .line 362
    move-wide/from16 v19, v7

    .line 363
    .line 364
    move-object v7, v4

    .line 365
    move-wide/from16 v4, v19

    .line 366
    .line 367
    invoke-virtual/range {v0 .. v7}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->drawRect-AsUm42w(Landroidx/compose/ui/graphics/Brush;JJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;)V

    .line 368
    .line 369
    .line 370
    goto/16 :goto_1e9

    .line 371
    .line 372
    :cond_173
    move-object v1, v2

    .line 373
    instance-of v0, v11, Landroidx/compose/ui/graphics/Outline$Rounded;

    .line 374
    .line 375
    const/4 v5, 0x3

    .line 376
    if-eqz v0, :cond_1da

    .line 377
    .line 378
    check-cast v11, Landroidx/compose/ui/graphics/Outline$Rounded;

    .line 379
    .line 380
    move-object v2, v1

    .line 381
    iget-object v1, v11, Landroidx/compose/ui/graphics/Outline$Rounded;->roundRectPath:Landroidx/compose/ui/graphics/AndroidPath;

    .line 382
    .line 383
    if-eqz v1, :cond_186

    .line 384
    .line 385
    :goto_180
    move-object/from16 v0, p1

    .line 386
    .line 387
    invoke-virtual/range {v0 .. v5}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->drawPath-GBMwjPU(Landroidx/compose/ui/graphics/Path;Landroidx/compose/ui/graphics/Brush;FLandroidx/compose/ui/graphics/drawscope/DrawStyle;I)V

    .line 388
    .line 389
    .line 390
    goto :goto_1e9

    .line 391
    :cond_186
    move-object v1, v2

    .line 392
    iget-object v0, v11, Landroidx/compose/ui/graphics/Outline$Rounded;->roundRect:Landroidx/compose/ui/geometry/RoundRect;

    .line 393
    .line 394
    iget v2, v0, Landroidx/compose/ui/geometry/RoundRect;->top:F

    .line 395
    .line 396
    iget v5, v0, Landroidx/compose/ui/geometry/RoundRect;->left:F

    .line 397
    .line 398
    iget-wide v6, v0, Landroidx/compose/ui/geometry/RoundRect;->bottomLeftCornerRadius:J

    .line 399
    .line 400
    shr-long v6, v6, v16

    .line 401
    .line 402
    long-to-int v6, v6

    .line 403
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 404
    .line 405
    .line 406
    move-result v6

    .line 407
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 408
    .line 409
    .line 410
    move-result v7

    .line 411
    int-to-long v7, v7

    .line 412
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 413
    .line 414
    .line 415
    move-result v9

    .line 416
    int-to-long v9, v9

    .line 417
    shl-long v7, v7, v16

    .line 418
    .line 419
    and-long v9, v9, v17

    .line 420
    .line 421
    or-long/2addr v7, v9

    .line 422
    iget v9, v0, Landroidx/compose/ui/geometry/RoundRect;->right:F

    .line 423
    .line 424
    sub-float/2addr v9, v5

    .line 425
    iget v0, v0, Landroidx/compose/ui/geometry/RoundRect;->bottom:F

    .line 426
    .line 427
    sub-float/2addr v0, v2

    .line 428
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 429
    .line 430
    .line 431
    move-result v2

    .line 432
    int-to-long v9, v2

    .line 433
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 434
    .line 435
    .line 436
    move-result v0

    .line 437
    int-to-long v11, v0

    .line 438
    shl-long v9, v9, v16

    .line 439
    .line 440
    and-long v11, v11, v17

    .line 441
    .line 442
    or-long/2addr v9, v11

    .line 443
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 444
    .line 445
    .line 446
    move-result v0

    .line 447
    int-to-long v11, v0

    .line 448
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 449
    .line 450
    .line 451
    move-result v0

    .line 452
    int-to-long v5, v0

    .line 453
    shl-long v11, v11, v16

    .line 454
    .line 455
    and-long v5, v5, v17

    .line 456
    .line 457
    or-long/2addr v5, v11

    .line 458
    move-wide/from16 v19, v7

    .line 459
    .line 460
    move v8, v3

    .line 461
    move-wide/from16 v2, v19

    .line 462
    .line 463
    move-object/from16 v0, p1

    .line 464
    .line 465
    move-wide v6, v5

    .line 466
    move-wide/from16 v19, v9

    .line 467
    .line 468
    move-object v9, v4

    .line 469
    move-wide/from16 v4, v19

    .line 470
    .line 471
    invoke-virtual/range {v0 .. v9}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->drawRoundRect-ZuiqVtQ(Landroidx/compose/ui/graphics/Brush;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;)V

    .line 472
    .line 473
    .line 474
    goto :goto_1e9

    .line 475
    :cond_1da
    instance-of v0, v11, Landroidx/compose/ui/graphics/Outline$Generic;

    .line 476
    .line 477
    if-eqz v0, :cond_1e5

    .line 478
    .line 479
    check-cast v11, Landroidx/compose/ui/graphics/Outline$Generic;

    .line 480
    .line 481
    iget-object v0, v11, Landroidx/compose/ui/graphics/Outline$Generic;->path:Landroidx/compose/ui/graphics/Path;

    .line 482
    .line 483
    move-object v2, v1

    .line 484
    move-object v1, v0

    .line 485
    goto :goto_180

    .line 486
    :cond_1e5
    invoke-static {}, Lcoil/util/-Utils$$ExternalSyntheticBUOutline0;->m$1()V

    .line 487
    .line 488
    .line 489
    return-void

    .line 490
    :cond_1e9
    :goto_1e9
    invoke-virtual/range {p1 .. p1}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->drawContent()V

    .line 491
    .line 492
    .line 493
    return-void
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
.end method

.method public final isImportantForBounds()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
.end method

.method public final onObservedReadsChanged()V
    .registers 3

    .line 1
    const-wide v0, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    iput-wide v0, p0, Landroidx/compose/foundation/BackgroundNode;->lastSize:J

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, Landroidx/compose/foundation/BackgroundNode;->lastLayoutDirection:Landroidx/compose/ui/unit/LayoutDirection;

    .line 10
    .line 11
    iput-object v0, p0, Landroidx/compose/foundation/BackgroundNode;->lastOutline:Landroidx/compose/ui/graphics/ColorKt;

    .line 12
    .line 13
    iput-object v0, p0, Landroidx/compose/foundation/BackgroundNode;->lastShape:Landroidx/compose/ui/graphics/Shape;

    .line 14
    .line 15
    invoke-static {p0}, Landroidx/compose/ui/node/HitTestResultKt;->invalidateDraw(Landroidx/compose/ui/node/DrawModifierNode;)V

    .line 16
    .line 17
    .line 18
    return-void
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
.end method
