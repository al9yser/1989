.class public final synthetic Landroidx/compose/foundation/BorderKt$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic $r8$classId:B


# direct methods
.method public synthetic constructor <init>(B)V
    .registers 2

    .line 1
    iput-byte p1, p0, Landroidx/compose/foundation/BorderKt$$ExternalSyntheticLambda1;->$r8$classId:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .line 1
    iget-byte p0, p0, Landroidx/compose/foundation/BorderKt$$ExternalSyntheticLambda1;->$r8$classId:B

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    .line 6
    const-wide v2, 0xffffffffL

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    const/16 v4, 0x20

    .line 12
    .line 13
    packed-switch p0, :pswitch_data_1ec

    .line 14
    .line 15
    .line 16
    check-cast p1, Landroidx/compose/ui/layout/Placeable$PlacementScope;

    .line 17
    .line 18
    return-object v1

    .line 19
    :pswitch_12
    check-cast p1, Landroidx/compose/ui/layout/Placeable$PlacementScope;

    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_15
    check-cast p1, Landroidx/compose/ui/layout/Placeable$PlacementScope;

    .line 23
    .line 24
    return-object v1

    .line 25
    :pswitch_18
    check-cast p1, Ljava/lang/Long;

    .line 26
    .line 27
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    return-object v1

    .line 31
    :pswitch_1e
    check-cast p1, Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 32
    .line 33
    sget-object p0, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->LocalContext:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 34
    .line 35
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    invoke-static {p1, p0}, Landroidx/compose/runtime/Updater;->read(Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    check-cast p0, Landroid/content/Context;

    .line 43
    .line 44
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    const-string p1, "android.software.leanback"

    .line 49
    .line 50
    invoke-virtual {p0, p1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    if-nez p0, :cond_3f

    .line 55
    .line 56
    sget-object p0, Landroidx/compose/foundation/gestures/BringIntoViewSpec;->Companion:Landroidx/compose/foundation/gestures/BringIntoViewSpec$Companion;

    .line 57
    .line 58
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    sget-object p0, Landroidx/compose/foundation/gestures/BringIntoViewSpec$Companion;->DefaultBringIntoViewSpec:Landroidx/compose/foundation/gestures/BringIntoViewSpec$Companion$DefaultBringIntoViewSpec$1;

    .line 62
    .line 63
    goto :goto_41

    .line 64
    :cond_3f
    sget-object p0, Landroidx/compose/foundation/gestures/BringIntoViewSpec_androidKt;->PivotBringIntoViewSpec:Landroidx/compose/foundation/gestures/BringIntoViewSpec_androidKt$PivotBringIntoViewSpec$1;

    .line 65
    .line 66
    :goto_41
    return-object p0

    .line 67
    :pswitch_42
    check-cast p1, Landroidx/compose/ui/input/pointer/PointerType;

    .line 68
    .line 69
    xor-int/lit8 p0, v0, 0x1

    .line 70
    .line 71
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 72
    .line 73
    .line 74
    move-result-object p0

    .line 75
    return-object p0

    .line 76
    :pswitch_4b
    check-cast p1, Ljava/lang/Integer;

    .line 77
    .line 78
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 79
    .line 80
    .line 81
    move-result p0

    .line 82
    new-instance p1, Landroidx/compose/foundation/ScrollState;

    .line 83
    .line 84
    invoke-direct {p1, p0}, Landroidx/compose/foundation/ScrollState;-><init>(I)V

    .line 85
    .line 86
    .line 87
    return-object p1

    .line 88
    :pswitch_57
    check-cast p1, Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 89
    .line 90
    sget p0, Landroidx/compose/foundation/AndroidOverscroll_androidKt;->$r8$clinit:I

    .line 91
    .line 92
    sget-object p0, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->LocalContext:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 93
    .line 94
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 95
    .line 96
    .line 97
    invoke-static {p1, p0}, Landroidx/compose/runtime/Updater;->read(Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object p0

    .line 101
    move-object v1, p0

    .line 102
    check-cast v1, Landroid/content/Context;

    .line 103
    .line 104
    sget-object p0, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 105
    .line 106
    invoke-static {p1, p0}, Landroidx/compose/runtime/Updater;->read(Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    move-object v2, p0

    .line 111
    check-cast v2, Landroidx/compose/ui/unit/Density;

    .line 112
    .line 113
    sget-object p0, Landroidx/compose/foundation/OverscrollConfiguration_androidKt;->LocalOverscrollConfiguration:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 114
    .line 115
    invoke-static {p1, p0}, Landroidx/compose/runtime/Updater;->read(Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object p0

    .line 119
    check-cast p0, Landroidx/compose/foundation/OverscrollConfiguration;

    .line 120
    .line 121
    if-nez p0, :cond_7c

    .line 122
    .line 123
    const/4 p0, 0x0

    .line 124
    goto :goto_86

    .line 125
    :cond_7c
    new-instance v0, Landroidx/compose/foundation/AndroidEdgeEffectOverscrollFactory;

    .line 126
    .line 127
    iget-wide v3, p0, Landroidx/compose/foundation/OverscrollConfiguration;->glowColor:J

    .line 128
    .line 129
    iget-object v5, p0, Landroidx/compose/foundation/OverscrollConfiguration;->drawPadding:Landroidx/compose/foundation/layout/PaddingValuesImpl;

    .line 130
    .line 131
    invoke-direct/range {v0 .. v5}, Landroidx/compose/foundation/AndroidEdgeEffectOverscrollFactory;-><init>(Landroid/content/Context;Landroidx/compose/ui/unit/Density;JLandroidx/compose/foundation/layout/PaddingValuesImpl;)V

    .line 132
    .line 133
    .line 134
    move-object p0, v0

    .line 135
    :goto_86
    return-object p0

    .line 136
    :pswitch_87
    check-cast p1, Ljava/lang/Long;

    .line 137
    .line 138
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 139
    .line 140
    .line 141
    return-object v1

    .line 142
    :pswitch_8d
    check-cast p1, Landroidx/compose/ui/layout/Placeable$PlacementScope;

    .line 143
    .line 144
    return-object v1

    .line 145
    :pswitch_90
    check-cast p1, Landroidx/compose/animation/core/AnimationVector1D;

    .line 146
    .line 147
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector1D;->value:F

    .line 148
    .line 149
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 150
    .line 151
    .line 152
    move-result-object p0

    .line 153
    return-object p0

    .line 154
    :pswitch_99
    check-cast p1, Landroidx/compose/animation/core/AnimationVector4D;

    .line 155
    .line 156
    new-instance p0, Landroidx/compose/ui/geometry/Rect;

    .line 157
    .line 158
    iget v0, p1, Landroidx/compose/animation/core/AnimationVector4D;->v1:F

    .line 159
    .line 160
    iget v1, p1, Landroidx/compose/animation/core/AnimationVector4D;->v2:F

    .line 161
    .line 162
    iget v2, p1, Landroidx/compose/animation/core/AnimationVector4D;->v3:F

    .line 163
    .line 164
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector4D;->v4:F

    .line 165
    .line 166
    invoke-direct {p0, v0, v1, v2, p1}, Landroidx/compose/ui/geometry/Rect;-><init>(FFFF)V

    .line 167
    .line 168
    .line 169
    return-object p0

    .line 170
    :pswitch_a9
    check-cast p1, Landroidx/compose/ui/geometry/Rect;

    .line 171
    .line 172
    new-instance p0, Landroidx/compose/animation/core/AnimationVector4D;

    .line 173
    .line 174
    iget v0, p1, Landroidx/compose/ui/geometry/Rect;->left:F

    .line 175
    .line 176
    iget v1, p1, Landroidx/compose/ui/geometry/Rect;->top:F

    .line 177
    .line 178
    iget v2, p1, Landroidx/compose/ui/geometry/Rect;->right:F

    .line 179
    .line 180
    iget p1, p1, Landroidx/compose/ui/geometry/Rect;->bottom:F

    .line 181
    .line 182
    invoke-direct {p0, v0, v1, v2, p1}, Landroidx/compose/animation/core/AnimationVector4D;-><init>(FFFF)V

    .line 183
    .line 184
    .line 185
    return-object p0

    .line 186
    :pswitch_b9
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 187
    .line 188
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 189
    .line 190
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 191
    .line 192
    .line 193
    move-result p0

    .line 194
    if-gez p0, :cond_c4

    .line 195
    .line 196
    move p0, v0

    .line 197
    :cond_c4
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 198
    .line 199
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    .line 200
    .line 201
    .line 202
    move-result p1

    .line 203
    if-gez p1, :cond_cd

    .line 204
    .line 205
    goto :goto_ce

    .line 206
    :cond_cd
    move v0, p1

    .line 207
    :goto_ce
    int-to-long p0, p0

    .line 208
    shl-long/2addr p0, v4

    .line 209
    int-to-long v0, v0

    .line 210
    and-long/2addr v0, v2

    .line 211
    or-long/2addr p0, v0

    .line 212
    new-instance v0, Landroidx/compose/ui/unit/IntSize;

    .line 213
    .line 214
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/unit/IntSize;-><init>(J)V

    .line 215
    .line 216
    .line 217
    return-object v0

    .line 218
    :pswitch_d9
    check-cast p1, Landroidx/compose/ui/unit/IntSize;

    .line 219
    .line 220
    new-instance p0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 221
    .line 222
    iget-wide v0, p1, Landroidx/compose/ui/unit/IntSize;->packedValue:J

    .line 223
    .line 224
    shr-long v4, v0, v4

    .line 225
    .line 226
    long-to-int p1, v4

    .line 227
    int-to-float p1, p1

    .line 228
    and-long/2addr v0, v2

    .line 229
    long-to-int v0, v0

    .line 230
    int-to-float v0, v0

    .line 231
    invoke-direct {p0, p1, v0}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 232
    .line 233
    .line 234
    return-object p0

    .line 235
    :pswitch_ea
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 236
    .line 237
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 238
    .line 239
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 240
    .line 241
    .line 242
    move-result p0

    .line 243
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 244
    .line 245
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    .line 246
    .line 247
    .line 248
    move-result p1

    .line 249
    int-to-long v0, p0

    .line 250
    shl-long/2addr v0, v4

    .line 251
    int-to-long p0, p1

    .line 252
    and-long/2addr p0, v2

    .line 253
    or-long/2addr p0, v0

    .line 254
    new-instance v0, Landroidx/compose/ui/unit/IntOffset;

    .line 255
    .line 256
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/unit/IntOffset;-><init>(J)V

    .line 257
    .line 258
    .line 259
    return-object v0

    .line 260
    :pswitch_103
    check-cast p1, Landroidx/compose/ui/unit/IntOffset;

    .line 261
    .line 262
    new-instance p0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 263
    .line 264
    iget-wide v0, p1, Landroidx/compose/ui/unit/IntOffset;->packedValue:J

    .line 265
    .line 266
    shr-long v4, v0, v4

    .line 267
    .line 268
    long-to-int p1, v4

    .line 269
    int-to-float p1, p1

    .line 270
    and-long/2addr v0, v2

    .line 271
    long-to-int v0, v0

    .line 272
    int-to-float v0, v0

    .line 273
    invoke-direct {p0, p1, v0}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 274
    .line 275
    .line 276
    return-object p0

    .line 277
    :pswitch_114
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 278
    .line 279
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 280
    .line 281
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 282
    .line 283
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 284
    .line 285
    .line 286
    move-result p0

    .line 287
    int-to-long v0, p0

    .line 288
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 289
    .line 290
    .line 291
    move-result p0

    .line 292
    int-to-long p0, p0

    .line 293
    shl-long/2addr v0, v4

    .line 294
    and-long/2addr p0, v2

    .line 295
    or-long/2addr p0, v0

    .line 296
    new-instance v0, Landroidx/compose/ui/geometry/Offset;

    .line 297
    .line 298
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/geometry/Offset;-><init>(J)V

    .line 299
    .line 300
    .line 301
    return-object v0

    .line 302
    :pswitch_12d
    check-cast p1, Landroidx/compose/ui/geometry/Offset;

    .line 303
    .line 304
    new-instance p0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 305
    .line 306
    iget-wide v0, p1, Landroidx/compose/ui/geometry/Offset;->packedValue:J

    .line 307
    .line 308
    shr-long/2addr v0, v4

    .line 309
    long-to-int v0, v0

    .line 310
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 311
    .line 312
    .line 313
    move-result v0

    .line 314
    iget-wide v4, p1, Landroidx/compose/ui/geometry/Offset;->packedValue:J

    .line 315
    .line 316
    and-long v1, v4, v2

    .line 317
    .line 318
    long-to-int p1, v1

    .line 319
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 320
    .line 321
    .line 322
    move-result p1

    .line 323
    invoke-direct {p0, v0, p1}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 324
    .line 325
    .line 326
    return-object p0

    .line 327
    :pswitch_146
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 328
    .line 329
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 330
    .line 331
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 332
    .line 333
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 334
    .line 335
    .line 336
    move-result p0

    .line 337
    int-to-long v0, p0

    .line 338
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 339
    .line 340
    .line 341
    move-result p0

    .line 342
    int-to-long p0, p0

    .line 343
    shl-long/2addr v0, v4

    .line 344
    and-long/2addr p0, v2

    .line 345
    or-long/2addr p0, v0

    .line 346
    new-instance v0, Landroidx/compose/ui/geometry/Size;

    .line 347
    .line 348
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/geometry/Size;-><init>(J)V

    .line 349
    .line 350
    .line 351
    return-object v0

    .line 352
    :pswitch_15f
    check-cast p1, Landroidx/compose/ui/geometry/Size;

    .line 353
    .line 354
    new-instance p0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 355
    .line 356
    iget-wide v0, p1, Landroidx/compose/ui/geometry/Size;->packedValue:J

    .line 357
    .line 358
    shr-long/2addr v0, v4

    .line 359
    long-to-int v0, v0

    .line 360
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 361
    .line 362
    .line 363
    move-result v0

    .line 364
    iget-wide v4, p1, Landroidx/compose/ui/geometry/Size;->packedValue:J

    .line 365
    .line 366
    and-long v1, v4, v2

    .line 367
    .line 368
    long-to-int p1, v1

    .line 369
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 370
    .line 371
    .line 372
    move-result p1

    .line 373
    invoke-direct {p0, v0, p1}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 374
    .line 375
    .line 376
    return-object p0

    .line 377
    :pswitch_178
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 378
    .line 379
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 380
    .line 381
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 382
    .line 383
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 384
    .line 385
    .line 386
    move-result p0

    .line 387
    int-to-long v0, p0

    .line 388
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 389
    .line 390
    .line 391
    move-result p0

    .line 392
    int-to-long p0, p0

    .line 393
    shl-long/2addr v0, v4

    .line 394
    and-long/2addr p0, v2

    .line 395
    or-long/2addr p0, v0

    .line 396
    new-instance v0, Landroidx/compose/ui/unit/DpOffset;

    .line 397
    .line 398
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/unit/DpOffset;-><init>(J)V

    .line 399
    .line 400
    .line 401
    return-object v0

    .line 402
    :pswitch_191
    check-cast p1, Landroidx/compose/ui/unit/DpOffset;

    .line 403
    .line 404
    new-instance p0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 405
    .line 406
    iget-wide v0, p1, Landroidx/compose/ui/unit/DpOffset;->packedValue:J

    .line 407
    .line 408
    shr-long/2addr v0, v4

    .line 409
    long-to-int v0, v0

    .line 410
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 411
    .line 412
    .line 413
    move-result v0

    .line 414
    iget-wide v4, p1, Landroidx/compose/ui/unit/DpOffset;->packedValue:J

    .line 415
    .line 416
    and-long v1, v4, v2

    .line 417
    .line 418
    long-to-int p1, v1

    .line 419
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 420
    .line 421
    .line 422
    move-result p1

    .line 423
    invoke-direct {p0, v0, p1}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 424
    .line 425
    .line 426
    return-object p0

    .line 427
    :pswitch_1aa
    check-cast p1, Landroidx/compose/animation/core/AnimationVector1D;

    .line 428
    .line 429
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector1D;->value:F

    .line 430
    .line 431
    new-instance p1, Landroidx/compose/ui/unit/Dp;

    .line 432
    .line 433
    invoke-direct {p1, p0}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 434
    .line 435
    .line 436
    return-object p1

    .line 437
    :pswitch_1b4
    check-cast p1, Landroidx/compose/ui/unit/Dp;

    .line 438
    .line 439
    new-instance p0, Landroidx/compose/animation/core/AnimationVector1D;

    .line 440
    .line 441
    iget p1, p1, Landroidx/compose/ui/unit/Dp;->value:F

    .line 442
    .line 443
    invoke-direct {p0, p1}, Landroidx/compose/animation/core/AnimationVector1D;-><init>(F)V

    .line 444
    .line 445
    .line 446
    return-object p0

    .line 447
    :pswitch_1be
    check-cast p1, Landroidx/compose/animation/core/AnimationVector1D;

    .line 448
    .line 449
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector1D;->value:F

    .line 450
    .line 451
    float-to-int p0, p0

    .line 452
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 453
    .line 454
    .line 455
    move-result-object p0

    .line 456
    return-object p0

    .line 457
    :pswitch_1c8
    check-cast p1, Ljava/lang/Integer;

    .line 458
    .line 459
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 460
    .line 461
    .line 462
    move-result p0

    .line 463
    new-instance p1, Landroidx/compose/animation/core/AnimationVector1D;

    .line 464
    .line 465
    int-to-float p0, p0

    .line 466
    invoke-direct {p1, p0}, Landroidx/compose/animation/core/AnimationVector1D;-><init>(F)V

    .line 467
    .line 468
    .line 469
    return-object p1

    .line 470
    :pswitch_1d5
    check-cast p1, Ljava/lang/Float;

    .line 471
    .line 472
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 473
    .line 474
    .line 475
    move-result p0

    .line 476
    new-instance p1, Landroidx/compose/animation/core/AnimationVector1D;

    .line 477
    .line 478
    invoke-direct {p1, p0}, Landroidx/compose/animation/core/AnimationVector1D;-><init>(F)V

    .line 479
    .line 480
    .line 481
    return-object p1

    .line 482
    :pswitch_1e1
    check-cast p1, Landroidx/compose/animation/core/AnimationScope;

    .line 483
    .line 484
    return-object v1

    .line 485
    :pswitch_1e4
    check-cast p1, Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;

    .line 486
    .line 487
    check-cast p1, Landroidx/compose/ui/node/LayoutNodeDrawScope;

    .line 488
    .line 489
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->drawContent()V

    .line 490
    .line 491
    .line 492
    return-object v1

    .line 493
    :pswitch_data_1ec
    .packed-switch 0x0
        :pswitch_1e4
        :pswitch_1e1
        :pswitch_1d5
        :pswitch_1c8
        :pswitch_1be
        :pswitch_1b4
        :pswitch_1aa
        :pswitch_191
        :pswitch_178
        :pswitch_15f
        :pswitch_146
        :pswitch_12d
        :pswitch_114
        :pswitch_103
        :pswitch_ea
        :pswitch_d9
        :pswitch_b9
        :pswitch_a9
        :pswitch_99
        :pswitch_90
        :pswitch_8d
        :pswitch_87
        :pswitch_57
        :pswitch_4b
        :pswitch_42
        :pswitch_1e
        :pswitch_18
        :pswitch_15
        :pswitch_12
    .end packed-switch
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
.end method
