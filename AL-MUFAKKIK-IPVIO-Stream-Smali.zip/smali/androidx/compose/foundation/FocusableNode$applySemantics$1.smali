.class public final synthetic Landroidx/compose/foundation/FocusableNode$applySemantics$1;
.super Lkotlin/jvm/internal/FunctionReferenceImpl;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic $r8$classId:B


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V
    .registers 8

    .line 1
    iput-byte p7, p0, Landroidx/compose/foundation/FocusableNode$applySemantics$1;->$r8$classId:B

    .line 2
    .line 3
    invoke-direct/range {p0 .. p6}, Lkotlin/jvm/internal/FunctionReferenceImpl;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Landroidx/compose/foundation/FocusableNode$applySemantics$1;->$r8$classId:B

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object v0, v0, Lkotlin/jvm/internal/CallableReference;->receiver:Ljava/lang/Object;

    .line 7
    .line 8
    packed-switch v1, :pswitch_data_168

    .line 9
    .line 10
    .line 11
    check-cast v0, Landroid/view/View;

    .line 12
    .line 13
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 14
    .line 15
    const/16 v3, 0x1e

    .line 16
    .line 17
    if-lt v1, v3, :cond_15

    .line 18
    .line 19
    invoke-static {v0}, Landroidx/core/os/BuildCompat$Api30Impl;->setImportantForContentCapture(Landroid/view/View;)V

    .line 20
    .line 21
    .line 22
    :cond_15
    const/16 v3, 0x1d

    .line 23
    .line 24
    if-lt v1, v3, :cond_25

    .line 25
    .line 26
    invoke-static {v0}, Landroidx/core/graphics/Insets$Api29Impl;->getContentCaptureSession(Landroid/view/View;)Landroid/view/contentcapture/ContentCaptureSession;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    if-nez v1, :cond_20

    .line 31
    .line 32
    goto :goto_25

    .line 33
    :cond_20
    new-instance v2, Lcoil/memory/RealStrongMemoryCache;

    .line 34
    .line 35
    invoke-direct {v2, v1, v0}, Lcoil/memory/RealStrongMemoryCache;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    :cond_25
    :goto_25
    return-object v2

    .line 39
    :pswitch_26
    check-cast v0, Landroidx/compose/ui/focus/FocusInvalidationManager;

    .line 40
    .line 41
    iget-object v1, v0, Landroidx/compose/ui/focus/FocusInvalidationManager;->focusTargetNodes:Landroidx/collection/MutableScatterSet;

    .line 42
    .line 43
    iget-object v3, v0, Landroidx/compose/ui/focus/FocusInvalidationManager;->focusEventNodes:Landroidx/collection/MutableScatterSet;

    .line 44
    .line 45
    iget-object v4, v0, Landroidx/compose/ui/focus/FocusInvalidationManager;->focusOwner:Landroidx/compose/ui/focus/FocusOwnerImpl;

    .line 46
    .line 47
    invoke-virtual {v4}, Landroidx/compose/ui/focus/FocusOwnerImpl;->getActiveFocusTargetNode()Landroidx/compose/ui/focus/FocusTargetNode;

    .line 48
    .line 49
    .line 50
    move-result-object v5

    .line 51
    sget-object v6, Landroidx/compose/ui/focus/FocusStateImpl;->Inactive:Landroidx/compose/ui/focus/FocusStateImpl;

    .line 52
    .line 53
    const/16 v14, 0x8

    .line 54
    .line 55
    const/4 v15, 0x0

    .line 56
    if-nez v5, :cond_7f

    .line 57
    .line 58
    iget-object v2, v3, Landroidx/collection/MutableScatterSet;->elements:[Ljava/lang/Object;

    .line 59
    .line 60
    iget-object v5, v3, Landroidx/collection/MutableScatterSet;->metadata:[J

    .line 61
    .line 62
    const-wide/16 v16, 0x80

    .line 63
    .line 64
    array-length v7, v5

    .line 65
    add-int/lit8 v7, v7, -0x2

    .line 66
    .line 67
    if-ltz v7, :cond_138

    .line 68
    .line 69
    move v8, v15

    .line 70
    const-wide/16 v18, 0xff

    .line 71
    .line 72
    :goto_47
    aget-wide v9, v5, v8

    .line 73
    .line 74
    const/16 p0, 0x7

    .line 75
    .line 76
    const-wide v20, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    not-long v11, v9

    .line 82
    shl-long v11, v11, p0

    .line 83
    .line 84
    and-long/2addr v11, v9

    .line 85
    and-long v11, v11, v20

    .line 86
    .line 87
    cmp-long v11, v11, v20

    .line 88
    .line 89
    if-eqz v11, :cond_7a

    .line 90
    .line 91
    sub-int v11, v8, v7

    .line 92
    .line 93
    not-int v11, v11

    .line 94
    ushr-int/lit8 v11, v11, 0x1f

    .line 95
    .line 96
    rsub-int/lit8 v11, v11, 0x8

    .line 97
    .line 98
    move v12, v15

    .line 99
    :goto_62
    if-ge v12, v11, :cond_78

    .line 100
    .line 101
    and-long v22, v9, v18

    .line 102
    .line 103
    cmp-long v13, v22, v16

    .line 104
    .line 105
    if-gez v13, :cond_74

    .line 106
    .line 107
    shl-int/lit8 v13, v8, 0x3

    .line 108
    .line 109
    add-int/2addr v13, v12

    .line 110
    aget-object v13, v2, v13

    .line 111
    .line 112
    check-cast v13, Landroidx/compose/ui/focus/FocusEventModifierNode;

    .line 113
    .line 114
    invoke-interface {v13, v6}, Landroidx/compose/ui/focus/FocusEventModifierNode;->onFocusEvent(Landroidx/compose/ui/focus/FocusState;)V

    .line 115
    .line 116
    .line 117
    :cond_74
    shr-long/2addr v9, v14

    .line 118
    add-int/lit8 v12, v12, 0x1

    .line 119
    .line 120
    goto :goto_62

    .line 121
    :cond_78
    if-ne v11, v14, :cond_138

    .line 122
    .line 123
    :cond_7a
    if-eq v8, v7, :cond_138

    .line 124
    .line 125
    add-int/lit8 v8, v8, 0x1

    .line 126
    .line 127
    goto :goto_47

    .line 128
    :cond_7f
    const/16 p0, 0x7

    .line 129
    .line 130
    const-wide/16 v16, 0x80

    .line 131
    .line 132
    const-wide/16 v18, 0xff

    .line 133
    .line 134
    const-wide v20, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    iget-boolean v7, v5, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 140
    .line 141
    if-eqz v7, :cond_138

    .line 142
    .line 143
    invoke-virtual {v1, v5}, Landroidx/collection/MutableScatterSet;->contains(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    move-result v7

    .line 147
    if-eqz v7, :cond_97

    .line 148
    .line 149
    invoke-virtual {v5}, Landroidx/compose/ui/focus/FocusTargetNode;->invalidateFocus$ui()V

    .line 150
    .line 151
    .line 152
    :cond_97
    invoke-virtual {v5}, Landroidx/compose/ui/focus/FocusTargetNode;->getFocusState()Landroidx/compose/ui/focus/FocusStateImpl;

    .line 153
    .line 154
    .line 155
    move-result-object v7

    .line 156
    iget-object v8, v5, Landroidx/compose/ui/Modifier$Node;->node:Landroidx/compose/ui/Modifier$Node;

    .line 157
    .line 158
    iget-boolean v8, v8, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 159
    .line 160
    if-nez v8, :cond_a6

    .line 161
    .line 162
    const-string v8, "visitAncestors called on an unattached node"

    .line 163
    .line 164
    invoke-static {v8}, Landroidx/compose/ui/internal/InlineClassHelperKt;->throwIllegalStateException(Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    :cond_a6
    iget-object v8, v5, Landroidx/compose/ui/Modifier$Node;->node:Landroidx/compose/ui/Modifier$Node;

    .line 168
    .line 169
    invoke-static {v5}, Landroidx/compose/ui/node/HitTestResultKt;->requireLayoutNode(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/node/LayoutNode;

    .line 170
    .line 171
    .line 172
    move-result-object v5

    .line 173
    move v9, v15

    .line 174
    :goto_ad
    if-eqz v5, :cond_fd

    .line 175
    .line 176
    iget-object v10, v5, Landroidx/compose/ui/node/LayoutNode;->nodes:Landroidx/compose/ui/node/NodeChain;

    .line 177
    .line 178
    iget-object v10, v10, Landroidx/compose/ui/node/NodeChain;->head:Ljava/lang/Object;

    .line 179
    .line 180
    check-cast v10, Landroidx/compose/ui/Modifier$Node;

    .line 181
    .line 182
    iget v10, v10, Landroidx/compose/ui/Modifier$Node;->aggregateChildKindSet:I

    .line 183
    .line 184
    and-int/lit16 v10, v10, 0x1400

    .line 185
    .line 186
    if-eqz v10, :cond_ec

    .line 187
    .line 188
    :goto_bb
    if-eqz v8, :cond_ec

    .line 189
    .line 190
    iget v10, v8, Landroidx/compose/ui/Modifier$Node;->kindSet:I

    .line 191
    .line 192
    and-int/lit16 v11, v10, 0x1400

    .line 193
    .line 194
    if-eqz v11, :cond_e9

    .line 195
    .line 196
    and-int/lit16 v10, v10, 0x400

    .line 197
    .line 198
    if-eqz v10, :cond_c9

    .line 199
    .line 200
    add-int/lit8 v9, v9, 0x1

    .line 201
    .line 202
    :cond_c9
    instance-of v10, v8, Landroidx/compose/ui/focus/FocusEventModifierNode;

    .line 203
    .line 204
    if-eqz v10, :cond_e9

    .line 205
    .line 206
    invoke-virtual {v3, v8}, Landroidx/collection/MutableScatterSet;->contains(Ljava/lang/Object;)Z

    .line 207
    .line 208
    .line 209
    move-result v10

    .line 210
    if-nez v10, :cond_d4

    .line 211
    .line 212
    goto :goto_e9

    .line 213
    :cond_d4
    const/4 v10, 0x1

    .line 214
    if-gt v9, v10, :cond_de

    .line 215
    .line 216
    move-object v10, v8

    .line 217
    check-cast v10, Landroidx/compose/ui/focus/FocusEventModifierNode;

    .line 218
    .line 219
    invoke-interface {v10, v7}, Landroidx/compose/ui/focus/FocusEventModifierNode;->onFocusEvent(Landroidx/compose/ui/focus/FocusState;)V

    .line 220
    .line 221
    .line 222
    goto :goto_e6

    .line 223
    :cond_de
    move-object v10, v8

    .line 224
    check-cast v10, Landroidx/compose/ui/focus/FocusEventModifierNode;

    .line 225
    .line 226
    sget-object v11, Landroidx/compose/ui/focus/FocusStateImpl;->ActiveParent:Landroidx/compose/ui/focus/FocusStateImpl;

    .line 227
    .line 228
    invoke-interface {v10, v11}, Landroidx/compose/ui/focus/FocusEventModifierNode;->onFocusEvent(Landroidx/compose/ui/focus/FocusState;)V

    .line 229
    .line 230
    .line 231
    :goto_e6
    invoke-virtual {v3, v8}, Landroidx/collection/MutableScatterSet;->remove(Ljava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    :cond_e9
    :goto_e9
    iget-object v8, v8, Landroidx/compose/ui/Modifier$Node;->parent:Landroidx/compose/ui/Modifier$Node;

    .line 235
    .line 236
    goto :goto_bb

    .line 237
    :cond_ec
    invoke-virtual {v5}, Landroidx/compose/ui/node/LayoutNode;->getParent$ui()Landroidx/compose/ui/node/LayoutNode;

    .line 238
    .line 239
    .line 240
    move-result-object v5

    .line 241
    if-eqz v5, :cond_fb

    .line 242
    .line 243
    iget-object v8, v5, Landroidx/compose/ui/node/LayoutNode;->nodes:Landroidx/compose/ui/node/NodeChain;

    .line 244
    .line 245
    if-eqz v8, :cond_fb

    .line 246
    .line 247
    iget-object v8, v8, Landroidx/compose/ui/node/NodeChain;->tail:Ljava/lang/Object;

    .line 248
    .line 249
    check-cast v8, Landroidx/compose/ui/node/TailModifierNode;

    .line 250
    .line 251
    goto :goto_ad

    .line 252
    :cond_fb
    move-object v8, v2

    .line 253
    goto :goto_ad

    .line 254
    :cond_fd
    iget-object v2, v3, Landroidx/collection/MutableScatterSet;->elements:[Ljava/lang/Object;

    .line 255
    .line 256
    iget-object v5, v3, Landroidx/collection/MutableScatterSet;->metadata:[J

    .line 257
    .line 258
    array-length v7, v5

    .line 259
    add-int/lit8 v7, v7, -0x2

    .line 260
    .line 261
    if-ltz v7, :cond_138

    .line 262
    .line 263
    move v8, v15

    .line 264
    :goto_107
    aget-wide v9, v5, v8

    .line 265
    .line 266
    not-long v11, v9

    .line 267
    shl-long v11, v11, p0

    .line 268
    .line 269
    and-long/2addr v11, v9

    .line 270
    and-long v11, v11, v20

    .line 271
    .line 272
    cmp-long v11, v11, v20

    .line 273
    .line 274
    if-eqz v11, :cond_133

    .line 275
    .line 276
    sub-int v11, v8, v7

    .line 277
    .line 278
    not-int v11, v11

    .line 279
    ushr-int/lit8 v11, v11, 0x1f

    .line 280
    .line 281
    rsub-int/lit8 v11, v11, 0x8

    .line 282
    .line 283
    move v12, v15

    .line 284
    :goto_11b
    if-ge v12, v11, :cond_131

    .line 285
    .line 286
    and-long v22, v9, v18

    .line 287
    .line 288
    cmp-long v13, v22, v16

    .line 289
    .line 290
    if-gez v13, :cond_12d

    .line 291
    .line 292
    shl-int/lit8 v13, v8, 0x3

    .line 293
    .line 294
    add-int/2addr v13, v12

    .line 295
    aget-object v13, v2, v13

    .line 296
    .line 297
    check-cast v13, Landroidx/compose/ui/focus/FocusEventModifierNode;

    .line 298
    .line 299
    invoke-interface {v13, v6}, Landroidx/compose/ui/focus/FocusEventModifierNode;->onFocusEvent(Landroidx/compose/ui/focus/FocusState;)V

    .line 300
    .line 301
    .line 302
    :cond_12d
    shr-long/2addr v9, v14

    .line 303
    add-int/lit8 v12, v12, 0x1

    .line 304
    .line 305
    goto :goto_11b

    .line 306
    :cond_131
    if-ne v11, v14, :cond_138

    .line 307
    .line 308
    :cond_133
    if-eq v8, v7, :cond_138

    .line 309
    .line 310
    add-int/lit8 v8, v8, 0x1

    .line 311
    .line 312
    goto :goto_107

    .line 313
    :cond_138
    invoke-virtual {v4}, Landroidx/compose/ui/focus/FocusOwnerImpl;->getActiveFocusTargetNode()Landroidx/compose/ui/focus/FocusTargetNode;

    .line 314
    .line 315
    .line 316
    move-result-object v2

    .line 317
    if-eqz v2, :cond_146

    .line 318
    .line 319
    iget-object v2, v4, Landroidx/compose/ui/focus/FocusOwnerImpl;->rootFocusNode:Landroidx/compose/ui/focus/FocusTargetNode;

    .line 320
    .line 321
    invoke-virtual {v2}, Landroidx/compose/ui/focus/FocusTargetNode;->getFocusState()Landroidx/compose/ui/focus/FocusStateImpl;

    .line 322
    .line 323
    .line 324
    move-result-object v2

    .line 325
    if-ne v2, v6, :cond_149

    .line 326
    .line 327
    :cond_146
    invoke-virtual {v4}, Landroidx/compose/ui/focus/FocusOwnerImpl;->clearOwnerFocus()V

    .line 328
    .line 329
    .line 330
    :cond_149
    invoke-virtual {v1}, Landroidx/collection/MutableScatterSet;->clear()V

    .line 331
    .line 332
    .line 333
    invoke-virtual {v3}, Landroidx/collection/MutableScatterSet;->clear()V

    .line 334
    .line 335
    .line 336
    iput-boolean v15, v0, Landroidx/compose/ui/focus/FocusInvalidationManager;->isInvalidationScheduled:Z

    .line 337
    .line 338
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 339
    .line 340
    return-object v0

    .line 341
    :pswitch_154
    check-cast v0, Landroidx/compose/foundation/text/contextmenu/provider/TextContextMenuDataProvider;

    .line 342
    .line 343
    invoke-interface {v0}, Landroidx/compose/foundation/text/contextmenu/provider/TextContextMenuDataProvider;->data()Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuData;

    .line 344
    .line 345
    .line 346
    move-result-object v0

    .line 347
    return-object v0

    .line 348
    :pswitch_15b
    check-cast v0, Landroidx/compose/foundation/FocusableNode;

    .line 349
    .line 350
    iget-object v0, v0, Landroidx/compose/foundation/FocusableNode;->focusTargetNode:Landroidx/compose/ui/focus/FocusTargetNode;

    .line 351
    .line 352
    invoke-static {v0}, Landroidx/compose/ui/focus/FocusTargetNode;->requestFocus-3ESFkO8$default(Landroidx/compose/ui/focus/FocusTargetNode;)Z

    .line 353
    .line 354
    .line 355
    move-result v0

    .line 356
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 357
    .line 358
    .line 359
    move-result-object v0

    .line 360
    return-object v0

    .line 361
    :pswitch_data_168
    .packed-switch 0x0
        :pswitch_15b
        :pswitch_154
        :pswitch_26
    .end packed-switch
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
.end method
