.class public final Landroidx/compose/foundation/MutatorMutex$mutate$2;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $block:Ljava/lang/Object;

.field public final synthetic $r8$classId:B

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public label:B

.field public final synthetic this$0:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroidx/work/impl/WorkDatabase_Impl;Lcoil/request/RequestService;Lkotlinx/coroutines/channels/BufferedChannel;Landroidx/work/impl/model/WorkSpecDao_Impl$25;Lkotlinx/coroutines/channels/BufferedChannel;Lkotlin/coroutines/Continuation;)V
    .registers 8

    .line 1
    const/4 v0, 0x2

    .line 2
    iput-byte v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$r8$classId:B

    .line 3
    .line 4
    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 5
    .line 6
    iput-object p2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p4, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 11
    .line 12
    iput-object p5, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 13
    .line 14
    invoke-direct {p0, v0, p6}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 15
    .line 16
    .line 17
    return-void
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;B)V
    .registers 5

    .line 18
    iput-byte p4, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$r8$classId:B

    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 13

    .line 1
    iget-byte v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$r8$classId:B

    .line 2
    .line 3
    iget-object v1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_42

    .line 8
    .line 9
    .line 10
    new-instance v3, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 11
    .line 12
    iget-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 13
    .line 14
    move-object v4, p1

    .line 15
    check-cast v4, Landroidx/work/impl/WorkDatabase_Impl;

    .line 16
    .line 17
    iget-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 18
    .line 19
    move-object v5, p1

    .line 20
    check-cast v5, Lcoil/request/RequestService;

    .line 21
    .line 22
    iget-object p0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 23
    .line 24
    move-object v6, p0

    .line 25
    check-cast v6, Lkotlinx/coroutines/channels/BufferedChannel;

    .line 26
    .line 27
    move-object v7, v2

    .line 28
    check-cast v7, Landroidx/work/impl/model/WorkSpecDao_Impl$25;

    .line 29
    .line 30
    move-object v8, v1

    .line 31
    check-cast v8, Lkotlinx/coroutines/channels/BufferedChannel;

    .line 32
    .line 33
    move-object v9, p2

    .line 34
    invoke-direct/range {v3 .. v9}, Landroidx/compose/foundation/MutatorMutex$mutate$2;-><init>(Landroidx/work/impl/WorkDatabase_Impl;Lcoil/request/RequestService;Lkotlinx/coroutines/channels/BufferedChannel;Landroidx/work/impl/model/WorkSpecDao_Impl$25;Lkotlinx/coroutines/channels/BufferedChannel;Lkotlin/coroutines/Continuation;)V

    .line 35
    .line 36
    .line 37
    return-object v3

    .line 38
    :pswitch_25
    move-object v9, p2

    .line 39
    new-instance p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 40
    .line 41
    check-cast v2, Landroidx/compose/animation/core/MutatorMutex;

    .line 42
    .line 43
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 44
    .line 45
    const/4 p2, 0x1

    .line 46
    invoke-direct {p0, v2, v1, v9, p2}, Landroidx/compose/foundation/MutatorMutex$mutate$2;-><init>(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;B)V

    .line 47
    .line 48
    .line 49
    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 50
    .line 51
    return-object p0

    .line 52
    :pswitch_33
    move-object v9, p2

    .line 53
    new-instance p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 54
    .line 55
    check-cast v2, Landroidx/compose/foundation/MutatorMutex;

    .line 56
    .line 57
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 58
    .line 59
    const/4 p2, 0x0

    .line 60
    invoke-direct {p0, v2, v1, v9, p2}, Landroidx/compose/foundation/MutatorMutex$mutate$2;-><init>(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;B)V

    .line 61
    .line 62
    .line 63
    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 64
    .line 65
    return-object p0

    .line 66
    nop

    .line 67
    :pswitch_data_42
    .packed-switch 0x0
        :pswitch_33
        :pswitch_25
    .end packed-switch
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget-byte v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$r8$classId:B

    .line 2
    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 4
    .line 5
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 6
    .line 7
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_2c

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    :pswitch_21
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    check-cast p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 39
    .line 40
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    return-object p0

    .line 45
    :pswitch_data_2c
    .packed-switch 0x0
        :pswitch_21
        :pswitch_16
    .end packed-switch
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$r8$classId:B

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x1

    .line 7
    const/4 v4, 0x0

    .line 8
    packed-switch v1, :pswitch_data_32a

    .line 9
    .line 10
    .line 11
    iget-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Lcoil/request/RequestService;

    .line 14
    .line 15
    iget-object v5, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v5, Landroidx/work/impl/WorkDatabase_Impl;

    .line 18
    .line 19
    iget-object v5, v5, Landroidx/work/impl/WorkDatabase;->invalidationTracker:Landroidx/room/InvalidationTracker;

    .line 20
    .line 21
    sget-object v6, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 22
    .line 23
    iget-byte v7, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:B

    .line 24
    .line 25
    if-eqz v7, :cond_3e

    .line 26
    .line 27
    if-eq v7, v3, :cond_32

    .line 28
    .line 29
    if-ne v7, v2, :cond_2b

    .line 30
    .line 31
    iget-object v4, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v4, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;

    .line 34
    .line 35
    :try_start_22
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_25
    .catchall {:try_start_22 .. :try_end_25} :catchall_28

    .line 36
    .line 37
    .line 38
    move-object v7, v4

    .line 39
    goto/16 :goto_143

    .line 40
    .line 41
    :catchall_28
    move-exception v0

    .line 42
    goto/16 :goto_177

    .line 43
    .line 44
    :cond_2b
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-static {v0}, Lokhttp3/internal/Util$$ExternalSyntheticLambda2;->m$3(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    goto/16 :goto_176

    .line 50
    .line 51
    :cond_32
    iget-object v4, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v4, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;

    .line 54
    .line 55
    :try_start_36
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_39
    .catchall {:try_start_36 .. :try_end_39} :catchall_28

    .line 56
    .line 57
    .line 58
    move-object v7, v4

    .line 59
    move-object/from16 v4, p1

    .line 60
    .line 61
    goto/16 :goto_14e

    .line 62
    .line 63
    :cond_3e
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    iget-object v7, v1, Lcoil/request/RequestService;->systemCallbacks:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v7, [Ljava/lang/String;

    .line 69
    .line 70
    iget-object v8, v5, Landroidx/room/InvalidationTracker;->viewTables:Ljava/util/HashMap;

    .line 71
    .line 72
    new-instance v9, Lkotlin/collections/builders/SetBuilder;

    .line 73
    .line 74
    invoke-direct {v9}, Lkotlin/collections/builders/SetBuilder;-><init>()V

    .line 75
    .line 76
    .line 77
    array-length v10, v7

    .line 78
    const/4 v11, 0x0

    .line 79
    move v12, v11

    .line 80
    :goto_4f
    if-ge v12, v10, :cond_7f

    .line 81
    .line 82
    aget-object v13, v7, v12

    .line 83
    .line 84
    sget-object v14, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 85
    .line 86
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v13, v14}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v15

    .line 93
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 94
    .line 95
    .line 96
    invoke-virtual {v8, v15}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v15

    .line 100
    if-eqz v15, :cond_79

    .line 101
    .line 102
    invoke-virtual {v13, v14}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v13

    .line 106
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 107
    .line 108
    .line 109
    invoke-virtual {v8, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v13

    .line 113
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 114
    .line 115
    .line 116
    check-cast v13, Ljava/util/Collection;

    .line 117
    .line 118
    invoke-virtual {v9, v13}, Lkotlin/collections/builders/SetBuilder;->addAll(Ljava/util/Collection;)Z

    .line 119
    .line 120
    .line 121
    goto :goto_7c

    .line 122
    :cond_79
    invoke-virtual {v9, v13}, Lkotlin/collections/builders/SetBuilder;->add(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    :goto_7c
    add-int/lit8 v12, v12, 0x1

    .line 126
    .line 127
    goto :goto_4f

    .line 128
    :cond_7f
    invoke-static {v9}, Lkotlin/TuplesKt;->build(Lkotlin/collections/builders/SetBuilder;)Lkotlin/collections/builders/SetBuilder;

    .line 129
    .line 130
    .line 131
    move-result-object v7

    .line 132
    new-array v8, v11, [Ljava/lang/String;

    .line 133
    .line 134
    invoke-virtual {v7, v8}, Ljava/util/AbstractCollection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v7

    .line 138
    check-cast v7, [Ljava/lang/String;

    .line 139
    .line 140
    new-instance v8, Ljava/util/ArrayList;

    .line 141
    .line 142
    array-length v9, v7

    .line 143
    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 144
    .line 145
    .line 146
    array-length v9, v7

    .line 147
    move v10, v11

    .line 148
    :goto_93
    if-ge v10, v9, :cond_be

    .line 149
    .line 150
    aget-object v12, v7, v10

    .line 151
    .line 152
    iget-object v13, v5, Landroidx/room/InvalidationTracker;->tableIdLookup:Ljava/util/LinkedHashMap;

    .line 153
    .line 154
    sget-object v14, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 155
    .line 156
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 157
    .line 158
    .line 159
    invoke-virtual {v12, v14}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v14

    .line 163
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 164
    .line 165
    .line 166
    invoke-virtual {v13, v14}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    move-result-object v13

    .line 170
    check-cast v13, Ljava/lang/Integer;

    .line 171
    .line 172
    if-eqz v13, :cond_b3

    .line 173
    .line 174
    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 175
    .line 176
    .line 177
    add-int/lit8 v10, v10, 0x1

    .line 178
    .line 179
    goto :goto_93

    .line 180
    :cond_b3
    const-string v4, "There is no table with name "

    .line 181
    .line 182
    invoke-virtual {v4, v12}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object v4

    .line 186
    invoke-static {v4}, Lokhttp3/internal/Util$$ExternalSyntheticLambda2;->m$2(Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    goto/16 :goto_13a

    .line 190
    .line 191
    :cond_be
    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->toIntArray(Ljava/util/ArrayList;)[I

    .line 192
    .line 193
    .line 194
    move-result-object v8

    .line 195
    new-instance v9, Landroidx/room/InvalidationTracker$ObserverWrapper;

    .line 196
    .line 197
    invoke-direct {v9, v1, v8, v7}, Landroidx/room/InvalidationTracker$ObserverWrapper;-><init>(Lcoil/request/RequestService;[I[Ljava/lang/String;)V

    .line 198
    .line 199
    .line 200
    iget-object v7, v5, Landroidx/room/InvalidationTracker;->observerMap:Landroidx/arch/core/internal/SafeIterableMap;

    .line 201
    .line 202
    monitor-enter v7

    .line 203
    :try_start_ca
    iget-object v10, v5, Landroidx/room/InvalidationTracker;->observerMap:Landroidx/arch/core/internal/SafeIterableMap;

    .line 204
    .line 205
    invoke-virtual {v10, v1}, Landroidx/arch/core/internal/SafeIterableMap;->get(Ljava/lang/Object;)Landroidx/arch/core/internal/SafeIterableMap$Entry;

    .line 206
    .line 207
    .line 208
    move-result-object v12

    .line 209
    if-eqz v12, :cond_d5

    .line 210
    .line 211
    iget-object v4, v12, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mValue:Ljava/lang/Object;

    .line 212
    .line 213
    goto :goto_ee

    .line 214
    :cond_d5
    new-instance v12, Landroidx/arch/core/internal/SafeIterableMap$Entry;

    .line 215
    .line 216
    invoke-direct {v12, v1, v9}, Landroidx/arch/core/internal/SafeIterableMap$Entry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 217
    .line 218
    .line 219
    iget v9, v10, Landroidx/arch/core/internal/SafeIterableMap;->mSize:I

    .line 220
    .line 221
    add-int/2addr v9, v3

    .line 222
    iput v9, v10, Landroidx/arch/core/internal/SafeIterableMap;->mSize:I

    .line 223
    .line 224
    iget-object v9, v10, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;

    .line 225
    .line 226
    if-nez v9, :cond_e8

    .line 227
    .line 228
    iput-object v12, v10, Landroidx/arch/core/internal/SafeIterableMap;->mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;

    .line 229
    .line 230
    iput-object v12, v10, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;

    .line 231
    .line 232
    goto :goto_ee

    .line 233
    :cond_e8
    iput-object v12, v9, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;

    .line 234
    .line 235
    iput-object v9, v12, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;

    .line 236
    .line 237
    iput-object v12, v10, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;

    .line 238
    .line 239
    :goto_ee
    check-cast v4, Landroidx/room/InvalidationTracker$ObserverWrapper;
    :try_end_f0
    .catchall {:try_start_ca .. :try_end_f0} :catchall_17b

    .line 240
    .line 241
    monitor-exit v7

    .line 242
    if-nez v4, :cond_13a

    .line 243
    .line 244
    iget-object v4, v5, Landroidx/room/InvalidationTracker;->observedTableTracker:Lcoil/disk/DiskLruCache$Editor;

    .line 245
    .line 246
    array-length v7, v8

    .line 247
    invoke-static {v8, v7}, Ljava/util/Arrays;->copyOf([II)[I

    .line 248
    .line 249
    .line 250
    move-result-object v7

    .line 251
    monitor-enter v4

    .line 252
    :try_start_fb
    array-length v8, v7

    .line 253
    move v9, v11

    .line 254
    :goto_fd
    if-ge v11, v8, :cond_11b

    .line 255
    .line 256
    aget v10, v7, v11

    .line 257
    .line 258
    iget-object v12, v4, Lcoil/disk/DiskLruCache$Editor;->entry:Ljava/lang/Object;

    .line 259
    .line 260
    check-cast v12, [J

    .line 261
    .line 262
    aget-wide v13, v12, v10

    .line 263
    .line 264
    const-wide/16 v15, 0x1

    .line 265
    .line 266
    add-long/2addr v15, v13

    .line 267
    aput-wide v15, v12, v10

    .line 268
    .line 269
    const-wide/16 v15, 0x0

    .line 270
    .line 271
    cmp-long v10, v13, v15

    .line 272
    .line 273
    if-nez v10, :cond_118

    .line 274
    .line 275
    iput-boolean v3, v4, Lcoil/disk/DiskLruCache$Editor;->closed:Z
    :try_end_114
    .catchall {:try_start_fb .. :try_end_114} :catchall_116

    .line 276
    .line 277
    move v9, v3

    .line 278
    goto :goto_118

    .line 279
    :catchall_116
    move-exception v0

    .line 280
    goto :goto_138

    .line 281
    :cond_118
    :goto_118
    add-int/lit8 v11, v11, 0x1

    .line 282
    .line 283
    goto :goto_fd

    .line 284
    :cond_11b
    monitor-exit v4

    .line 285
    if-eqz v9, :cond_13a

    .line 286
    .line 287
    iget-object v4, v5, Landroidx/room/InvalidationTracker;->database:Landroidx/work/impl/WorkDatabase_Impl;

    .line 288
    .line 289
    iget-object v7, v4, Landroidx/work/impl/WorkDatabase;->mDatabase:Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;

    .line 290
    .line 291
    if-eqz v7, :cond_13a

    .line 292
    .line 293
    iget-object v7, v7, Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;->delegate:Landroid/database/sqlite/SQLiteDatabase;

    .line 294
    .line 295
    invoke-virtual {v7}, Landroid/database/sqlite/SQLiteDatabase;->isOpen()Z

    .line 296
    .line 297
    .line 298
    move-result v7

    .line 299
    if-ne v7, v3, :cond_13a

    .line 300
    .line 301
    invoke-virtual {v4}, Landroidx/work/impl/WorkDatabase;->getOpenHelper()Landroidx/sqlite/db/SupportSQLiteOpenHelper;

    .line 302
    .line 303
    .line 304
    move-result-object v4

    .line 305
    invoke-interface {v4}, Landroidx/sqlite/db/SupportSQLiteOpenHelper;->getWritableDatabase()Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;

    .line 306
    .line 307
    .line 308
    move-result-object v4

    .line 309
    invoke-virtual {v5, v4}, Landroidx/room/InvalidationTracker;->syncTriggers$room_runtime_release(Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase;)V

    .line 310
    .line 311
    .line 312
    goto :goto_13a

    .line 313
    :goto_138
    monitor-exit v4

    .line 314
    throw v0

    .line 315
    :cond_13a
    :goto_13a
    :try_start_13a
    iget-object v4, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 316
    .line 317
    check-cast v4, Lkotlinx/coroutines/channels/BufferedChannel;

    .line 318
    .line 319
    new-instance v7, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;

    .line 320
    .line 321
    invoke-direct {v7, v4}, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;-><init>(Lkotlinx/coroutines/channels/BufferedChannel;)V

    .line 322
    .line 323
    .line 324
    :cond_143
    :goto_143
    iput-object v7, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 325
    .line 326
    iput-byte v3, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:B

    .line 327
    .line 328
    invoke-virtual {v7, v0}, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;->hasNext(Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 329
    .line 330
    .line 331
    move-result-object v4

    .line 332
    if-ne v4, v6, :cond_14e

    .line 333
    .line 334
    goto :goto_16f

    .line 335
    :cond_14e
    :goto_14e
    check-cast v4, Ljava/lang/Boolean;

    .line 336
    .line 337
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 338
    .line 339
    .line 340
    move-result v4

    .line 341
    if-eqz v4, :cond_171

    .line 342
    .line 343
    invoke-virtual {v7}, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;->next()Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    iget-object v4, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 347
    .line 348
    check-cast v4, Landroidx/work/impl/model/WorkSpecDao_Impl$25;

    .line 349
    .line 350
    invoke-virtual {v4}, Landroidx/work/impl/model/WorkSpecDao_Impl$25;->call()Ljava/lang/Object;

    .line 351
    .line 352
    .line 353
    move-result-object v4

    .line 354
    iget-object v8, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 355
    .line 356
    check-cast v8, Lkotlinx/coroutines/channels/BufferedChannel;

    .line 357
    .line 358
    iput-object v7, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 359
    .line 360
    iput-byte v2, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:B

    .line 361
    .line 362
    invoke-interface {v8, v4, v0}, Lkotlinx/coroutines/channels/SendChannel;->send(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 363
    .line 364
    .line 365
    move-result-object v4
    :try_end_16d
    .catchall {:try_start_13a .. :try_end_16d} :catchall_28

    .line 366
    if-ne v4, v6, :cond_143

    .line 367
    .line 368
    :goto_16f
    move-object v4, v6

    .line 369
    goto :goto_176

    .line 370
    :cond_171
    invoke-virtual {v5, v1}, Landroidx/room/InvalidationTracker;->removeObserver(Lcoil/request/RequestService;)V

    .line 371
    .line 372
    .line 373
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 374
    .line 375
    :goto_176
    return-object v4

    .line 376
    :goto_177
    invoke-virtual {v5, v1}, Landroidx/room/InvalidationTracker;->removeObserver(Lcoil/request/RequestService;)V

    .line 377
    .line 378
    .line 379
    throw v0

    .line 380
    :catchall_17b
    move-exception v0

    .line 381
    monitor-exit v7

    .line 382
    throw v0

    .line 383
    :pswitch_17e
    iget-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 384
    .line 385
    check-cast v1, Landroidx/compose/animation/core/MutatorMutex;

    .line 386
    .line 387
    sget-object v5, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 388
    .line 389
    iget-byte v6, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:B

    .line 390
    .line 391
    if-eqz v6, :cond_1be

    .line 392
    .line 393
    if-eq v6, v3, :cond_1aa

    .line 394
    .line 395
    if-ne v6, v2, :cond_1a3

    .line 396
    .line 397
    iget-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 398
    .line 399
    check-cast v1, Landroidx/compose/animation/core/MutatorMutex;

    .line 400
    .line 401
    iget-object v2, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 402
    .line 403
    check-cast v2, Lkotlinx/coroutines/sync/Mutex;

    .line 404
    .line 405
    iget-object v0, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 406
    .line 407
    move-object v3, v0

    .line 408
    check-cast v3, Landroidx/compose/animation/core/MutatorMutex$Mutator;

    .line 409
    .line 410
    :try_start_199
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_19c
    .catchall {:try_start_199 .. :try_end_19c} :catchall_1a0

    .line 411
    .line 412
    .line 413
    move-object/from16 v0, p1

    .line 414
    .line 415
    goto/16 :goto_234

    .line 416
    .line 417
    :catchall_1a0
    move-exception v0

    .line 418
    goto/16 :goto_24f

    .line 419
    .line 420
    :cond_1a3
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 421
    .line 422
    invoke-static {v0}, Lokhttp3/internal/Util$$ExternalSyntheticLambda2;->m$3(Ljava/lang/String;)V

    .line 423
    .line 424
    .line 425
    goto/16 :goto_249

    .line 426
    .line 427
    :cond_1aa
    iget-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 428
    .line 429
    check-cast v1, Landroidx/compose/animation/core/MutatorMutex;

    .line 430
    .line 431
    iget-object v3, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 432
    .line 433
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 434
    .line 435
    iget-object v6, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 436
    .line 437
    check-cast v6, Lkotlinx/coroutines/sync/Mutex;

    .line 438
    .line 439
    iget-object v7, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 440
    .line 441
    check-cast v7, Landroidx/compose/animation/core/MutatorMutex$Mutator;

    .line 442
    .line 443
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 444
    .line 445
    .line 446
    goto :goto_220

    .line 447
    :cond_1be
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 448
    .line 449
    .line 450
    iget-object v6, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 451
    .line 452
    check-cast v6, Lkotlinx/coroutines/CoroutineScope;

    .line 453
    .line 454
    new-instance v7, Landroidx/compose/animation/core/MutatorMutex$Mutator;

    .line 455
    .line 456
    invoke-interface {v6}, Lkotlinx/coroutines/CoroutineScope;->getCoroutineContext()Lkotlin/coroutines/CoroutineContext;

    .line 457
    .line 458
    .line 459
    move-result-object v6

    .line 460
    sget-object v8, Lkotlinx/coroutines/Job$Key;->$$INSTANCE:Lkotlinx/coroutines/Job$Key;

    .line 461
    .line 462
    invoke-interface {v6, v8}, Lkotlin/coroutines/CoroutineContext;->get(Lkotlin/coroutines/CoroutineContext$Key;)Lkotlin/coroutines/CoroutineContext$Element;

    .line 463
    .line 464
    .line 465
    move-result-object v6

    .line 466
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 467
    .line 468
    .line 469
    check-cast v6, Lkotlinx/coroutines/Job;

    .line 470
    .line 471
    invoke-direct {v7, v6}, Landroidx/compose/animation/core/MutatorMutex$Mutator;-><init>(Lkotlinx/coroutines/Job;)V

    .line 472
    .line 473
    .line 474
    iget-object v6, v1, Landroidx/compose/animation/core/MutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 475
    .line 476
    :goto_1db
    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v8

    .line 480
    check-cast v8, Landroidx/compose/animation/core/MutatorMutex$Mutator;

    .line 481
    .line 482
    if-eqz v8, :cond_1f4

    .line 483
    .line 484
    sget-object v9, Landroidx/compose/animation/core/MutatePriority;->Default:Landroidx/compose/animation/core/MutatePriority;

    .line 485
    .line 486
    invoke-virtual {v9, v9}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 487
    .line 488
    .line 489
    move-result v9

    .line 490
    if-ltz v9, :cond_1ec

    .line 491
    .line 492
    goto :goto_1f4

    .line 493
    :cond_1ec
    new-instance v0, Ljava/util/concurrent/CancellationException;

    .line 494
    .line 495
    const-string v1, "Current mutation had a higher priority"

    .line 496
    .line 497
    invoke-direct {v0, v1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 498
    .line 499
    .line 500
    throw v0

    .line 501
    :cond_1f4
    :goto_1f4
    invoke-virtual {v6, v8, v7}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 502
    .line 503
    .line 504
    move-result v9

    .line 505
    if-eqz v9, :cond_265

    .line 506
    .line 507
    if-eqz v8, :cond_208

    .line 508
    .line 509
    iget-object v6, v8, Landroidx/compose/animation/core/MutatorMutex$Mutator;->job:Lkotlinx/coroutines/Job;

    .line 510
    .line 511
    new-instance v8, Landroidx/compose/animation/core/MutationInterruptedException;

    .line 512
    .line 513
    const-string v9, "Mutation interrupted"

    .line 514
    .line 515
    invoke-direct {v8, v9}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 516
    .line 517
    .line 518
    invoke-interface {v6, v8}, Lkotlinx/coroutines/Job;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 519
    .line 520
    .line 521
    :cond_208
    iget-object v6, v1, Landroidx/compose/animation/core/MutatorMutex;->mutex:Lkotlinx/coroutines/sync/MutexImpl;

    .line 522
    .line 523
    iget-object v8, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 524
    .line 525
    check-cast v8, Lkotlin/jvm/functions/Function1;

    .line 526
    .line 527
    iput-object v7, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 528
    .line 529
    iput-object v6, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 530
    .line 531
    iput-object v8, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 532
    .line 533
    iput-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 534
    .line 535
    iput-byte v3, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:B

    .line 536
    .line 537
    invoke-virtual {v6, v0}, Lkotlinx/coroutines/sync/MutexImpl;->lock(Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 538
    .line 539
    .line 540
    move-result-object v3

    .line 541
    if-ne v3, v5, :cond_21f

    .line 542
    .line 543
    goto :goto_230

    .line 544
    :cond_21f
    move-object v3, v8

    .line 545
    :goto_220
    :try_start_220
    iput-object v7, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 546
    .line 547
    iput-object v6, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 548
    .line 549
    iput-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 550
    .line 551
    iput-object v4, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 552
    .line 553
    iput-byte v2, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:B

    .line 554
    .line 555
    invoke-interface {v3, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 556
    .line 557
    .line 558
    move-result-object v0
    :try_end_22e
    .catchall {:try_start_220 .. :try_end_22e} :catchall_24c

    .line 559
    if-ne v0, v5, :cond_232

    .line 560
    .line 561
    :goto_230
    move-object v4, v5

    .line 562
    goto :goto_249

    .line 563
    :cond_232
    move-object v2, v6

    .line 564
    move-object v3, v7

    .line 565
    :goto_234
    :try_start_234
    iget-object v1, v1, Landroidx/compose/animation/core/MutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 566
    .line 567
    :cond_236
    invoke-virtual {v1, v3, v4}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 568
    .line 569
    .line 570
    move-result v5

    .line 571
    if-eqz v5, :cond_23d

    .line 572
    .line 573
    goto :goto_243

    .line 574
    :cond_23d
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 575
    .line 576
    .line 577
    move-result-object v5
    :try_end_241
    .catchall {:try_start_234 .. :try_end_241} :catchall_24a

    .line 578
    if-eq v5, v3, :cond_236

    .line 579
    .line 580
    :goto_243
    check-cast v2, Lkotlinx/coroutines/sync/MutexImpl;

    .line 581
    .line 582
    invoke-virtual {v2, v4}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 583
    .line 584
    .line 585
    move-object v4, v0

    .line 586
    :goto_249
    return-object v4

    .line 587
    :catchall_24a
    move-exception v0

    .line 588
    goto :goto_25f

    .line 589
    :catchall_24c
    move-exception v0

    .line 590
    move-object v2, v6

    .line 591
    move-object v3, v7

    .line 592
    :goto_24f
    :try_start_24f
    iget-object v1, v1, Landroidx/compose/animation/core/MutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 593
    .line 594
    :goto_251
    invoke-virtual {v1, v3, v4}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 595
    .line 596
    .line 597
    move-result v5

    .line 598
    if-nez v5, :cond_25e

    .line 599
    .line 600
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 601
    .line 602
    .line 603
    move-result-object v5

    .line 604
    if-ne v5, v3, :cond_25e

    .line 605
    .line 606
    goto :goto_251

    .line 607
    :cond_25e
    throw v0
    :try_end_25f
    .catchall {:try_start_24f .. :try_end_25f} :catchall_24a

    .line 608
    :goto_25f
    check-cast v2, Lkotlinx/coroutines/sync/MutexImpl;

    .line 609
    .line 610
    invoke-virtual {v2, v4}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 611
    .line 612
    .line 613
    throw v0

    .line 614
    :cond_265
    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 615
    .line 616
    .line 617
    move-result-object v9

    .line 618
    if-eq v9, v8, :cond_1f4

    .line 619
    .line 620
    goto/16 :goto_1db

    .line 621
    .line 622
    :pswitch_26d
    iget-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 623
    .line 624
    check-cast v1, Landroidx/compose/foundation/MutatorMutex;

    .line 625
    .line 626
    sget-object v5, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 627
    .line 628
    iget-byte v6, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:B

    .line 629
    .line 630
    if-eqz v6, :cond_2ac

    .line 631
    .line 632
    if-eq v6, v3, :cond_298

    .line 633
    .line 634
    if-ne v6, v2, :cond_291

    .line 635
    .line 636
    iget-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 637
    .line 638
    check-cast v1, Landroidx/compose/foundation/MutatorMutex;

    .line 639
    .line 640
    iget-object v2, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 641
    .line 642
    check-cast v2, Lkotlinx/coroutines/sync/Mutex;

    .line 643
    .line 644
    iget-object v0, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 645
    .line 646
    move-object v3, v0

    .line 647
    check-cast v3, Landroidx/compose/foundation/MutatorMutex$Mutator;

    .line 648
    .line 649
    :try_start_288
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_28b
    .catchall {:try_start_288 .. :try_end_28b} :catchall_28e

    .line 650
    .line 651
    .line 652
    move-object/from16 v0, p1

    .line 653
    .line 654
    goto :goto_2f8

    .line 655
    :catchall_28e
    move-exception v0

    .line 656
    goto/16 :goto_313

    .line 657
    .line 658
    :cond_291
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 659
    .line 660
    invoke-static {v0}, Lokhttp3/internal/Util$$ExternalSyntheticLambda2;->m$3(Ljava/lang/String;)V

    .line 661
    .line 662
    .line 663
    goto/16 :goto_30d

    .line 664
    .line 665
    :cond_298
    iget-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 666
    .line 667
    check-cast v1, Landroidx/compose/foundation/MutatorMutex;

    .line 668
    .line 669
    iget-object v3, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 670
    .line 671
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 672
    .line 673
    iget-object v6, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 674
    .line 675
    check-cast v6, Lkotlinx/coroutines/sync/Mutex;

    .line 676
    .line 677
    iget-object v7, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 678
    .line 679
    check-cast v7, Landroidx/compose/foundation/MutatorMutex$Mutator;

    .line 680
    .line 681
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 682
    .line 683
    .line 684
    goto :goto_2e4

    .line 685
    :cond_2ac
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 686
    .line 687
    .line 688
    iget-object v6, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 689
    .line 690
    check-cast v6, Lkotlinx/coroutines/CoroutineScope;

    .line 691
    .line 692
    new-instance v7, Landroidx/compose/foundation/MutatorMutex$Mutator;

    .line 693
    .line 694
    sget-object v8, Landroidx/compose/foundation/MutatePriority;->Default:Landroidx/compose/foundation/MutatePriority;

    .line 695
    .line 696
    invoke-interface {v6}, Lkotlinx/coroutines/CoroutineScope;->getCoroutineContext()Lkotlin/coroutines/CoroutineContext;

    .line 697
    .line 698
    .line 699
    move-result-object v6

    .line 700
    sget-object v9, Lkotlinx/coroutines/Job$Key;->$$INSTANCE:Lkotlinx/coroutines/Job$Key;

    .line 701
    .line 702
    invoke-interface {v6, v9}, Lkotlin/coroutines/CoroutineContext;->get(Lkotlin/coroutines/CoroutineContext$Key;)Lkotlin/coroutines/CoroutineContext$Element;

    .line 703
    .line 704
    .line 705
    move-result-object v6

    .line 706
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 707
    .line 708
    .line 709
    check-cast v6, Lkotlinx/coroutines/Job;

    .line 710
    .line 711
    invoke-direct {v7, v8, v6}, Landroidx/compose/foundation/MutatorMutex$Mutator;-><init>(Landroidx/compose/foundation/MutatePriority;Lkotlinx/coroutines/Job;)V

    .line 712
    .line 713
    .line 714
    invoke-virtual {v1, v7}, Landroidx/compose/foundation/MutatorMutex;->tryMutateOrCancel(Landroidx/compose/foundation/MutatorMutex$Mutator;)V

    .line 715
    .line 716
    .line 717
    iget-object v6, v1, Landroidx/compose/foundation/MutatorMutex;->mutex:Lkotlinx/coroutines/sync/MutexImpl;

    .line 718
    .line 719
    iget-object v8, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 720
    .line 721
    check-cast v8, Lkotlin/jvm/functions/Function1;

    .line 722
    .line 723
    iput-object v7, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 724
    .line 725
    iput-object v6, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 726
    .line 727
    iput-object v8, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 728
    .line 729
    iput-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 730
    .line 731
    iput-byte v3, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:B

    .line 732
    .line 733
    invoke-virtual {v6, v0}, Lkotlinx/coroutines/sync/MutexImpl;->lock(Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 734
    .line 735
    .line 736
    move-result-object v3

    .line 737
    if-ne v3, v5, :cond_2e3

    .line 738
    .line 739
    goto :goto_2f4

    .line 740
    :cond_2e3
    move-object v3, v8

    .line 741
    :goto_2e4
    :try_start_2e4
    iput-object v7, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 742
    .line 743
    iput-object v6, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 744
    .line 745
    iput-object v1, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 746
    .line 747
    iput-object v4, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 748
    .line 749
    iput-byte v2, v0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:B

    .line 750
    .line 751
    invoke-interface {v3, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 752
    .line 753
    .line 754
    move-result-object v0
    :try_end_2f2
    .catchall {:try_start_2e4 .. :try_end_2f2} :catchall_310

    .line 755
    if-ne v0, v5, :cond_2f6

    .line 756
    .line 757
    :goto_2f4
    move-object v4, v5

    .line 758
    goto :goto_30d

    .line 759
    :cond_2f6
    move-object v2, v6

    .line 760
    move-object v3, v7

    .line 761
    :goto_2f8
    :try_start_2f8
    iget-object v1, v1, Landroidx/compose/foundation/MutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 762
    .line 763
    :cond_2fa
    invoke-virtual {v1, v3, v4}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 764
    .line 765
    .line 766
    move-result v5

    .line 767
    if-eqz v5, :cond_301

    .line 768
    .line 769
    goto :goto_307

    .line 770
    :cond_301
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 771
    .line 772
    .line 773
    move-result-object v5
    :try_end_305
    .catchall {:try_start_2f8 .. :try_end_305} :catchall_30e

    .line 774
    if-eq v5, v3, :cond_2fa

    .line 775
    .line 776
    :goto_307
    check-cast v2, Lkotlinx/coroutines/sync/MutexImpl;

    .line 777
    .line 778
    invoke-virtual {v2, v4}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 779
    .line 780
    .line 781
    move-object v4, v0

    .line 782
    :goto_30d
    return-object v4

    .line 783
    :catchall_30e
    move-exception v0

    .line 784
    goto :goto_323

    .line 785
    :catchall_310
    move-exception v0

    .line 786
    move-object v2, v6

    .line 787
    move-object v3, v7

    .line 788
    :goto_313
    :try_start_313
    iget-object v1, v1, Landroidx/compose/foundation/MutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 789
    .line 790
    :goto_315
    invoke-virtual {v1, v3, v4}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 791
    .line 792
    .line 793
    move-result v5

    .line 794
    if-nez v5, :cond_322

    .line 795
    .line 796
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 797
    .line 798
    .line 799
    move-result-object v5

    .line 800
    if-ne v5, v3, :cond_322

    .line 801
    .line 802
    goto :goto_315

    .line 803
    :cond_322
    throw v0
    :try_end_323
    .catchall {:try_start_313 .. :try_end_323} :catchall_30e

    .line 804
    :goto_323
    check-cast v2, Lkotlinx/coroutines/sync/MutexImpl;

    .line 805
    .line 806
    invoke-virtual {v2, v4}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 807
    .line 808
    .line 809
    throw v0

    .line 810
    nop

    .line 811
    :pswitch_data_32a
    .packed-switch 0x0
        :pswitch_26d
        :pswitch_17e
    .end packed-switch
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
.end method
