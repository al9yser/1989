.class public final synthetic Landroidx/compose/foundation/contextmenu/ComposableSingletons$ContextMenuUiKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function8;


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Boolean;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;Ljava/lang/Integer;)Ljava/lang/Object;
    .registers 10

    .line 1
    move-object p0, p1

    .line 2
    check-cast p0, Ljava/lang/String;

    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    move-object p2, p3

    .line 9
    check-cast p2, Landroidx/compose/foundation/contextmenu/ContextMenuColors;

    .line 10
    .line 11
    check-cast p4, Lkotlin/jvm/functions/Function3;

    .line 12
    .line 13
    check-cast p5, Lkotlin/jvm/functions/Function0;

    .line 14
    .line 15
    invoke-virtual {p7}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result p3

    .line 19
    and-int/lit8 p7, p3, 0x6

    .line 20
    .line 21
    move v0, p3

    .line 22
    sget-object p3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 23
    .line 24
    if-nez p7, :cond_24

    .line 25
    .line 26
    invoke-virtual {p6, p3}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result p7

    .line 30
    if-eqz p7, :cond_21

    .line 31
    .line 32
    const/4 p7, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 p7, 0x2

    .line 35
    :goto_22
    or-int/2addr p7, v0

    .line 36
    goto :goto_25

    .line 37
    :cond_24
    move p7, v0

    .line 38
    :goto_25
    and-int/lit8 v1, v0, 0x30

    .line 39
    .line 40
    if-nez v1, :cond_35

    .line 41
    .line 42
    invoke-virtual {p6, p0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    if-eqz v1, :cond_32

    .line 47
    .line 48
    const/16 v1, 0x20

    .line 49
    .line 50
    goto :goto_34

    .line 51
    :cond_32
    const/16 v1, 0x10

    .line 52
    .line 53
    :goto_34
    or-int/2addr p7, v1

    .line 54
    :cond_35
    and-int/lit16 v1, v0, 0x180

    .line 55
    .line 56
    if-nez v1, :cond_45

    .line 57
    .line 58
    invoke-virtual {p6, p1}, Landroidx/compose/runtime/GapComposer;->changed(Z)Z

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    if-eqz v1, :cond_42

    .line 63
    .line 64
    const/16 v1, 0x100

    .line 65
    .line 66
    goto :goto_44

    .line 67
    :cond_42
    const/16 v1, 0x80

    .line 68
    .line 69
    :goto_44
    or-int/2addr p7, v1

    .line 70
    :cond_45
    and-int/lit16 v1, v0, 0xc00

    .line 71
    .line 72
    if-nez v1, :cond_55

    .line 73
    .line 74
    invoke-virtual {p6, p2}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    if-eqz v1, :cond_52

    .line 79
    .line 80
    const/16 v1, 0x800

    .line 81
    .line 82
    goto :goto_54

    .line 83
    :cond_52
    const/16 v1, 0x400

    .line 84
    .line 85
    :goto_54
    or-int/2addr p7, v1

    .line 86
    :cond_55
    and-int/lit16 v1, v0, 0x6000

    .line 87
    .line 88
    if-nez v1, :cond_65

    .line 89
    .line 90
    invoke-virtual {p6, p4}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v1

    .line 94
    if-eqz v1, :cond_62

    .line 95
    .line 96
    const/16 v1, 0x4000

    .line 97
    .line 98
    goto :goto_64

    .line 99
    :cond_62
    const/16 v1, 0x2000

    .line 100
    .line 101
    :goto_64
    or-int/2addr p7, v1

    .line 102
    :cond_65
    const/high16 v1, 0x30000

    .line 103
    .line 104
    and-int/2addr v0, v1

    .line 105
    if-nez v0, :cond_76

    .line 106
    .line 107
    invoke-virtual {p6, p5}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-eqz v0, :cond_73

    .line 112
    .line 113
    const/high16 v0, 0x20000

    .line 114
    .line 115
    goto :goto_75

    .line 116
    :cond_73
    const/high16 v0, 0x10000

    .line 117
    .line 118
    :goto_75
    or-int/2addr p7, v0

    .line 119
    :cond_76
    const v0, 0x92493

    .line 120
    .line 121
    .line 122
    and-int/2addr v0, p7

    .line 123
    const v1, 0x92492

    .line 124
    .line 125
    .line 126
    if-eq v0, v1, :cond_81

    .line 127
    .line 128
    const/4 v0, 0x1

    .line 129
    goto :goto_82

    .line 130
    :cond_81
    const/4 v0, 0x0

    .line 131
    :goto_82
    and-int/lit8 v1, p7, 0x1

    .line 132
    .line 133
    invoke-virtual {p6, v1, v0}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    if-eqz v0, :cond_a0

    .line 138
    .line 139
    shr-int/lit8 v0, p7, 0x3

    .line 140
    .line 141
    and-int/lit16 v0, v0, 0x3fe

    .line 142
    .line 143
    shl-int/lit8 v1, p7, 0x9

    .line 144
    .line 145
    and-int/lit16 v1, v1, 0x1c00

    .line 146
    .line 147
    or-int/2addr v0, v1

    .line 148
    const v1, 0xe000

    .line 149
    .line 150
    .line 151
    and-int/2addr v1, p7

    .line 152
    or-int/2addr v0, v1

    .line 153
    const/high16 v1, 0x70000

    .line 154
    .line 155
    and-int/2addr p7, v1

    .line 156
    or-int/2addr p7, v0

    .line 157
    invoke-static/range {p0 .. p7}, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt;->ContextMenuItem(Ljava/lang/String;ZLandroidx/compose/foundation/contextmenu/ContextMenuColors;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    .line 158
    .line 159
    .line 160
    goto :goto_a3

    .line 161
    :cond_a0
    invoke-virtual {p6}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 162
    .line 163
    .line 164
    :goto_a3
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 165
    .line 166
    return-object p0
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
.end method
