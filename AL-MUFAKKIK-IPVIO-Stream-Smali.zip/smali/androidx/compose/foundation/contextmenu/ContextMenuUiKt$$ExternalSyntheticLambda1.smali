.class public final synthetic Landroidx/compose/foundation/contextmenu/ContextMenuUiKt$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic f$0:Ljava/lang/Object;

.field public final synthetic f$1:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;B)V
    .registers 4

    .line 12
    iput-byte p3, p0, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt$$ExternalSyntheticLambda1;->$r8$classId:B

    iput-object p1, p0, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt$$ExternalSyntheticLambda1;->f$0:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt$$ExternalSyntheticLambda1;->f$1:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt$$ExternalSyntheticLambda1;->$r8$classId:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt$$ExternalSyntheticLambda1;->f$1:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt$$ExternalSyntheticLambda1;->f$0:Ljava/lang/Object;

    .line 10
    .line 11
    return-void
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 1
    iget-byte v0, p0, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt$$ExternalSyntheticLambda1;->$r8$classId:B

    .line 2
    .line 3
    sget-object v1, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 4
    .line 5
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 6
    .line 7
    iget-object v3, p0, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt$$ExternalSyntheticLambda1;->f$1:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object p0, p0, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt$$ExternalSyntheticLambda1;->f$0:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    packed-switch v0, :pswitch_data_136

    .line 13
    .line 14
    .line 15
    check-cast p0, Landroid/text/Spannable;

    .line 16
    .line 17
    check-cast v3, Landroidx/compose/ui/text/AndroidParagraphIntrinsics$$ExternalSyntheticLambda0;

    .line 18
    .line 19
    check-cast p1, Landroidx/compose/ui/text/SpanStyle;

    .line 20
    .line 21
    check-cast p2, Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 24
    .line 25
    .line 26
    move-result p2

    .line 27
    check-cast p3, Ljava/lang/Integer;

    .line 28
    .line 29
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 30
    .line 31
    .line 32
    move-result p3

    .line 33
    new-instance v0, Landroidx/compose/ui/text/android/style/TypefaceSpan;

    .line 34
    .line 35
    iget-object v1, p1, Landroidx/compose/ui/text/SpanStyle;->fontFamily:Landroidx/compose/ui/text/font/FontFamily;

    .line 36
    .line 37
    iget-object v5, p1, Landroidx/compose/ui/text/SpanStyle;->fontWeight:Landroidx/compose/ui/text/font/FontWeight;

    .line 38
    .line 39
    if-nez v5, :cond_2a

    .line 40
    .line 41
    sget-object v5, Landroidx/compose/ui/text/font/FontWeight;->Normal:Landroidx/compose/ui/text/font/FontWeight;

    .line 42
    .line 43
    :cond_2a
    iget-object v6, p1, Landroidx/compose/ui/text/SpanStyle;->fontStyle:Landroidx/compose/ui/text/font/FontStyle;

    .line 44
    .line 45
    if-eqz v6, :cond_31

    .line 46
    .line 47
    iget v6, v6, Landroidx/compose/ui/text/font/FontStyle;->value:I

    .line 48
    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v6, v4

    .line 51
    :goto_32
    iget-object p1, p1, Landroidx/compose/ui/text/SpanStyle;->fontSynthesis:Landroidx/compose/ui/text/font/FontSynthesis;

    .line 52
    .line 53
    if-eqz p1, :cond_39

    .line 54
    .line 55
    iget p1, p1, Landroidx/compose/ui/text/font/FontSynthesis;->value:I

    .line 56
    .line 57
    goto :goto_3c

    .line 58
    :cond_39
    const p1, 0xffff

    .line 59
    .line 60
    .line 61
    :goto_3c
    iget-object v3, v3, Landroidx/compose/ui/text/AndroidParagraphIntrinsics$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v3, Landroidx/compose/ui/text/AndroidParagraphIntrinsics;

    .line 64
    .line 65
    iget-object v7, v3, Landroidx/compose/ui/text/AndroidParagraphIntrinsics;->fontFamilyResolver:Landroidx/compose/ui/text/font/FontFamily$Resolver;

    .line 66
    .line 67
    check-cast v7, Landroidx/compose/ui/text/font/FontFamilyResolverImpl;

    .line 68
    .line 69
    invoke-virtual {v7, v1, v5, v6, p1}, Landroidx/compose/ui/text/font/FontFamilyResolverImpl;->resolve-DPcqOEQ(Landroidx/compose/ui/text/font/FontFamily;Landroidx/compose/ui/text/font/FontWeight;II)Landroidx/compose/ui/text/font/TypefaceResult;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    instance-of v1, p1, Landroidx/compose/ui/text/font/TypefaceResult$Immutable;

    .line 74
    .line 75
    if-nez v1, :cond_5d

    .line 76
    .line 77
    new-instance v1, Lcoil/network/RealNetworkObserver;

    .line 78
    .line 79
    iget-object v5, v3, Landroidx/compose/ui/text/AndroidParagraphIntrinsics;->resolvedTypefaces:Lcoil/network/RealNetworkObserver;

    .line 80
    .line 81
    invoke-direct {v1, p1, v5}, Lcoil/network/RealNetworkObserver;-><init>(Landroidx/compose/ui/text/font/TypefaceResult;Lcoil/network/RealNetworkObserver;)V

    .line 82
    .line 83
    .line 84
    iput-object v1, v3, Landroidx/compose/ui/text/AndroidParagraphIntrinsics;->resolvedTypefaces:Lcoil/network/RealNetworkObserver;

    .line 85
    .line 86
    iget-object p1, v1, Lcoil/network/RealNetworkObserver;->networkCallback:Ljava/lang/Object;

    .line 87
    .line 88
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    .line 90
    .line 91
    check-cast p1, Landroid/graphics/Typeface;

    .line 92
    .line 93
    goto :goto_66

    .line 94
    :cond_5d
    check-cast p1, Landroidx/compose/ui/text/font/TypefaceResult$Immutable;

    .line 95
    .line 96
    iget-object p1, p1, Landroidx/compose/ui/text/font/TypefaceResult$Immutable;->value:Ljava/lang/Object;

    .line 97
    .line 98
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 99
    .line 100
    .line 101
    check-cast p1, Landroid/graphics/Typeface;

    .line 102
    .line 103
    :goto_66
    invoke-direct {v0, p1, v4}, Landroidx/compose/ui/text/android/style/TypefaceSpan;-><init>(Ljava/lang/Object;B)V

    .line 104
    .line 105
    .line 106
    const/16 p1, 0x21

    .line 107
    .line 108
    invoke-interface {p0, v0, p2, p3, p1}, Landroid/text/Spannable;->setSpan(Ljava/lang/Object;III)V

    .line 109
    .line 110
    .line 111
    return-object v2

    .line 112
    :pswitch_6f
    check-cast v3, Lkotlin/jvm/functions/Function0;

    .line 113
    .line 114
    check-cast p0, Lkotlin/jvm/functions/Function1;

    .line 115
    .line 116
    check-cast p1, Landroidx/compose/ui/Modifier;

    .line 117
    .line 118
    check-cast p2, Landroidx/compose/runtime/Composer;

    .line 119
    .line 120
    check-cast p3, Ljava/lang/Integer;

    .line 121
    .line 122
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 123
    .line 124
    .line 125
    check-cast p2, Landroidx/compose/runtime/GapComposer;

    .line 126
    .line 127
    const p1, 0x2d4acc1b

    .line 128
    .line 129
    .line 130
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    if-ne p1, v1, :cond_91

    .line 138
    .line 139
    invoke-static {v3}, Landroidx/compose/runtime/SnapshotStateKt__DerivedStateKt;->derivedStateOf(Lkotlin/jvm/functions/Function0;)Landroidx/compose/runtime/DerivedSnapshotState;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    :cond_91
    check-cast p1, Landroidx/compose/runtime/State;

    .line 147
    .line 148
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object p3

    .line 152
    if-ne p3, v1, :cond_b4

    .line 153
    .line 154
    new-instance p3, Landroidx/compose/animation/core/Animatable;

    .line 155
    .line 156
    invoke-interface {p1}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    check-cast v0, Landroidx/compose/ui/geometry/Offset;

    .line 161
    .line 162
    iget-wide v5, v0, Landroidx/compose/ui/geometry/Offset;->packedValue:J

    .line 163
    .line 164
    sget-object v3, Landroidx/compose/foundation/text/selection/SelectionMagnifierKt;->UnspecifiedSafeOffsetVectorConverter:Landroidx/compose/animation/core/TwoWayConverterImpl;

    .line 165
    .line 166
    sget-wide v5, Landroidx/compose/foundation/text/selection/SelectionMagnifierKt;->OffsetDisplacementThreshold:J

    .line 167
    .line 168
    new-instance v7, Landroidx/compose/ui/geometry/Offset;

    .line 169
    .line 170
    invoke-direct {v7, v5, v6}, Landroidx/compose/ui/geometry/Offset;-><init>(J)V

    .line 171
    .line 172
    .line 173
    const/16 v5, 0x8

    .line 174
    .line 175
    invoke-direct {p3, v0, v3, v7, v5}, Landroidx/compose/animation/core/Animatable;-><init>(Ljava/lang/Object;Landroidx/compose/animation/core/TwoWayConverterImpl;Ljava/lang/Object;I)V

    .line 176
    .line 177
    .line 178
    invoke-virtual {p2, p3}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 179
    .line 180
    .line 181
    :cond_b4
    check-cast p3, Landroidx/compose/animation/core/Animatable;

    .line 182
    .line 183
    invoke-virtual {p2, p3}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 184
    .line 185
    .line 186
    move-result v0

    .line 187
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v3

    .line 191
    if-nez v0, :cond_c2

    .line 192
    .line 193
    if-ne v3, v1, :cond_cd

    .line 194
    .line 195
    :cond_c2
    new-instance v3, Landroidx/work/ListenableFutureKt$launchFuture$1$2;

    .line 196
    .line 197
    const/4 v0, 0x0

    .line 198
    const/16 v5, 0xa

    .line 199
    .line 200
    invoke-direct {v3, p1, p3, v0, v5}, Landroidx/work/ListenableFutureKt$launchFuture$1$2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;B)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {p2, v3}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 204
    .line 205
    .line 206
    :cond_cd
    check-cast v3, Lkotlin/jvm/functions/Function2;

    .line 207
    .line 208
    invoke-static {p2, v2, v3}, Landroidx/compose/runtime/Updater;->LaunchedEffect(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 209
    .line 210
    .line 211
    iget-object p1, p3, Landroidx/compose/animation/core/Animatable;->internalState:Landroidx/compose/animation/core/AnimationState;

    .line 212
    .line 213
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 214
    .line 215
    .line 216
    move-result p3

    .line 217
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 218
    .line 219
    .line 220
    move-result-object v0

    .line 221
    if-nez p3, :cond_e0

    .line 222
    .line 223
    if-ne v0, v1, :cond_e8

    .line 224
    .line 225
    :cond_e0
    new-instance v0, Landroidx/compose/foundation/text/selection/SelectionMagnifierKt$$ExternalSyntheticLambda3;

    .line 226
    .line 227
    invoke-direct {v0, p1, v4}, Landroidx/compose/foundation/text/selection/SelectionMagnifierKt$$ExternalSyntheticLambda3;-><init>(Landroidx/compose/runtime/State;B)V

    .line 228
    .line 229
    .line 230
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 231
    .line 232
    .line 233
    :cond_e8
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 234
    .line 235
    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object p0

    .line 239
    check-cast p0, Landroidx/compose/ui/Modifier;

    .line 240
    .line 241
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 242
    .line 243
    .line 244
    return-object p0

    .line 245
    :pswitch_f4
    check-cast p0, Lkotlin/jvm/functions/Function1;

    .line 246
    .line 247
    check-cast v3, Landroidx/compose/foundation/contextmenu/ContextMenuColors;

    .line 248
    .line 249
    check-cast p1, Landroidx/compose/foundation/layout/ColumnScope;

    .line 250
    .line 251
    check-cast p2, Landroidx/compose/runtime/Composer;

    .line 252
    .line 253
    check-cast p3, Ljava/lang/Integer;

    .line 254
    .line 255
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 256
    .line 257
    .line 258
    move-result p1

    .line 259
    and-int/lit8 p3, p1, 0x11

    .line 260
    .line 261
    const/16 v0, 0x10

    .line 262
    .line 263
    const/4 v5, 0x1

    .line 264
    if-eq p3, v0, :cond_10b

    .line 265
    .line 266
    move p3, v5

    .line 267
    goto :goto_10c

    .line 268
    :cond_10b
    move p3, v4

    .line 269
    :goto_10c
    and-int/2addr p1, v5

    .line 270
    check-cast p2, Landroidx/compose/runtime/GapComposer;

    .line 271
    .line 272
    invoke-virtual {p2, p1, p3}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 273
    .line 274
    .line 275
    move-result p1

    .line 276
    if-eqz p1, :cond_131

    .line 277
    .line 278
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object p1

    .line 282
    if-ne p1, v1, :cond_123

    .line 283
    .line 284
    new-instance p1, Landroidx/compose/foundation/contextmenu/ContextMenuScope;

    .line 285
    .line 286
    invoke-direct {p1}, Landroidx/compose/foundation/contextmenu/ContextMenuScope;-><init>()V

    .line 287
    .line 288
    .line 289
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 290
    .line 291
    .line 292
    :cond_123
    check-cast p1, Landroidx/compose/foundation/contextmenu/ContextMenuScope;

    .line 293
    .line 294
    iget-object p3, p1, Landroidx/compose/foundation/contextmenu/ContextMenuScope;->composables:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 295
    .line 296
    invoke-virtual {p3}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    .line 297
    .line 298
    .line 299
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    invoke-virtual {p1, v3, p2, v4}, Landroidx/compose/foundation/contextmenu/ContextMenuScope;->Content$foundation(Landroidx/compose/foundation/contextmenu/ContextMenuColors;Landroidx/compose/runtime/Composer;I)V

    .line 303
    .line 304
    .line 305
    goto :goto_134

    .line 306
    :cond_131
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 307
    .line 308
    .line 309
    :goto_134
    return-object v2

    .line 310
    nop

    .line 311
    :pswitch_data_136
    .packed-switch 0x0
        :pswitch_f4
        :pswitch_6f
    .end packed-switch
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
.end method
