.class public final Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;
.super Landroidx/compose/foundation/gestures/ForEachGestureKt;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"


# instance fields
.field public initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

.field public pointerId:J
