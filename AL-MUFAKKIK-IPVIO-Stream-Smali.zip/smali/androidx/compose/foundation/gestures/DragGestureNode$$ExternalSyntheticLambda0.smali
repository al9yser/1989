.class public final synthetic Landroidx/compose/foundation/gestures/DragGestureNode$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic f$0:F

.field public final synthetic f$1:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(FLkotlin/jvm/internal/Ref$BooleanRef;)V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode$$ExternalSyntheticLambda0;->$r8$classId:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode$$ExternalSyntheticLambda0;->f$0:F

    .line 8
    .line 9
    iput-object p2, p0, Landroidx/compose/foundation/gestures/DragGestureNode$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    .line 10
    .line 11
    return-void
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
.end method

.method public synthetic constructor <init>(Landroidx/compose/animation/core/TransitionInstance;F)V
    .registers 4

    .line 12
    const/4 v0, 0x1

    iput-byte v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode$$ExternalSyntheticLambda0;->$r8$classId:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    iput p2, p0, Landroidx/compose/foundation/gestures/DragGestureNode$$ExternalSyntheticLambda0;->f$0:F

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 1
    iget-byte v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode$$ExternalSyntheticLambda0;->$r8$classId:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    iget v3, p0, Landroidx/compose/foundation/gestures/DragGestureNode$$ExternalSyntheticLambda0;->f$0:F

    .line 6
    .line 7
    iget-object p0, p0, Landroidx/compose/foundation/gestures/DragGestureNode$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_ae

    .line 10
    .line 11
    .line 12
    check-cast p0, Landroidx/compose/animation/core/TransitionInstance;

    .line 13
    .line 14
    check-cast p1, Ljava/lang/Long;

    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 17
    .line 18
    .line 19
    move-result-wide v4

    .line 20
    invoke-virtual {p0}, Landroidx/compose/animation/core/TransitionInstance;->isSeeking()Z

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    iget-object v0, p0, Landroidx/compose/animation/core/TransitionInstance;->startTimeNanos$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 25
    .line 26
    if-nez p1, :cond_62

    .line 27
    .line 28
    invoke-virtual {v0}, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;->getLongValue()J

    .line 29
    .line 30
    .line 31
    move-result-wide v6

    .line 32
    const-wide/high16 v8, -0x8000000000000000L

    .line 33
    .line 34
    cmp-long p1, v6, v8

    .line 35
    .line 36
    if-nez p1, :cond_33

    .line 37
    .line 38
    invoke-virtual {v0, v4, v5}, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;->setLongValue(J)V

    .line 39
    .line 40
    .line 41
    iget-object p1, p0, Landroidx/compose/animation/core/TransitionInstance;->transitionState:Lcoil/memory/RealStrongMemoryCache;

    .line 42
    .line 43
    iget-object p1, p1, Lcoil/memory/RealStrongMemoryCache;->weakMemoryCache:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast p1, Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 46
    .line 47
    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 48
    .line 49
    invoke-virtual {p1, v6}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->setValue(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    :cond_33
    invoke-virtual {v0}, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;->getLongValue()J

    .line 53
    .line 54
    .line 55
    move-result-wide v6

    .line 56
    sub-long/2addr v4, v6

    .line 57
    const/4 p1, 0x0

    .line 58
    cmpg-float p1, v3, p1

    .line 59
    .line 60
    if-nez p1, :cond_3e

    .line 61
    .line 62
    goto :goto_4b

    .line 63
    :cond_3e
    long-to-double v4, v4

    .line 64
    float-to-double v6, v3

    .line 65
    div-double/2addr v4, v6

    .line 66
    invoke-static {v4, v5}, Ljava/lang/Double;->isNaN(D)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-nez v0, :cond_5b

    .line 71
    .line 72
    invoke-static {v4, v5}, Ljava/lang/Math;->round(D)J

    .line 73
    .line 74
    .line 75
    move-result-wide v4

    .line 76
    :goto_4b
    iget-object v0, p0, Landroidx/compose/animation/core/TransitionInstance;->parentTransition:Landroidx/compose/animation/core/TransitionInstance;

    .line 77
    .line 78
    if-nez v0, :cond_54

    .line 79
    .line 80
    iget-object v0, p0, Landroidx/compose/animation/core/TransitionInstance;->_playTimeNanos$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 81
    .line 82
    invoke-virtual {v0, v4, v5}, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;->setLongValue(J)V

    .line 83
    .line 84
    .line 85
    :cond_54
    if-nez p1, :cond_57

    .line 86
    .line 87
    move v1, v2

    .line 88
    :cond_57
    invoke-virtual {p0, v4, v5, v1}, Landroidx/compose/animation/core/TransitionInstance;->onFrame$animation_core(JZ)V

    .line 89
    .line 90
    .line 91
    goto :goto_62

    .line 92
    :cond_5b
    const-string p0, "Cannot round NaN value."

    .line 93
    .line 94
    invoke-static {p0}, Lokhttp3/internal/Util$$ExternalSyntheticLambda2;->m$2(Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    const/4 p0, 0x0

    .line 98
    goto :goto_64

    .line 99
    :cond_62
    :goto_62
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 100
    .line 101
    :goto_64
    return-object p0

    .line 102
    :pswitch_65
    check-cast p0, Lkotlin/jvm/internal/Ref$BooleanRef;

    .line 103
    .line 104
    check-cast p1, Landroidx/compose/foundation/gestures/DraggableGestureConnection;

    .line 105
    .line 106
    invoke-interface {p1}, Landroidx/compose/foundation/GestureConnection;->getGestureState-7meUWtM()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    const-string v4, "waiting"

    .line 111
    .line 112
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    invoke-interface {p1}, Landroidx/compose/foundation/gestures/DraggableGestureConnection;->getOrientation()Landroidx/compose/foundation/gestures/Orientation;

    .line 117
    .line 118
    .line 119
    move-result-object v4

    .line 120
    if-nez v4, :cond_7b

    .line 121
    .line 122
    :cond_79
    move p1, v1

    .line 123
    goto :goto_9b

    .line 124
    :cond_7b
    invoke-interface {p1}, Landroidx/compose/foundation/gestures/DraggableGestureConnection;->getOrientation()Landroidx/compose/foundation/gestures/Orientation;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 129
    .line 130
    .line 131
    sget v4, Landroidx/compose/foundation/gestures/DraggableKt;->$r8$clinit:I

    .line 132
    .line 133
    sget-object v4, Landroidx/compose/foundation/gestures/Orientation;->Horizontal:Landroidx/compose/foundation/gestures/Orientation;

    .line 134
    .line 135
    const/high16 v5, 0x41f00000    # 30.0f

    .line 136
    .line 137
    if-ne p1, v4, :cond_90

    .line 138
    .line 139
    cmpg-float p1, v3, v5

    .line 140
    .line 141
    if-gtz p1, :cond_79

    .line 142
    .line 143
    :goto_8e
    move p1, v2

    .line 144
    goto :goto_9b

    .line 145
    :cond_90
    cmpl-float p1, v3, v5

    .line 146
    .line 147
    if-lez p1, :cond_79

    .line 148
    .line 149
    const/high16 p1, 0x42b40000    # 90.0f

    .line 150
    .line 151
    cmpg-float p1, v3, p1

    .line 152
    .line 153
    if-gtz p1, :cond_79

    .line 154
    .line 155
    goto :goto_8e

    .line 156
    :goto_9b
    iget-boolean v3, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 157
    .line 158
    if-nez v3, :cond_a3

    .line 159
    .line 160
    if-eqz v0, :cond_a4

    .line 161
    .line 162
    if-eqz p1, :cond_a4

    .line 163
    .line 164
    :cond_a3
    move v1, v2

    .line 165
    :cond_a4
    iput-boolean v1, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 166
    .line 167
    xor-int/lit8 p0, v1, 0x1

    .line 168
    .line 169
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 170
    .line 171
    .line 172
    move-result-object p0

    .line 173
    return-object p0

    .line 174
    nop

    .line 175
    :pswitch_data_ae
    .packed-switch 0x0
        :pswitch_65
    .end packed-switch
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
.end method
