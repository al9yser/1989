.class public interface abstract Landroidx/compose/foundation/layout/Arrangement$SpacingAlignmentCalculator;
.super Ljava/lang/Object;
.source "r8-map-id-0087837f54a01438dc5899cfbccb437e9488162e5ecf4168b45c1688b5a05b55"


# virtual methods
.method public abstract align(ILandroidx/compose/ui/unit/LayoutDirection;)I
.end method
